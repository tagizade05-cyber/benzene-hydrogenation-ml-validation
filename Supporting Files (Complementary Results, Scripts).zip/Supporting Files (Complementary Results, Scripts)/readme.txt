This README and the comments in the code were written by the large language model (LLM) OpenAI ChatGPT.
Authors remain responsible for checking the data, code, interpretation and publication claims.


BENZENE HYDROGENATION: DATA, CODE AND SAVED RESULTS


1. PURPOSE AND SCOPE

This package accompanies a study of cyclohexane and cyclohexene yield prediction
from literature-derived benzene-hydrogenation experiments. The workbook contains
90 observations from four publications and 30 catalyst identities. Both product
targets are analysed separately. 


2. START HERE: VIEW SAVED RESULTS WITHOUT FITTING MODELS

No Python installation is needed to view the saved PNG/PDF/SVG figures or CSVs.
Within results/, the principal figure locations are:

  dataset_composition/
    Dataset composition and yield-distribution figure and source summaries.
  metrics_heatmaps/filter_on/<target>/figures/
    Main CV performance matrices, including the horizontal R2/MAE/RMSE figure.
  oof_learning_curves/filter_on/<target>/figures/
    Seed-42 OOF/actual panels and training/validation learning curves.
  matched_cv_bo/filter_on/figures/
    Matched-analysis 8- and 16-panel OOF/actual figures (seed 42).
  matched_cv_bo/filter_on/merged_cv_both_bo_updated/
    Matched mean +/- SD comparison heatmap for both targets.
  regression_equations/filter_on/<target>/
    Three equations, coefficients, predictions, metrics and comparison figures.

<target> means cyclohexane or cyclohexene. The four main CV folder names are:
  kfold_5                shuffled row-wise five-fold CV
  groupkfold_catalyst    five-fold CV grouped by catalyst identity
  leave_one_out         leave-one-observation-out CV (LOO)
  leave_one_paper_out    leave-one-publication-out CV (LOPO)

The archived completed analyses use descriptor filtering (filter_on). The option
to run filter_off is supported by the scripts; its results are not supplied here.

3. FILES AND DEPENDENCIES

DATA_ML_Benzene_Hydrogenation.xlsx is the source workbook; the analysis worksheet
is FullDataset. Is_unsupported_metal is the unsupported-catalyst indicator, shown
as Unsupported (Powder/Nano-clusters) in the composition figure.

Main modelling entry points:
  CYCLOHEXANE_ML_MODELS.py
  CYCLOHEXENE_ML_MODELS.py
Additional matched analyses:
  CYCLOHEXANE_ADDITIONAL_MATCHED_CV_CASE.py
  CYCLOHEXENE_ADDITIONAL_MATCHED_CV_CASE.py
Sparse empirical equations:
  CYCLOHEXANE_REGRESSION_EQUATIONS.py
  CYCLOHEXENE_REGRESSION_EQUATIONS.py
Plotting/support:
  plot_dataset_composition.py       standalone dataset figure
  Merged_CV_BO_Plots.py             matched seed-42 OOF figures
  run_all_cv.py                    optional batch runner (also has --plots-only)
  workflow_common.py               shared data/path/validation helpers
  results/Results_plot_CYCLOHEXANE_heatmaps.py
  results/Results_plot_CYCLOHEXENE_heatmaps.py
  results/CYCLOHEXANE_OOF_and_learning_curves.py
  results/CYCLOHEXENE_OOF_and_learning_curves.py
  results/results_plot_support.py  shared plotting/input validation
  results/saved_curve_estimators.py  estimators for optional missing LOO subsets
  results/matched_cv_bo/filter_on/plot_cv_heatmaps_merged_nested_and_nonnested.py

Do not remove the helpers, plotting_snapshot/, learning_curve_inputs_seed42/,
saved source-code copies, search caches, or split/configuration files. They provide
required inputs and provenance even where some files look duplicated. Run the
entry points above, not historical copies stored inside individual result folders.

4. PYTHON ENVIRONMENT

Create a separate Python 3.11 environment, open a terminal in this package's root
folder, and install:

  python -m pip install -r requirements.txt

The local matched run metadata records Python 3.11.9, NumPy 2.3.3, pandas 2.3.3,
scikit-learn 1.7.2, scikit-optimize 0.10.2 and XGBoost 3.0.5. These five package
versions are pinned in requirements.txt. Other listed packages are needed but
their exact versions were not recorded in that metadata; this file is therefore
not a complete environment lockfile. Installing dependencies is an explicit user
step and does not automatically change any existing local Python installation.

5. INTERPRETING RESULTS AND SEEDS

Main-model summaries are under model_results/filter_on/<target>/<cv_case>/.
Compact copies for plotting are under metrics_heatmaps/ and oof_learning_curves/.
Pooled OOF R2, MAE and RMSE are computed after combining held-out predictions;
they are not arithmetic averages of fold-level R2 values. MAE and RMSE are yield
percentage points; R2 is dimensionless. Predictions are not clipped to 0-100%.

Main non-LOO metric summaries report five-run means and sample SD (ddof=1). LOO
has one run, so an across-seed SD is undefined. OOF panels, metrics in their boxes,
SHAP figures and reference hyperparameter selections use seed 42.

For matched results, model_metrics_by_seed_5runs.csv provides all five seed scores.
The five-seed summary copies retain their original names, including
cyclohexane_model_metrics_mean_SD_5seeds.csv and the historical spelling
cylohexene_model_metrics_mean_SD_5seeds.csv, because the matched heatmap reads them.

The main workflow uses shuffled inner five-fold tuning even with grouped outer
evaluation. The matched workflow instead groups inner tuning by catalyst or paper
to match the outer design. Non-nested BO and the equation CV diagnostics reuse
globally selected settings and are tuning-informed. Nested tuning excludes outer
test responses. The predictor rarity screen is target-free but applied globally
before CV; it is not a fold-local preprocessing procedure. GPR/OLS scalers are
fitted on their training subsets.

Learning curves use seed 42 and saved fractions. LOO XGBoost/GPR curves retain
parameters selected in the original outer-training fold, fit smaller subsets
without new BO, and reuse the full-size point. Other saved CV curves use subset
retuning. The LOO curves are conditional diagnostics. OOF predictions alone do
not provide genuine smaller-training-size learning points.

