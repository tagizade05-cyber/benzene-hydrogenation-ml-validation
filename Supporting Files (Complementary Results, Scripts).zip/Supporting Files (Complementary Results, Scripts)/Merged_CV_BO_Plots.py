"""Redraw matched-CV supporting figures using saved CSV snapshots only.

Run after the two matched-analysis scripts. Defaults produce one eight-panel
OOF vs Actual figure per target and one combined sixteen-panel figure. PNG and
PDF versions are saved. --include-small-panels also makes the original two- and
four-panel comparisons. No model is imported, fitted, or optimized here.

"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json
import string

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

SCRIPT_DIR = Path(__file__).resolve().parent
RESULTS_ROOT = SCRIPT_DIR / "results" / "matched_cv_bo"
APPLY_RARE_FEATURE_FILTER_TO_ML = True
PREFERRED_SEED = 42
DPI = 300
TARGETS = ("Cyclohexane", "Cyclohexene")
MODELS = ("XGBoost", "GPR")
CASES = ("Nested BO", "Non-nested BO")
ALL_CASES = ("Base case", "Nested BO", "Non-nested BO")
STRATEGIES = ("groupkfold_catalyst", "leave_one_paper_out")
COLORS = {"groupkfold_catalyst": "#1f77b4", "leave_one_paper_out": "#e07b25"}
SHORT_NAMES = {"groupkfold_catalyst": "Catalyst group 5-fold", "leave_one_paper_out": "LOPO"}


def file_sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def pooled_metrics(actual, predicted):
    e = np.asarray(actual, dtype=float) - np.asarray(predicted, dtype=float)
    sst = np.sum((actual - np.mean(actual)) ** 2)
    r2 = 1 - np.sum(e ** 2) / sst if sst > 0 else (1.0 if np.all(e == 0) else 0.0)
    return np.array([r2, np.abs(e).mean(), np.sqrt(np.mean(e ** 2))])


def load_target(snapshot, target, seed, filter_on):
    """Reject mixed, incomplete, stale, or numerically inconsistent plot inputs."""
    manifest_path = snapshot / f"{target}_snapshot_manifest.json"
    if not manifest_path.is_file():
        raise FileNotFoundError(f"Missing {manifest_path}. Run the updated {target} matched-analysis script first.")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if manifest.get("status") != "complete" or manifest.get("inner_policy") != "matched_grouping_no_rowwise_fallback":
        raise ValueError(f"{target}: a complete matched-inner/outer run is required.")
    if bool(manifest["descriptor_filter"]) != filter_on:
        raise ValueError(f"{target}: descriptor-filter setting does not match the selected plotting folder.")
    if seed not in manifest["seeds"]:
        raise ValueError(f"{target}: seed {seed} is unavailable; saved seeds are {manifest['seeds']}.")
    for filename, expected_hash in manifest["files"].items():
        path = snapshot / filename
        if not path.is_file() or file_sha(path) != expected_hash:
            raise ValueError(f"Incomplete/modified snapshot file: {path}. Republish the complete run before plotting.")
    pred_path = snapshot / f"{target}_matched_CV_BO_OOF_predictions_LONG.csv"
    metrics_path = snapshot / f"{target}_matched_CV_BO_metrics.csv"
    preds = pd.read_csv(pred_path)
    mets = pd.read_csv(metrics_path)
    required_predictions = {"seed", "outer_strategy", "model", "BO_case", "row_index", "actual", "oof_prediction", "analysis_signature", "run_id"}
    required_metrics = {"seed", "outer_strategy", "model", "BO_case", "R2", "MAE", "RMSE", "analysis_signature", "run_id"}
    if required_predictions - set(preds) or required_metrics - set(mets):
        raise ValueError(f"{target}: the expected new snapshot schema is missing.")
    for frame in [preds, mets]:
        if set(frame.analysis_signature) != {manifest["analysis_signature"]} or set(frame.run_id) != {manifest["run_id"]}:
            raise ValueError(f"{target}: metric and prediction files came from different runs.")
    preds = preds.loc[pd.to_numeric(preds.seed).eq(seed)].copy()
    mets = mets.loc[pd.to_numeric(mets.seed).eq(seed)].copy()
    count = int(manifest["n_rows"])
    reference_actual = None
    for cv in STRATEGIES:
        for model in MODELS:
            for case in ALL_CASES:
                pp = subset(preds, cv, model, case)
                mm = metric_row(mets, cv, model, case)
                if len(pp) != count or pp.row_index.duplicated().any() or not np.array_equal(pp.row_index.to_numpy(), np.arange(count)):
                    raise ValueError(f"{target}/{cv}/{model}/{case}: every observation must have exactly one OOF prediction.")
                actual, predicted = pp.actual.to_numpy(float), pp.oof_prediction.to_numpy(float)
                if not np.isfinite(np.r_[actual, predicted]).all():
                    raise ValueError("Non-finite plot values are not permitted.")
                if reference_actual is None:
                    reference_actual = actual
                elif not np.allclose(reference_actual, actual, rtol=0, atol=1e-12):
                    raise ValueError(f"{target}: actual yields differ across validation/model cases.")
                calculated = pooled_metrics(actual, predicted)
                supplied = mm[["R2", "MAE", "RMSE"]].to_numpy(float)
                if not np.allclose(calculated, supplied, rtol=1e-9, atol=1e-9):
                    raise ValueError(f"{target}/{cv}/{model}/{case}: stored metrics disagree with saved OOF predictions.")
    return preds, mets, manifest


def subset(predictions, cv, model, case):
    return predictions.loc[predictions.outer_strategy.eq(cv) & predictions.model.eq(model)
                           & predictions.BO_case.eq(case)].sort_values("row_index")


def metric_row(metrics, cv, model, case):
    selected = metrics.loc[metrics.outer_strategy.eq(cv) & metrics.model.eq(model) & metrics.BO_case.eq(case)]
    if len(selected) != 1:
        raise ValueError(f"Need exactly one metric row for {cv}/{model}/{case}; found {len(selected)}.")
    return selected.iloc[0]


def shared_limits(predictions):
    """Keep every actual yield and raw OOF prediction visible, including negatives.

    Scales are shared across BO panels WITHIN a target. The two targets have
    different yield ranges and are not forced onto the same sixteen-panel scale.
    """
    selected = predictions[predictions.BO_case.isin(CASES)]
    values = np.r_[selected.actual.to_numpy(float), selected.oof_prediction.to_numpy(float)]
    low, high = min(0.0, values.min()), max(0.0, values.max())
    padding = max((high - low) * .065, .1)
    return low - padding, high + padding


def panel(ax, predictions, metrics, cv, model, case, limits, title, letter):
    sample = subset(predictions, cv, model, case)
    stats = metric_row(metrics, cv, model, case)
    ax.scatter(sample.actual, sample.oof_prediction, s=23, alpha=.82,
               c=COLORS[cv], edgecolors="#242424", linewidths=.35, zorder=3)
    ax.plot(limits, limits, color="#333333", linestyle="--", linewidth=1, zorder=1)
    ax.set_xlim(limits); ax.set_ylim(limits)
    ax.set_aspect("equal", adjustable="box")
    ax.grid(alpha=.22, linewidth=.6)
    ax.set_axisbelow(True)
    ax.tick_params(labelsize=10.5, labelbottom=True, labelleft=True)
    ax.set_title(f"({letter}) {title}", fontsize=11.5, pad=7)
    ax.text(.035, .97, f"R² = {stats.R2:.3f}\nMAE = {stats.MAE:.3f} pp\nRMSE = {stats.RMSE:.3f} pp",
            transform=ax.transAxes, va="top", ha="left", fontsize=10.3, linespacing=1.15,
            bbox={"facecolor": "white", "edgecolor": "#cccccc", "alpha": .91, "pad": 3}, zorder=5)


def save_figure(fig, output, name, options):
    output.mkdir(parents=True, exist_ok=True)
    for extension in options.formats:
        destination = output / f"{name}.{extension}"
        fig.savefig(destination, dpi=options.dpi, bbox_inches="tight", facecolor="white")
        print(f"Saved {destination}", flush=True)
    plt.close(fig)


def plot_eight(target, preds, mets, output, options):
    fig, axes = plt.subplots(2, 4, figsize=(17.2, 10.0))
    limits = shared_limits(preds)
    for row, case in enumerate(CASES):
        for column, (cv, model) in enumerate((cv, model) for cv in STRATEGIES for model in MODELS):
            panel(axes[row, column], preds, mets, cv, model, case, limits,
                  f"{SHORT_NAMES[cv]}\n{model} | {case}", string.ascii_lowercase[row * 4 + column])
    fig.suptitle(f"{target} yield | OOF vs Actual | Random seed {options.seed}", fontsize=17, y=.985)
    fig.supxlabel("Actual yield (%)", fontsize=13, y=.035)
    fig.supylabel("OOF predicted yield (%)", fontsize=13, x=.025)
    fig.subplots_adjust(left=.065, right=.99, bottom=.085, top=.86, hspace=.32, wspace=.21)
    save_figure(fig, output, f"{target}_EIGHT_PANEL_matched_CV_OOF_seed{options.seed}", options)


def plot_sixteen(loaded, output, options):
    fig, axes = plt.subplots(4, 4, figsize=(18.0, 20.0))
    for target_index, target in enumerate(TARGETS):
        preds, mets, _ = loaded[target]
        limits = shared_limits(preds)
        for case_index, case in enumerate(CASES):
            row = target_index * 2 + case_index
            for col, (cv, model) in enumerate((cv, model) for cv in STRATEGIES for model in MODELS):
                title = f"{target} | {SHORT_NAMES[cv]}\n{model} | {case}"
                panel(axes[row, col], preds, mets, cv, model, case, limits, title, string.ascii_lowercase[row * 4 + col])
    fig.suptitle(f"Benzene hydrogenation yields | OOF vs Actual | Random seed {options.seed}", fontsize=17, y=.99)
    fig.supxlabel("Actual yield (%)", fontsize=13, y=.025)
    fig.supylabel("OOF predicted yield (%)", fontsize=13, x=.023)
    fig.subplots_adjust(left=.065, right=.99, bottom=.055, top=.93, hspace=.32, wspace=.21)
    save_figure(fig, output, f"BOTH_TARGETS_SIXTEEN_PANEL_matched_CV_OOF_seed{options.seed}", options)


def plot_small_panels(target, preds, mets, output, options):
    """Optional original pair/four-panel layouts for supplementary alternatives."""
    for cv in STRATEGIES:
        for model in MODELS:
            fig, axes = plt.subplots(1, 2, figsize=(10, 5.6))
            for i, case in enumerate(CASES):
                panel(axes[i], preds, mets, cv, model, case, shared_limits(preds), case, string.ascii_lowercase[i])
            fig.suptitle(f"{target} | {SHORT_NAMES[cv]} | {model}\nOOF vs Actual | Random seed {options.seed}", fontsize=13)
            fig.supxlabel("Actual yield (%)"); fig.supylabel("OOF predicted yield (%)")
            fig.subplots_adjust(top=.78, bottom=.15, left=.1, right=.98, wspace=.24)
            save_figure(fig, output, f"{target}_{cv}_{model}_TWO_PANEL_seed{options.seed}", options)
        fig, axes = plt.subplots(2, 2, figsize=(10, 11))
        for i, model in enumerate(MODELS):
            for j, case in enumerate(CASES):
                panel(axes[i, j], preds, mets, cv, model, case, shared_limits(preds), f"{model} | {case}", string.ascii_lowercase[i * 2 + j])
        fig.suptitle(f"{target} | {SHORT_NAMES[cv]}\nOOF vs Actual | Random seed {options.seed}", fontsize=14)
        fig.supxlabel("Actual yield (%)"); fig.supylabel("OOF predicted yield (%)")
        fig.subplots_adjust(top=.86, bottom=.08, left=.1, right=.98, wspace=.24, hspace=.25)
        save_figure(fig, output, f"{target}_{cv}_FOUR_PANEL_seed{options.seed}", options)


def parse_options(argv=None):
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--results-root", type=Path, default=RESULTS_ROOT)
    p.add_argument("--data-dir", type=Path, help="Override the flat plotting_snapshot directory.")
    p.add_argument("--output-dir", type=Path, help="Override the default figures directory.")
    p.add_argument("--seed", type=int, default=PREFERRED_SEED)
    p.add_argument("--targets", nargs="+", choices=TARGETS, default=list(TARGETS))
    p.add_argument("--formats", nargs="+", choices=["png", "pdf"], default=["png", "pdf"])
    p.add_argument("--dpi", type=int, default=DPI)
    p.add_argument("--descriptor-filter", dest="descriptor_filter", action="store_true")
    p.add_argument("--no-descriptor-filter", dest="descriptor_filter", action="store_false")
    p.set_defaults(descriptor_filter=APPLY_RARE_FEATURE_FILTER_TO_ML)
    p.add_argument("--include-small-panels", action="store_true")
    opts = p.parse_args(argv)
    if opts.dpi < 50:
        p.error("Use at least 50 DPI.")
    return opts


def main(options=None):
    options = options or parse_options()
    parent = options.results_root / ("filter_on" if options.descriptor_filter else "filter_off")
    snapshot = options.data_dir or (parent / "plotting_snapshot")
    output = options.output_dir or (parent / "figures")
    loaded = {target: load_target(snapshot, target, options.seed, options.descriptor_filter) for target in options.targets}
    if len(loaded) == 2:
        manifests = [loaded[t][2] for t in TARGETS]
        for key in ["workbook_sha256", "descriptor_filter", "bo_iterations", "inner_policy", "n_rows", "outer_splits_sha256"]:
            if manifests[0][key] != manifests[1][key]:
                raise ValueError(f"The two targets have different {key}; do not merge unlike analyses.")
    for target, (preds, mets, _) in loaded.items():
        plot_eight(target, preds, mets, output, options)
        if options.include_small_panels:
            plot_small_panels(target, preds, mets, output, options)
    if len(loaded) == 2:
        plot_sixteen(loaded, output, options)
    record = {"created_utc": datetime.now(timezone.utc).isoformat(), "seed": options.seed,
              "descriptor_filter": options.descriptor_filter, "dpi": options.dpi,
              "formats": options.formats, "metrics": "pooled OOF; verified against saved predictions",
              "predictions_clipped": False, "model_training_performed": False,
              "plot_script_sha256": file_sha(__file__),
              "plot_libraries": {"numpy": np.__version__, "pandas": pd.__version__, "matplotlib": matplotlib.__version__},
              "source_manifests": {t: data[2] for t, data in loaded.items()}}
    (output / "figure_provenance.json").write_text(json.dumps(record, indent=2), encoding="utf-8")



if __name__ == "__main__":
    main()
