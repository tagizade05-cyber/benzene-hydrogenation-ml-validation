"""Three regression equations for cyclohexane yield.

1. BO LASSO selection + OLS on original descriptors, five-fold CV R2 objective.
2. Original-0/1 predefined terms, five-fold CV R2 BO objective.
3. Original-0/1 predefined terms, full-data R2 BO objective.

Place beside DATA_ML_Benzene_Hydrogenation.xlsx and run normally.
No reference-category equation cases or separate ML model evaluations are run.
"""
from pathlib import Path
from datetime import datetime
import argparse
import hashlib
import json
import shutil
import sys
import textwrap
import time

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.base import BaseEstimator, RegressorMixin
from sklearn.linear_model import LinearRegression, Lasso
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
from sklearn.model_selection import KFold
from sklearn.preprocessing import StandardScaler
from skopt import BayesSearchCV
from skopt.space import Real, Integer
from threadpoolctl import threadpool_limits

for _stream in (sys.stdout, sys.stderr):
    if hasattr(_stream, "reconfigure"):
        _stream.reconfigure(encoding="utf-8", errors="replace")

SCRIPT_DIR = Path(__file__).resolve().parent
TARGET_NAME = "cyclohexane"
TARGET = "Cyclohexane_yield_%"
TARGET_LABEL = "Cyclohexane yield (%)"
INPUT_FILE = SCRIPT_DIR / "DATA_ML_Benzene_Hydrogenation.xlsx"
SHEET_NAME = "FullDataset"
RESULTS_ROOT = SCRIPT_DIR / "results" / "regression_equations"
EQUATION_BO_N_ITER = 30
EQUATION_BO_CV_SPLITS = 5
EQUATION_BO_RANDOM_STATE = 42
BO_SEARCH_N_JOBS = -1
APPLY_RARE_FEATURE_FILTER_TO_ML = True  # Applied to LASSO-OLS descriptors only.
LEAKAGE_COLS = [
    "Benzene_conversion_%",
    "Selectivity_to_cyclohexane_%",
    "Selectivity_to_cyclohexene_%",
    "Cyclohexene_yield_%",
]
ID_COLS = [
    "Author",
    "Source_study",
    "Reference",
    "Paper",
    "Experiment_ID",
    "Catalyst_ID2",
    "Catalyst_ID",
    "Catalyst",
    "Metal",
]
LINEAR_EQ_BASE_ALPHA = 0.03
LINEAR_EQ_SELECTION_THRESHOLD = 1e-4
LINEAR_EQ_SELECTION_THRESHOLD_MIN = 1e-4
LINEAR_EQ_SELECTION_THRESHOLD_MAX = 5e-2
LINEAR_EQ_MAX_TERMS_CAP = 20
LINEAR_EQ_MAX_ITER = 500000
LINEAR_EQ_TOL = 1e-2
SYMBOLIC_CVR2_MAX_TERMS_CAP = 18
SYMBOLIC_FULLR2_MAX_TERMS_CAP = 13
SYMBOLIC_FULLR2_ALPHA_MIN = 1e-3
SYMBOLIC_CVR2_ALPHA_MIN = 1e-3
SYMBOLIC_SELECTION_THRESHOLD_MIN = 1e-7
SYMBOLIC_CONDITION_NUMBER_LIMIT = 1e8
SYMBOLIC_BO_ACQ_FUNC = "LCB"
SYMBOLIC_BO_ACQ_KAPPA = 3.0
SYMBOLIC_BO_ACQ_XI = 0.05
MIN_BINARY_MINORITY_COUNT = 3
MIN_CONTINUOUS_UNIQUE_VALUES = 3

RUN_START = time.perf_counter()


def log(message):
    print(f"[{datetime.now():%Y-%m-%d %H:%M:%S}] +{time.perf_counter()-RUN_START:8.2f}s | {message}", flush=True)


def format_runtime(seconds):
    return f"{seconds:.2f} s ({seconds/60:.2f} min)"


def metrics(y_true, y_pred):
    y_true = np.asarray(y_true, dtype=float)
    y_pred = np.asarray(y_pred, dtype=float)
    r2 = np.nan
    if len(y_true) >= 2:
        r2 = float(r2_score(y_true, y_pred))
    return {
        "R2": r2,
        "MAE": float(mean_absolute_error(y_true, y_pred)),
        "RMSE": float(np.sqrt(mean_squared_error(y_true, y_pred))),
    }


def metrics_safe(y_true, y_pred):
    return metrics(y_true, y_pred)


def normalize_acq(acq_func, kappa, xi):
    acq = str(acq_func).upper()
    if acq == "UCB":
        # scikit-optimize uses LCB for UCB-style exploration under minimisation.
        acq = "LCB"
    allowed = {"LCB", "PI", "EI", "GP_HEDGE"}
    if acq not in allowed:
        raise ValueError("Acquisition function must be one of: LCB, UCB, PI, EI, gp_hedge")
    if acq == "GP_HEDGE":
        acq = "gp_hedge"
    kwargs = {}
    if acq == "LCB":
        kwargs["kappa"] = kappa
    elif acq in ["PI", "EI"]:
        kwargs["xi"] = xi
    return acq, kwargs


def safe_param_dict(params):
    out = {}
    for k, v in params.items():
        if hasattr(v, "item"):
            v = v.item()
        out[k] = v
    return out


def fmt_params_for_report(params):
    return json.dumps(params, indent=2, default=str)


def trim_rare_ml_features(X_df, min_binary_minority_count=3, min_continuous_unique_values=3):
    """Target-independent feature filter for ML models only."""
    X_df = pd.DataFrame(X_df).copy()
    keep_cols = []
    rows = []
    for col in X_df.columns:
        s = pd.to_numeric(X_df[col], errors="coerce")
        finite = s.replace([np.inf, -np.inf], np.nan).dropna()
        unique_vals = np.sort(finite.unique())
        is_binary = len(unique_vals) <= 2 and set(unique_vals).issubset({0, 1})
        if is_binary:
            count_0 = int((s == 0).sum())
            count_1 = int((s == 1).sum())
            minority = min(count_0, count_1)
            keep = minority >= int(min_binary_minority_count)
            reason = f"binary counts: 0={count_0}, 1={count_1}, minority={minority}, required={min_binary_minority_count}"
        else:
            n_unique = int(finite.nunique())
            keep = n_unique >= int(min_continuous_unique_values)
            reason = f"non-binary unique finite values={n_unique}, required={min_continuous_unique_values}"
        rows.append({"feature": col, "kept_for_ML": bool(keep), "reason": reason})
        if keep:
            keep_cols.append(col)
    if not keep_cols:
        raise RuntimeError("Rare-feature filtering removed every ML feature.")
    return X_df[keep_cols].copy(), pd.DataFrame(rows)


def make_full_r2_cv(n_train):
    idx = np.arange(int(n_train))
    return [(idx, idx)]


class LassoOLSLinearEquationRegressor(BaseEstimator, RegressorMixin):
    """OLS equation fitted on original linear descriptors selected by Lasso.

    Workflow:
    1. Standardize original descriptor columns.
    2. Fit Lasso for sparse coefficient/term selection.
    3. Keep terms with |scaled Lasso coefficient| > selection_threshold.
    4. Optionally keep only the strongest max_terms terms.
    5. Refit ordinary least squares on the selected unscaled original descriptors.

    This gives a readable linear empirical equation using original descriptors only.
    It is intentionally separate from the predefined symbolic candidate-term library.
    """

    def __init__(
        self,
        alpha=0.03,
        selection_threshold=1e-4,
        max_terms=20,
        max_iter=200000,
        tol=1e-5,
        random_state=42,
    ):
        self.alpha = alpha
        self.selection_threshold = selection_threshold
        self.max_terms = max_terms
        self.max_iter = max_iter
        self.tol = tol
        self.random_state = random_state

    def fit(self, X, y):
        X_df = pd.DataFrame(X).copy()
        self.feature_names_in_ = list(X_df.columns)
        y_arr = np.asarray(y, dtype=float)

        self.scaler_ = StandardScaler()
        X_scaled = self.scaler_.fit_transform(X_df)

        self.lasso_ = Lasso(
            alpha=float(self.alpha),
            max_iter=int(self.max_iter),
            tol=float(self.tol),
            random_state=int(self.random_state),
            selection="cyclic",
        )
        self.lasso_.fit(X_scaled, y_arr)

        abs_coef = np.abs(np.asarray(self.lasso_.coef_, dtype=float))
        selected_idx = np.where(abs_coef > float(self.selection_threshold))[0]

        if len(selected_idx) == 0:
            # Deterministic fallback: retain the strongest Lasso coefficient if all
            # coefficients are below the user-defined threshold.
            selected_idx = np.array([int(np.argmax(abs_coef))])

        max_terms_int = int(self.max_terms) if self.max_terms is not None else len(self.feature_names_in_)
        max_terms_int = max(1, min(max_terms_int, len(self.feature_names_in_)))
        selected_idx = selected_idx[np.argsort(abs_coef[selected_idx])[::-1]][:max_terms_int]
        selected_idx = np.asarray(sorted(selected_idx), dtype=int)

        self.selected_idx_ = selected_idx
        self.selected_terms_ = [self.feature_names_in_[i] for i in selected_idx]
        self.selected_features_ = self.selected_terms_
        self.lasso_scaled_coef_ = self.lasso_.coef_

        self.ols_model_ = LinearRegression()
        self.ols_model_.fit(X_df[self.selected_terms_], y_arr)
        self.coef_ = np.asarray(self.ols_model_.coef_, dtype=float)
        self.intercept_ = float(self.ols_model_.intercept_)
        return self

    def predict(self, X):
        X_df = pd.DataFrame(X).copy()
        return self.ols_model_.predict(X_df[self.selected_terms_])


class SparseSymbolicRegressor(BaseEstimator, RegressorMixin):
    """Lasso term selection + OLS refit on a predefined symbolic candidate-term library."""

    def __init__(
        self,
        alpha=0.01,
        selection_threshold=1e-8,
        max_terms=8,
        max_iter=1000000,
        tol=1e-4,
        random_state=42,
        refit_ols=True,
        condition_number_limit=1e8,
    ):
        self.alpha = alpha
        self.selection_threshold = selection_threshold
        self.max_terms = max_terms
        self.max_iter = max_iter
        self.tol = tol
        self.random_state = random_state
        self.refit_ols = refit_ols
        self.condition_number_limit = condition_number_limit

    def fit(self, X, y):
        X_df = pd.DataFrame(X).copy()
        self.feature_names_in_ = list(X_df.columns)
        y_arr = np.asarray(y, dtype=float)

        self.scaler_ = StandardScaler()
        X_scaled = self.scaler_.fit_transform(X_df)

        self.lasso_ = Lasso(
            alpha=float(self.alpha),
            max_iter=int(self.max_iter),
            tol=float(self.tol),
            selection="random",
            random_state=int(self.random_state),
        )
        self.lasso_.fit(X_scaled, y_arr)

        abs_coef = np.abs(self.lasso_.coef_)
        selected_idx = np.where(abs_coef > float(self.selection_threshold))[0]
        max_terms_int = int(self.max_terms) if self.max_terms is not None else len(self.feature_names_in_)
        max_terms_int = max(1, min(max_terms_int, len(self.feature_names_in_)))

        if len(selected_idx) == 0:
            correlations = []
            for j in range(X_scaled.shape[1]):
                xj = X_scaled[:, j]
                if np.std(xj) <= 1e-12:
                    corr = 0.0
                else:
                    corr = abs(np.corrcoef(xj, y_arr)[0, 1])
                    if not np.isfinite(corr):
                        corr = 0.0
                correlations.append(corr)
            selected_idx = np.array([int(np.argmax(correlations))])

        # Keep strongest max_terms terms; this preserves the existing merged-script cap values.
        selected_idx = selected_idx[np.argsort(abs_coef[selected_idx])[::-1]][:max_terms_int]
        selected_idx = np.asarray(sorted(selected_idx), dtype=int)

        def condition_number(idx_array):
            if len(idx_array) <= 1:
                return 1.0
            mat = X_df.iloc[:, idx_array].astype(float).values
            mat = mat - np.nanmean(mat, axis=0)
            try:
                cn = float(np.linalg.cond(mat))
            except Exception:
                cn = np.inf
            return cn if np.isfinite(cn) else np.inf

        self.condition_number_before_pruning_ = condition_number(selected_idx)
        pruned_terms = []
        while len(selected_idx) > 1 and condition_number(selected_idx) > float(self.condition_number_limit):
            weakest_local = int(np.argmin(abs_coef[selected_idx]))
            removed_idx = int(selected_idx[weakest_local])
            pruned_terms.append(self.feature_names_in_[removed_idx])
            selected_idx = np.delete(selected_idx, weakest_local)

        self.condition_number_after_pruning_ = condition_number(selected_idx)
        self.pruned_terms_due_to_condition_number_ = pruned_terms
        self.selected_idx_ = selected_idx
        self.selected_terms_ = [self.feature_names_in_[i] for i in selected_idx]

        if self.refit_ols:
            self.ols_model_ = LinearRegression()
            self.ols_model_.fit(X_df[self.selected_terms_], y_arr)
            self.coef_ = self.ols_model_.coef_
            self.intercept_ = self.ols_model_.intercept_
        else:
            self.ols_model_ = None
            self.coef_ = self.lasso_.coef_[selected_idx]
            self.intercept_ = self.lasso_.intercept_
        return self

    def predict(self, X):
        X_df = pd.DataFrame(X).copy()
        if self.refit_ols and self.ols_model_ is not None:
            return self.ols_model_.predict(X_df[self.selected_terms_])
        X_scaled = self.scaler_.transform(X_df)
        pred = np.full(X_scaled.shape[0], self.intercept_, dtype=float)
        pred += X_scaled[:, self.selected_idx_] @ self.coef_
        return pred


def build_original_indicator_library(source, generated_terms):
    categorical_map = {
        "Metal_Pt": "I_Metal_Pt", "Metal_Pd": "I_Metal_Pd",
        "Metal_Ni": "I_Metal_Ni", "Metal_Ru": "I_Metal_Ru",
        "Is_CS-N-n-Propyl-Membrane": "I_Chitosan_N_n_Propyl_Membrane",
        "Is_PVP_clinopti": "I_PVP_Clinoptilolite", "Is_unsupported_metal": "I_unsupported",
        "Is_Carbon": "I_Carbon", "Is_S4NR": "I_S4NR", "Is_P4NR": "I_P4NR",
        "Is_S8NR": "I_S8NR", "Is_M4KR": "I_M4KR", "Is_NY6": "I_NY6",
        "Is_NY3": "I_NY3", "Is_PAA": "I_PAA", "Is_PFT": "I_PFT",
        "Is_PAAO": "I_PAAO", "Is_PAN": "I_PAN",
        "Is_crosslinker_methylene_bisacrylamide": "I_MBA",
        "Is_crosslinker_divinylbenzene": "I_DVB",
        "Is_Zn": "I_Zn", "Is_Crosslinked": "I_crosslinked",
        "Is_water_volume_reported": "I_water_reported",
        "Is_benzene_volume_reported": "I_benzene_reported",
        "Is_pressure_reported": "I_pressure_reported",
        "Is_H2_pressure_reported": "I_H2_pressure_reported",
        "Is_H2/C6H6_ratio_reported": "I_H2_Bz_ratio_reported",
        "Is_Reaction_time_reported": "I_reaction_time_reported",
        "Is_Contact_time_reported": "I_contact_time_reported",
    }
    generated = {k: np.asarray(v).copy() for k, v in generated_terms.items()
                 if not k.startswith("I_")}
    coding_rows = []
    for column, term in categorical_map.items():
        if column not in source.columns:
            continue
        values = source[column].to_numpy(dtype=float)
        if not np.isin(values, [0.0, 1.0]).all():
            raise ValueError(f"Original indicator {column} must contain only 0/1 values")
        generated[term] = values.copy()
        coding_rows.append({
            "source_column": column, "term": term,
            "coding": "original 0/1; no reference recoding",
            "value_1": "reported" if "reported" in term else "category/attribute present",
            "value_0": "not reported" if "reported" in term else "category/attribute absent",
            "count_1": int((values == 1).sum()), "count_0": int((values == 0).sum()),
        })
    candidates = pd.DataFrame(generated, index=source.index).replace(
        [np.inf, -np.inf], np.nan).fillna(0)
    constants = [c for c in candidates if candidates[c].std(ddof=0) <= 1e-12]
    nonconstant = candidates.drop(columns=constants)
    retained = nonconstant.T.drop_duplicates().T.copy()
    screening_rows = []
    for term in candidates:
        if term in constants:
            status, equivalent = "constant removed", ""
        elif term in retained:
            status, equivalent = "retained", ""
        else:
            status = "exact duplicate removed"
            equivalent = next(c for c in retained
                              if np.array_equal(candidates[term].values, retained[c].values))
        screening_rows.append({"term": term, "status": status, "duplicate_of": equivalent})
    screening = pd.DataFrame(screening_rows)
    coding = pd.DataFrame(coding_rows).merge(screening, on="term", how="left")
    return retained, coding, screening


def make_equation_string(intercept, selected_terms, coefficients, target_name="Y_cyclohexane"):
    eqn_local = f"{target_name} = {intercept:.4f}"
    for term, coef in zip(selected_terms, coefficients):
        sign = "+" if coef >= 0 else "-"
        eqn_local += f" {sign} {abs(coef):.4g}·({term})"
    return eqn_local


def make_term_importance(selected_terms, coefficients, terms_df):
    out = pd.DataFrame({
        "term": selected_terms,
        "coefficient": coefficients,
        "term_std": [terms_df[t].std(ddof=0) for t in selected_terms],
    })
    out["abs_scaled_effect"] = np.abs(out["coefficient"] * out["term_std"])
    return out.sort_values("abs_scaled_effect", ascending=False)


def run_workflow(options):
    started = time.perf_counter()
    EQUATION_BO_N_ITER = options.bo_iterations
    EQUATION_BO_CV_SPLITS = options.cv_folds
    BO_SEARCH_N_JOBS = options.jobs
    out_dir = options.output_root / ("filter_on" if options.descriptor_filter else "filter_off") / TARGET_NAME
    out_dir.mkdir(parents=True, exist_ok=True)
    log(f"Input: {options.input}")
    log(f"Target: {TARGET}; exactly three equations; seed 42")
    log(f"Output: {out_dir}")
    df = pd.read_excel(options.input, sheet_name=SHEET_NAME)
    df.columns = [str(c).strip() for c in df.columns]
    if TARGET not in df or "Is_unsupported_metal" not in df:
        raise ValueError(f"Updated workbook must contain {TARGET} and Is_unsupported_metal.")
    df_model = df.dropna(subset=[TARGET]).reset_index(drop=True)
    y = pd.to_numeric(df_model[TARGET], errors="raise")
    if len(y) < 4 or not np.isfinite(y.to_numpy()).all():
        raise ValueError("At least four finite target observations are required.")
    drop_cols = [c for c in [TARGET] + LEAKAGE_COLS + ID_COLS if c in df_model]
    raw = df_model.drop(columns=drop_cols).apply(pd.to_numeric, errors="coerce")
    all_missing = raw.columns[raw.isna().all()].tolist()
    raw = raw.drop(columns=all_missing)
    missing = raw.replace([np.inf,-np.inf], np.nan).isna().sum()
    missing[missing.gt(0)].rename_axis("feature").reset_index(name="count_before_zero_fill").to_csv(
        out_dir / "missing_values_before_zero_fill.csv", index=False)
    X_all = raw.replace([np.inf,-np.inf], np.nan).fillna(0).astype(float)
    if not np.isin(X_all["Is_unsupported_metal"].to_numpy(), [0.,1.]).all():
        raise ValueError("Is_unsupported_metal must be an original 0/1 indicator.")
    if options.descriptor_filter:
        X_ml, filter_report = trim_rare_ml_features(X_all, MIN_BINARY_MINORITY_COUNT, MIN_CONTINUOUS_UNIQUE_VALUES)
    else:
        X_ml = X_all.copy()
        filter_report = pd.DataFrame({"feature":list(X_ml), "kept_for_ML":True, "reason":"descriptor filter disabled"})
    filter_report.to_csv(out_dir / "linear_descriptor_filter_report.csv", index=False)
    X_sym_source = X_all.copy()

    def safe_col(col):
        if col in X_sym_source.columns:
            return X_sym_source[col].astype(float).values
        return None


    def make_equation_bo_cv(n_rows):
        """Reproducible shuffled 5-fold CV used only by the equation workflows."""
        n_cv = min(int(EQUATION_BO_CV_SPLITS), int(n_rows) // 2)
        if n_cv < 2:
            raise ValueError("Equation Bayesian optimization requires at least four observations for R2 scoring.")
        return KFold(
            n_splits=n_cv,
            shuffle=True,
            random_state=EQUATION_BO_RANDOM_STATE,
        ), n_cv


    def evaluate_fixed_equation_5fold(model_factory, params, X_data, model_label):
        """
        Generate reproducible shuffled 5-fold predictions using one globally selected
        hyperparameter set. These folds are independent of the main-model CV_STRATEGY.
        For CV-R2-optimized equations they are tuning-informed; for the Full-R2 equation
        they are a post-selection diagnostic only.
        """
        splitter, n_cv = make_equation_bo_cv(len(y))
        splits = list(splitter.split(X_data, y))

        oof = np.zeros(len(y), dtype=float)
        fold_rows = []
        fold_terms = []

        for fold, (tr, te) in enumerate(splits, 1):
            model = model_factory(params)
            model.fit(X_data.iloc[tr], y.iloc[tr].values)
            pred = model.predict(X_data.iloc[te])
            oof[te] = pred

            m = metrics_safe(y.iloc[te], pred)
            m.update({
                "fold": fold,
                "test_size": len(te),
                "n_selected_terms": len(model.selected_terms_),
                "hyperparameter_source": "single full-data BO; fixed best hyperparameters",
                "equation_cv_basis": f"shuffled {n_cv}-fold KFold; random_state={EQUATION_BO_RANDOM_STATE}",
                "min_pred_in_fold": float(np.min(pred)),
                "max_pred_in_fold": float(np.max(pred)),
            })
            fold_rows.append(m)
            fold_terms.append({
                "fold": fold,
                "model": model_label,
                "selected_terms": ", ".join(model.selected_terms_),
                "n_selected_terms": len(model.selected_terms_),
            })

        return (
            oof,
            pd.DataFrame(fold_terms),
            pd.DataFrame(fold_rows),
            metrics(y, oof),
            n_cv,
        )


    def run_linear_eq_bayes_search(X_data, y_data, context_label):
        if BayesSearchCV is None:
            raise ImportError(
                "Bayesian optimization requires scikit-optimize. "
                "Install it with: python -m pip install scikit-optimize"
            )

        eq_acq_func, eq_acq_kwargs = normalize_acq(
            SYMBOLIC_BO_ACQ_FUNC,
            SYMBOLIC_BO_ACQ_KAPPA,
            SYMBOLIC_BO_ACQ_XI,
        )
        optimizer_kwargs = {
            "acq_func": eq_acq_func,
            "acq_func_kwargs": eq_acq_kwargs,
        }
        cv5, n_cv = make_equation_bo_cv(len(y_data))

        log(
            f"Lasso-OLS BO started for {context_label} | "
            f"objective=5-fold CV R2, n_iter={EQUATION_BO_N_ITER}"
        )
        start = time.perf_counter()

        search = BayesSearchCV(
            estimator=LassoOLSLinearEquationRegressor(
                random_state=42,
                max_iter=LINEAR_EQ_MAX_ITER,
            ),
            search_spaces=linear_eq_search_space_cvr2,
            n_iter=EQUATION_BO_N_ITER,
            scoring="r2",
            cv=cv5,
            n_jobs=BO_SEARCH_N_JOBS,
            random_state=EQUATION_BO_RANDOM_STATE,
            optimizer_kwargs=optimizer_kwargs,
            refit=True,
            verbose=0,
            return_train_score=True,
        )
        search.fit(X_data, y_data)

        elapsed = time.perf_counter() - start
        best_params = safe_param_dict(search.best_params_)
        params = linear_eq_default_params.copy()
        params.update(best_params)
        params.update({"max_iter": LINEAR_EQ_MAX_ITER, "random_state": 42})

        best_score = float(search.best_score_)
        results_df = pd.DataFrame(search.cv_results_).sort_values("rank_test_score")
        results_df["context"] = context_label
        results_df["bo_objective"] = "5fold_cross_validated_R2"
        results_df["model_family"] = "Lasso-selected OLS linear equation"
        results_df["mean_CV_R2"] = results_df["mean_test_score"]
        results_df["std_CV_R2"] = results_df["std_test_score"]

        best_rows = [
            {"context": context_label, "bo_objective": "5fold_cross_validated_R2", "parameter": k, "value": v}
            for k, v in best_params.items()
        ]
        best_rows.extend([
            {"context": context_label, "bo_objective": "5fold_cross_validated_R2", "parameter": "best_mean_5fold_CV_R2", "value": best_score},
            {"context": context_label, "bo_objective": "5fold_cross_validated_R2", "parameter": "cv_description", "value": f"shuffled KFold with {n_cv} folds; random_state={EQUATION_BO_RANDOM_STATE}"},
            {"context": context_label, "bo_objective": "5fold_cross_validated_R2", "parameter": "bo_iterations", "value": EQUATION_BO_N_ITER},
            {"context": context_label, "bo_objective": "5fold_cross_validated_R2", "parameter": "bo_runtime_seconds", "value": elapsed},
            {"context": context_label, "bo_objective": "5fold_cross_validated_R2", "parameter": "search_space", "value": str(linear_eq_search_space_cvr2)},
        ])

        log(f"Lasso-OLS BO complete | best mean 5-fold CV R2={best_score:.4f}")
        return params, results_df, pd.DataFrame(best_rows), best_score, elapsed


    def _symbolic_optimizer_kwargs():
        sym_acq_func, sym_acq_kwargs = normalize_acq(
            SYMBOLIC_BO_ACQ_FUNC,
            SYMBOLIC_BO_ACQ_KAPPA,
            SYMBOLIC_BO_ACQ_XI,
        )
        return {"acq_func": sym_acq_func, "acq_func_kwargs": sym_acq_kwargs}


    def run_symbolic_bayes_search_cvr2(X_terms_data, y_data, context_label):
        if BayesSearchCV is None:
            raise ImportError(
                "Bayesian optimization requires scikit-optimize. "
                "Install it with: python -m pip install scikit-optimize"
            )

        cv5, n_cv = make_equation_bo_cv(len(y_data))
        objective_label = "predefined_symbolic_terms_5fold_CV_R2"
        log(f"Symbolic CV-R2 BO started | n_iter={EQUATION_BO_N_ITER}")
        start = time.perf_counter()

        search = BayesSearchCV(
            estimator=SparseSymbolicRegressor(
                random_state=42,
                refit_ols=True,
                condition_number_limit=SYMBOLIC_CONDITION_NUMBER_LIMIT,
            ),
            search_spaces=symbolic_search_space_cvr2,
            n_iter=EQUATION_BO_N_ITER,
            scoring="r2",
            cv=cv5,
            n_jobs=BO_SEARCH_N_JOBS,
            random_state=EQUATION_BO_RANDOM_STATE,
            optimizer_kwargs=_symbolic_optimizer_kwargs(),
            refit=True,
            verbose=0,
            return_train_score=True,
        )
        search.fit(X_terms_data, y_data)

        elapsed = time.perf_counter() - start
        best_params = safe_param_dict(search.best_params_)
        params = symbolic_default_params.copy()
        params.update(best_params)
        params.update({
            "max_iter": 1000000,
            "random_state": 42,
            "refit_ols": True,
            "condition_number_limit": SYMBOLIC_CONDITION_NUMBER_LIMIT,
        })

        best_score = float(search.best_score_)
        results_df = pd.DataFrame(search.cv_results_).sort_values("rank_test_score")
        results_df["context"] = context_label
        results_df["bo_objective"] = objective_label
        results_df["mean_CV_R2"] = results_df["mean_test_score"]
        results_df["std_CV_R2"] = results_df["std_test_score"]

        best_rows = [
            {"context": context_label, "bo_objective": objective_label, "parameter": k, "value": v}
            for k, v in best_params.items()
        ]
        best_rows.extend([
            {"context": context_label, "bo_objective": objective_label, "parameter": "best_mean_5fold_CV_R2", "value": best_score},
            {"context": context_label, "bo_objective": objective_label, "parameter": "cv_description", "value": f"shuffled KFold with {n_cv} folds; random_state={EQUATION_BO_RANDOM_STATE}"},
            {"context": context_label, "bo_objective": objective_label, "parameter": "bo_iterations", "value": EQUATION_BO_N_ITER},
            {"context": context_label, "bo_objective": objective_label, "parameter": "bo_runtime_seconds", "value": elapsed},
            {"context": context_label, "bo_objective": objective_label, "parameter": "search_space", "value": str(symbolic_search_space_cvr2)},
        ])

        log(f"Symbolic CV-R2 BO complete | best mean 5-fold CV R2={best_score:.4f}")
        return params, results_df, pd.DataFrame(best_rows), best_score, elapsed


    def run_symbolic_bayes_search_fullr2(X_terms_data, y_data, context_label):
        """Single 30-iteration BO maximizing in-sample Full-data R2."""
        if BayesSearchCV is None:
            raise ImportError(
                "Bayesian optimization requires scikit-optimize. "
                "Install it with: python -m pip install scikit-optimize"
            )

        full_r2_cv = make_full_r2_cv(len(y_data))
        objective_label = "predefined_symbolic_terms_Full_data_R2"
        log(f"Symbolic Full-R2 BO started | n_iter={EQUATION_BO_N_ITER}")
        start = time.perf_counter()

        search = BayesSearchCV(
            estimator=SparseSymbolicRegressor(
                random_state=42,
                refit_ols=True,
                condition_number_limit=SYMBOLIC_CONDITION_NUMBER_LIMIT,
            ),
            search_spaces=symbolic_search_space_fullr2,
            n_iter=EQUATION_BO_N_ITER,
            scoring="r2",
            cv=full_r2_cv,
            n_jobs=BO_SEARCH_N_JOBS,
            random_state=EQUATION_BO_RANDOM_STATE,
            optimizer_kwargs=_symbolic_optimizer_kwargs(),
            refit=True,
            verbose=0,
            return_train_score=True,
        )
        search.fit(X_terms_data, y_data)

        elapsed = time.perf_counter() - start
        best_params = safe_param_dict(search.best_params_)
        params = symbolic_default_params.copy()
        params.update(best_params)
        params.update({
            "max_iter": 1000000,
            "random_state": 42,
            "refit_ols": True,
            "condition_number_limit": SYMBOLIC_CONDITION_NUMBER_LIMIT,
        })

        best_score = float(search.best_score_)
        results_df = pd.DataFrame(search.cv_results_).sort_values("rank_test_score")
        results_df["context"] = context_label
        results_df["bo_objective"] = objective_label
        results_df["Full_data_R2"] = results_df["mean_test_score"]

        best_rows = [
            {"context": context_label, "bo_objective": objective_label, "parameter": k, "value": v}
            for k, v in best_params.items()
        ]
        best_rows.extend([
            {"context": context_label, "bo_objective": objective_label, "parameter": "best_Full_data_R2", "value": best_score},
            {"context": context_label, "bo_objective": objective_label, "parameter": "objective_definition", "value": "single in-sample split: train=all rows; score=all rows"},
            {"context": context_label, "bo_objective": objective_label, "parameter": "bo_iterations", "value": EQUATION_BO_N_ITER},
            {"context": context_label, "bo_objective": objective_label, "parameter": "bo_runtime_seconds", "value": elapsed},
            {"context": context_label, "bo_objective": objective_label, "parameter": "search_space", "value": str(symbolic_search_space_fullr2)},
        ])

        log(f"Symbolic Full-R2 BO complete | best Full-data R2={best_score:.4f}")
        return params, results_df, pd.DataFrame(best_rows), best_score, elapsed

    continuous_symbol_map = {
        "Reaction_water_ml": "V_water",
        "Reaction_benzene_ml": "V_benzene",
        "Zn/Ru_g": "Zn_Ru",
        "Crosslinker_mol_%": "CL",
        "Metal_ratio_%": "M",
        "Reaction_temperature_C": "T",
        "Reaction_time_min": "t_react",
        "Contact_time_s": "t_contact",
        "Reaction_Pressure_bar": "P_react",
        "Reaction_H2_pressure_bar": "P_H2",
        "H2_to_Benzene_ratio": "H2_Bz",
        "Preparation_time_h": "t_prep",
        "Preparation_temperature_C": "T_prep",
        "N_n_Propyl_%": "N_propyl_pct",
    }

    term_dict = {}
    for col, sym in continuous_symbol_map.items():
        arr = safe_col(col)
        if arr is not None:
            term_dict[sym] = arr

    transform_cols = [
        ("Reaction_temperature_C", "T"),
        ("Reaction_time_min", "t_react"),
        ("Contact_time_s", "t_contact"),
        ("Metal_ratio_%", "M"),
        ("Reaction_water_ml", "V_water"),
        ("Reaction_benzene_ml", "V_benzene"),
        ("Reaction_Pressure_bar", "P_react"),
        ("H2_to_Benzene_ratio", "H2_Bz"),
    
    ]
    for col, sym in transform_cols:
        arr = safe_col(col)
        if arr is not None:
            arr_nonneg = np.maximum(arr, 0)
            term_dict[f"ln(1+{sym})"] = np.log1p(arr_nonneg)
            term_dict[f"sqrt({sym})"] = np.sqrt(arr_nonneg)
            term_dict[f"{sym}^2"] = arr ** 2

    interactions = [
        ("Metal_ratio_%", "Reaction_temperature_C", "M*T"),
        ("Metal_ratio_%", "Reaction_time_min", "M*t_react"),
        ("Metal_ratio_%", "Contact_time_s", "M*t_contact"),
        ("Reaction_temperature_C", "Reaction_time_min", "T*t_react"),
        ("Reaction_temperature_C", "Contact_time_s", "T*t_contact"),
        ("Reaction_water_ml", "Reaction_time_min", "V_water*t_react"),
        ("Reaction_benzene_ml", "Reaction_time_min", "V_benzene*t_react"),
        ("Reaction_Pressure_bar", "Reaction_temperature_C", "P_react*T"),
        ("H2_to_Benzene_ratio", "Reaction_temperature_C", "H2_Bz*T"),
        ("Zn/Ru_g", "Metal_ratio_%", "Zn_Ru*M"),
        ("Crosslinker_mol_%", "Metal_ratio_%", "CL*M"),
    ]
    for c1, c2, name in interactions:
        a = safe_col(c1)
        b = safe_col(c2)
        if a is not None and b is not None:
            term_dict[name] = a * b

    terms, indicator_coding, library_screening = build_original_indicator_library(X_sym_source, term_dict)
    if terms.empty:
        raise ValueError("The predefined term library is empty after screening.")
    if "I_unsupported" not in terms:
        raise ValueError("The unsupported indicator was constant/duplicated; inspect the updated dataset before fitting.")
    if not np.array_equal(terms["I_unsupported"].to_numpy(), X_all["Is_unsupported_metal"].to_numpy()):
        raise RuntimeError("Unsupported indicator coding changed unexpectedly.")
    indicator_coding.loc[indicator_coding.source_column.eq("Is_unsupported_metal"), "value_1"] = "Unsupported (Powder/Nano-clusters)"
    indicator_coding.loc[indicator_coding.source_column.eq("Is_unsupported_metal"), "value_0"] = "unsupported-metal descriptor absent"
    log(f"Rows: {len(y)}; LASSO-OLS descriptors: {X_ml.shape[1]}; predefined terms: {terms.shape[1]}")

    linear_eq_search_space_cvr2 = {
        "alpha": Real(1e-4, 10.0, prior="log-uniform"),
        "selection_threshold": Real(
            LINEAR_EQ_SELECTION_THRESHOLD_MIN,
            LINEAR_EQ_SELECTION_THRESHOLD_MAX,
            prior="log-uniform",
        ),
        "max_terms": Integer(1, max(2, min(LINEAR_EQ_MAX_TERMS_CAP, X_ml.shape[1]))),
        "tol": Real(1e-6, 1e-3, prior="log-uniform"),
    }

    linear_eq_default_params = {
        "alpha": LINEAR_EQ_BASE_ALPHA,
        "selection_threshold": LINEAR_EQ_SELECTION_THRESHOLD,
        "max_terms": min(LINEAR_EQ_MAX_TERMS_CAP, max(1, X_ml.shape[1])),
        "max_iter": LINEAR_EQ_MAX_ITER,
        "tol": LINEAR_EQ_TOL,
        "random_state": 42,
    }

    symbolic_search_space_cvr2 = {
        "alpha": Real(SYMBOLIC_CVR2_ALPHA_MIN, 1.0, prior="log-uniform"),
        "selection_threshold": Real(SYMBOLIC_SELECTION_THRESHOLD_MIN, 1e-3, prior="log-uniform"),
        "max_terms": Integer(1, max(2, min(SYMBOLIC_CVR2_MAX_TERMS_CAP, terms.shape[1]))),
        "tol": Real(1e-5, 1e-3, prior="log-uniform"),
    }

    symbolic_search_space_fullr2 = {
        "alpha": Real(SYMBOLIC_FULLR2_ALPHA_MIN, 1.0, prior="log-uniform"),
        "selection_threshold": Real(1e-6, 1e-3, prior="log-uniform"),
        "max_terms": Integer(1, max(2, min(SYMBOLIC_FULLR2_MAX_TERMS_CAP, terms.shape[1]))),
        "tol": Real(1e-5, 1e-3, prior="log-uniform"),
    }

    symbolic_default_params = {
        "alpha": 0.01,
        "selection_threshold": SYMBOLIC_SELECTION_THRESHOLD_MIN,
        "max_terms": min(8, max(1, terms.shape[1])),
        "max_iter": 1000000,
        "tol": 1e-4,
        "random_state": 42,
        "refit_ols": True,
        "condition_number_limit": SYMBOLIC_CONDITION_NUMBER_LIMIT,
    }

    definitions = []
    for column, symbol in continuous_symbol_map.items():
        if column in X_sym_source:
            definitions.append({"term":symbol,"definition":column,"source_columns":column})
    for column, symbol in transform_cols:
        if column in X_sym_source:
            definitions.extend([
                {"term":f"ln(1+{symbol})","definition":f"ln(1 + max({column}, 0))","source_columns":column},
                {"term":f"sqrt({symbol})","definition":f"sqrt(max({column}, 0))","source_columns":column},
                {"term":f"{symbol}^2","definition":f"({column})^2","source_columns":column}])
    for c1,c2,name in interactions:
        if c1 in X_sym_source and c2 in X_sym_source:
            definitions.append({"term":name,"definition":f"{c1} * {c2}","source_columns":f"{c1}; {c2}"})
    for row in indicator_coding.itertuples():
        definitions.append({"term":row.term,"definition":f"original 0/1 value of {row.source_column}","source_columns":row.source_column})
    term_definitions = pd.DataFrame(definitions).merge(library_screening, on="term", how="left")
    term_definitions.to_csv(out_dir / "predefined_term_definitions.csv", index=False)
    indicator_coding.to_csv(out_dir / "predefined_indicator_coding.csv", index=False)
    library_screening.to_csv(out_dir / "predefined_library_screening.csv", index=False)
    terms.to_csv(out_dir / "predefined_candidate_library.csv", index=True, index_label="row_index")
    X_ml.to_csv(out_dir / "linear_equation_processed_features.csv", index=True, index_label="row_index")

    results = []
    specifications = [
        ("equation_1", "LASSO-OLS | BO five-fold CV R2", "CV_R2", X_ml,
         LassoOLSLinearEquationRegressor, run_linear_eq_bayes_search),
        ("equation_2", "Predefined terms | BO five-fold CV R2", "CV_R2", terms,
         SparseSymbolicRegressor, run_symbolic_bayes_search_cvr2),
        ("equation_3", "Predefined terms | BO full-data R2", "FULL_DATA_R2", terms,
         SparseSymbolicRegressor, run_symbolic_bayes_search_fullr2),
    ]
    for equation_id, label, objective, matrix, estimator_class, search in specifications:
        log(f"Starting {equation_id}: {label}")
        params, trials, best, best_score, duration = search(matrix, y.values, equation_id)
        oof, fold_terms, fold_metrics, cv_metrics, n_cv = evaluate_fixed_equation_5fold(
            lambda p: estimator_class(**p), params, matrix, label)
        model = estimator_class(**params)
        model.fit(matrix, y.values)
        full_pred = model.predict(matrix)
        full_metrics = metrics(y, full_pred)
        importance = make_term_importance(model.selected_terms_, model.coef_, matrix)
        equation = make_equation_string(model.intercept_, model.selected_terms_, model.coef_)
        full_precision = make_full_precision_equation(model.intercept_, model.selected_terms_, model.coef_)
        importance.to_csv(out_dir / f"{equation_id}_coefficients.csv", index=False)
        trials.to_csv(out_dir / f"{equation_id}_BO_trials.csv", index=False)
        best.to_csv(out_dir / f"{equation_id}_BO_best_parameters.csv", index=False)
        fold_terms.to_csv(out_dir / f"{equation_id}_five_fold_selected_terms.csv", index=False)
        fold_metrics.to_csv(out_dir / f"{equation_id}_five_fold_metrics.csv", index=False)
        results.append({"id":equation_id,"label":label,"objective":objective,"matrix":matrix,
                        "model":model,"params":params,"trials":trials,"best":best,"best_score":best_score,
                        "duration":duration,"oof":oof,"full_pred":full_pred,"cv_metrics":cv_metrics,
                        "full_metrics":full_metrics,"n_cv":n_cv,"fold_terms":fold_terms,"fold_metrics":fold_metrics,
                        "importance":importance,"equation":equation,"equation_full_precision":full_precision})
        log(f"Completed {equation_id}: pooled diagnostic R2={cv_metrics['R2']:.4f}; full-data R2={full_metrics['R2']:.4f}")

    save_equation_outputs(results, df_model, y, X_all, X_ml, terms, options, out_dir, started)
    plot_equation_results(results, y, out_dir)
    if Path(__file__).resolve().is_file():
        shutil.copy2(__file__, out_dir / Path(__file__).name)
    log(f"Saved exactly three regression equations to {out_dir}")
    return out_dir


def make_full_precision_equation(intercept, selected_terms, coefficients):
    text = f"Y_{TARGET_NAME} = {float(intercept):.17g}"
    for name, coefficient in zip(selected_terms, coefficients):
        text += f" {'+' if coefficient >= 0 else '-'} {abs(float(coefficient)):.17g} * ({name})"
    return text


def save_equation_outputs(results, df_model, y, X_all, X_ml, terms, options, out_dir, started):
    summaries, metrics_rows, params_rows, fold_frames, selection_frames, trial_frames = [], [], [], [], [], []
    predictions = df_model[[c for c in ID_COLS if c in df_model]].copy()
    predictions.insert(0, "row_index", np.arange(len(y)))
    predictions[TARGET] = y.to_numpy()
    report_sections = []
    for result in results:
        model = result["model"]
        coding = "original_descriptors" if result["id"] == "equation_1" else "original_0_1_indicators"
        summaries.append({"equation_id":result["id"],"model":result["label"],"BO_objective":result["objective"],
                          "BO_objective_score":result["best_score"],"equation":result["equation"],
                          "equation_full_precision":result["equation_full_precision"],
                          "intercept":float(model.intercept_),"n_selected_terms":len(model.selected_terms_),
                          "selected_terms":json.dumps(list(model.selected_terms_)),"indicator_coding":coding})
        metrics_rows.append({"equation_id":result["id"],"model":result["label"],
                             "BO_objective":result["objective"],"BO_objective_score":result["best_score"],
                             "seed":42,"n_rows":len(y),"n_folds":result["n_cv"],
                             "n_selected_terms":len(model.selected_terms_),
                             "lasso_iterations":int(model.lasso_.n_iter_),
                             "lasso_iteration_limit":int(model.max_iter),
                             "lasso_reached_iteration_limit":bool(model.lasso_.n_iter_ >= model.max_iter),
                             "lasso_dual_gap":float(model.lasso_.dual_gap_),
                             **{f"pooled_five_fold_{k}":v for k,v in result["cv_metrics"].items()},
                             **{f"full_data_{k}":v for k,v in result["full_metrics"].items()},
                             "five_fold_interpretation":"tuning-informed diagnostic; globally selected hyperparameters",
                             "full_data_interpretation":"in-sample fit"})
        predictions[f"{result['id']}_OOF_prediction_%"] = result["oof"]
        predictions[f"{result['id']}_full_data_prediction_%"] = result["full_pred"]
        for name,value in result["params"].items():
            params_rows.append({"equation_id":result["id"],"parameter":name,"value":value})
        for frame, collection in ((result["fold_metrics"],fold_frames), (result["fold_terms"],selection_frames),
                                  (result["trials"],trial_frames)):
            copy = frame.copy()
            copy.insert(0,"equation_id",result["id"])
            collection.append(copy)
        section = (f"{result['id']}: {result['label']}\n"
                   f"BO objective: {result['objective']}; score: {result['best_score']:.8g}\n"
                   f"{result['equation']}\n\nFull-precision equation:\n{result['equation_full_precision']}\n"
                   f"\nApplied parameters:\n{json.dumps(result['params'],indent=2,default=str)}\n"
                   f"\nFull-precision coefficients (excluding intercept above):\n{result['importance'].to_string(index=False)}\n")
        (out_dir / f"{result['id']}.txt").write_text(section,encoding="utf-8")
        report_sections.append(section)
    pd.DataFrame(summaries).to_csv(out_dir / "three_equations.csv",index=False)
    pd.DataFrame(metrics_rows).to_csv(out_dir / "equation_metrics.csv",index=False)
    pd.DataFrame(params_rows).to_csv(out_dir / "applied_hyperparameters.csv",index=False)
    predictions.to_csv(out_dir / "OOF_and_full_data_predictions.csv",index=False)
    pd.concat(fold_frames,ignore_index=True).to_csv(out_dir / "five_fold_metrics_all_equations.csv",index=False)
    pd.concat(selection_frames,ignore_index=True).to_csv(out_dir / "five_fold_selected_terms_all_equations.csv",index=False)
    pd.concat(trial_frames,ignore_index=True).to_csv(out_dir / "BO_trials_all_equations.csv",index=False)
    (out_dir / "three_equations.txt").write_text("\n\n".join(report_sections),encoding="utf-8")
    (out_dir / "optimized_hyperparameters.json").write_text(json.dumps(
        {r["id"]:r["params"] for r in results},indent=2,default=str),encoding="utf-8")
    split_plan = [{"fold":fold,"train_indices":tr.tolist(),"test_indices":te.tolist()}
                  for fold,(tr,te) in enumerate(KFold(n_splits=results[0]["n_cv"],shuffle=True,random_state=42).split(X_all),1)]
    (out_dir / "five_fold_splits_seed42.json").write_text(json.dumps(split_plan,indent=2),encoding="utf-8")
    meta = {"target":TARGET_NAME,"input_file":str(options.input.resolve()),
            "workbook_sha256":hashlib.sha256(options.input.read_bytes()).hexdigest(),
            "script_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            "equation_count":3,"seed":42,"BO_iterations_per_equation":options.bo_iterations,
            "cv_folds":results[0]["n_cv"],"linear_descriptor_filter":options.descriptor_filter,
            "n_rows":len(y),"n_linear_features":X_ml.shape[1],"n_predefined_terms":terms.shape[1],
            "predefined_indicator_coding":"original 0/1 values; no reference-category recoding",
            "unsupported_source":"Is_unsupported_metal","unsupported_term":"I_unsupported",
            "bo_acquisition":SYMBOLIC_BO_ACQ_FUNC,"bo_kappa":SYMBOLIC_BO_ACQ_KAPPA,"bo_xi":SYMBOLIC_BO_ACQ_XI,
            "elapsed_fitting_seconds":time.perf_counter()-started}
    (out_dir / "run_metadata.json").write_text(json.dumps(meta,indent=2),encoding="utf-8")
    report = (f"Three regression equations: {TARGET_LABEL}\n\n"
              f"Rows: {len(y)}; seed: 42; BO iterations per equation: {options.bo_iterations}\n"
              f"Equation 1 uses {X_ml.shape[1]} original descriptors after the configured frequency filter.\n"
              f"Equations 2 and 3 share {terms.shape[1]} predefined numeric/interaction and original-0/1 indicator terms.\n"
              "I_unsupported = Is_unsupported_metal (1: Unsupported (Powder/Nano-clusters); 0: descriptor absent).\n"
              "No categorical state is preassigned or subtracted. Constant/duplicate screening and condition-number pruning remain.\n"
              "No extra machine-learning model comparisons or mean-reference models are evaluated.\n\n"
              "Interpretation of scores:\n"
              "Equations 1 and 2 maximize mean shuffled five-fold validation R2. Their reported pooled OOF R2 is a different aggregation.\n"
              "Equation 3 maximizes R2 on all training rows (in-sample); its five-fold scores are a separate post-selection diagnostic.\n"
              "All equation hyperparameters are selected using the complete dataset. Five-fold diagnostics are tuning-informed, not nested validation.\n"
              "Within each diagnostic fold, Lasso selection and OLS refitting use training rows only; terms and coefficients can differ by fold.\n"
              "The final three displayed equations are fitted on all rows. Raw predictions are saved without clipping to 0-100.\n"
              "Full-precision coefficients and intercepts reproduce the saved full-data predictions.\n\n"
              + pd.DataFrame(metrics_rows).to_string(index=False) + "\n\n" + "\n\n".join(report_sections))
    (out_dir / "analysis_report.txt").write_text(report,encoding="utf-8")


def plot_equation_results(results, y, out_dir):
    plt.rcParams.update({"font.family":"DejaVu Sans","font.size":11,"axes.labelsize":11,"axes.titlesize":12})
    colors = ("tab:green","tab:purple","tab:brown")
    titles = ("LASSO-OLS\nCV R² objective", "Predefined terms\nCV R² objective", "Predefined terms\nFull-data R² objective")
    for mode,filename,suptitle in (
        ("oof","01_three_equations_OOF_vs_Actual","Five-fold OOF predictions (tuning-informed diagnostics)"),
        ("full_pred","02_three_equations_full_fit_vs_Actual","Full-data fitted predictions"),
    ):
        fig, axes = plt.subplots(1,3,figsize=(19,6.3))
        for i,(ax,result,color,title) in enumerate(zip(axes,results,colors,titles)):
            prediction = np.asarray(result[mode],dtype=float)
            actual = np.asarray(y,dtype=float)
            lo,hi = float(min(actual.min(),prediction.min())),float(max(actual.max(),prediction.max()))
            pad = .05*(hi-lo) if hi>lo else 1.
            ax.scatter(actual,prediction,s=35,alpha=.8,color=color,edgecolor="black",linewidth=.35)
            ax.plot([lo-pad,hi+pad],[lo-pad,hi+pad],"--",color="black",linewidth=1)
            ax.set(xlim=(lo-pad,hi+pad),ylim=(lo-pad,hi+pad),xlabel=f"Actual {TARGET_LABEL.lower()}",title=f"({chr(97+i)}) {title}")
            if i==0:
                ax.set_ylabel(f"{'OOF predicted' if mode=='oof' else 'Full-data fitted'} yield (%)")
            score = result["cv_metrics"] if mode=="oof" else result["full_metrics"]
            ax.text(.04,.96,f"R² = {score['R2']:.3f}\nMAE = {score['MAE']:.3f}\nRMSE = {score['RMSE']:.3f}",
                    transform=ax.transAxes,va="top",fontsize=10,bbox=dict(facecolor="white",edgecolor="gray",alpha=.9))
            ax.grid(alpha=.18)
        fig.suptitle(f"{TARGET_LABEL}\n{suptitle}",fontsize=16)
        fig.tight_layout(rect=(0,0,1,.9))
        for suffix in ("png","pdf"):
            fig.savefig(out_dir / f"{filename}.{suffix}",dpi=300,bbox_inches="tight")
        plt.close(fig)
    fig,axes = plt.subplots(1,3,figsize=(22,9))
    for i,(ax,result,color,title) in enumerate(zip(axes,results,colors,titles)):
        data = result["importance"].sort_values("abs_scaled_effect")
        labels = [textwrap.fill(str(name).replace("Is_unsupported_metal","Unsupported binary"),width=28) for name in data.term]
        ax.barh(labels,data.coefficient,color=color,edgecolor="black",linewidth=.4,alpha=.85)
        ax.axvline(0,color="black",linestyle="--",linewidth=1)
        ax.set(title=f"({chr(97+i)}) {title}",xlabel="Coefficient in final equation")
        ax.tick_params(axis="y",labelsize=8.5)
        ax.grid(axis="x",alpha=.18)
    fig.suptitle(f"Final equation coefficients: {TARGET_LABEL}",fontsize=16)
    fig.tight_layout(rect=(0,0,1,.94),w_pad=3)
    for suffix in ("png","pdf"):
        fig.savefig(out_dir / f"03_three_equations_coefficients.{suffix}",dpi=300,bbox_inches="tight")
    plt.close(fig)


def parse_options():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input",type=Path,default=INPUT_FILE)
    parser.add_argument("--output-root",type=Path,default=RESULTS_ROOT)
    parser.add_argument("--bo-iterations",type=int,default=EQUATION_BO_N_ITER)
    parser.add_argument("--cv-folds",type=int,default=EQUATION_BO_CV_SPLITS)
    parser.add_argument("--jobs",type=int,default=BO_SEARCH_N_JOBS)
    parser.add_argument("--descriptor-filter",action=argparse.BooleanOptionalAction,default=APPLY_RARE_FEATURE_FILTER_TO_ML)
    options = parser.parse_args()
    if not options.input.is_file():
        parser.error(f"Updated workbook not found: {options.input}")
    if options.bo_iterations<1 or options.cv_folds<2 or options.jobs==0:
        parser.error("BO iterations must be positive, CV folds >=2, and jobs nonzero.")
    return options


if __name__ == "__main__":
    with threadpool_limits(limits=1):
        run_workflow(parse_options())
