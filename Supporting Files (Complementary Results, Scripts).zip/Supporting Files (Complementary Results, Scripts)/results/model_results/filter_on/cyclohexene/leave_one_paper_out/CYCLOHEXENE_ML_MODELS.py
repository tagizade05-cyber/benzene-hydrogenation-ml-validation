"""Evaluate cyclohexene yield regression with cross-validation.

Models: training-mean baseline, XGBoost, Gaussian process regression (GPR),
and ordinary least squares (OLS). XGBoost and GPR are compared with fixed,
non-nested Bayesian-optimised and nested Bayesian-optimised parameters.

Place the workbook beside this script, edit Configuration below,
then execute: python CYCLOHEXENE_ML_MODELS.py
Results: results/model_results/<filter_on|filter_off>/cyclohexene/<CV_STRATEGY>/
All tabular results are included in that text file; figures are PNG files.
Dependencies are listed in requirements.txt. See README.txt for setup.
"""

import os
from workflow_common import (parse_training_options, export_plot_inputs,
    generate_learning_curves, format_mean_sd)
from plot_dataset_composition import plot_dataset_composition
import re
import json
import warnings
import time
import atexit
import shutil
from pathlib import Path
from datetime import datetime

warnings.filterwarnings("ignore")
import seaborn as sns
import numpy as np
import pandas as pd

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from sklearn.model_selection import KFold, GroupKFold, LeaveOneOut, LeaveOneGroupOut
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import StandardScaler
from sklearn.base import BaseEstimator, RegressorMixin
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import ConstantKernel, RBF, Matern, WhiteKernel

import xgboost as xgb
import shap

try:
    from skopt import BayesSearchCV
    from skopt.space import Real, Integer
except ImportError:
    BayesSearchCV = None
    Real = None
    Integer = None

# -----------------------
# Runtime logging
# -----------------------
RUN_START = time.perf_counter()
RUN_COMPLETED = False


def elapsed_seconds():
    """Return the elapsed wall-clock time since script startup."""
    return time.perf_counter() - RUN_START


def log(message):
    """Print a timestamped progress message and elapsed time."""
    print(f"[{datetime.now():%Y-%m-%d %H:%M:%S}] +{elapsed_seconds():8.2f}s | {message}", flush=True)


def format_runtime(seconds):
    return f"{seconds:.2f} s ({seconds/60:.2f} min)"


def _runtime_on_abnormal_exit():
    if not RUN_COMPLETED:
        print(
            f"[{datetime.now():%Y-%m-%d %H:%M:%S}] +{elapsed_seconds():8.2f}s | "
            f"Script stopped before normal completion. Runtime: {format_runtime(elapsed_seconds())}",
            flush=True,
        )


atexit.register(_runtime_on_abnormal_exit)

# -----------------------
# Configuration: input data and validation design
# -----------------------
# Start Python from the folder containing the workbook. All paths below are
# relative to that current working folder, including when using an IDE.
SCRIPT_DIR = Path(__file__).resolve().parent
INPUT_FILE = SCRIPT_DIR / "DATA_ML_Benzene_Hydrogenation.xlsx"
SHEET_NAME = "FullDataset"  # Excel worksheet containing one experiment per row.

# Choose the outer cross-validation (CV) design before comparing models:
#   "kfold_5": shuffled row-wise folds. Use for a within-dataset benchmark;
#       related experiments from one catalyst or study can occur in both sets.
#   "groupkfold_catalyst": hold out complete Catalyst_ID2 groups. Use to assess
#       transfer to catalyst groups absent from training. Every row needs a
#       valid Catalyst_ID2; at least two distinct groups are required.
#   "leave_one_out": hold out one experiment at a time (LOOCV). Each row is
#       tested once, but related rows can remain in training. Cost grows with
#       the number of rows, especially with nested optimisation.
#   "leave_one_paper_out": hold out one literature-source group at a time
#       (LOPO). Use to assess transfer across studies. Labels are taken from
#       the first non-empty field in Author, Source_study, Reference, Paper.
#       Ensure this priority identifies one publication consistently: author
#       names alone may combine papers, and inconsistent fields may split one.
#       Rows without any source label become separate one-row groups; inspect
#       the reported group labels before interpreting the result as paper CV.
CV_STRATEGY = "leave_one_paper_out"  # kfold_5, groupkfold_catalyst, leave_one_out, leave_one_paper_out

# Used only by kfold_5 and groupkfold_catalyst; reduced when there are fewer
# rows or groups. Keep 5 for five-fold CV. LOOCV and LOPO ignore this setting.
# The option name kfold_5 is retained even if N_SPLITS is changed.
N_SPLITS = 5

# Repeat the entire fitting/tuning procedure with these seeds. The first seed
# supplies the detailed plots and reference tables. Use at least two distinct
# seeds for a sample standard deviation; more seeds increase computing time.
# Grouped/LOOCV/LOPO outer folds are deterministic; shuffled folds vary by seed.
RUN_SEEDS = [42] if CV_STRATEGY == "leave_one_out" else [42, 101, 202, 303, 404]
N_SEED_REPEATS = len(RUN_SEEDS)
KFOLD_RANDOM_STATE = RUN_SEEDS[0]

# Target values are yield percentages. Exclude other measured outcomes and
# identifiers from predictors to avoid using outputs as explanatory variables.
TARGET = "Cyclohexene_yield_%"
TARGET_NAME = "cyclohexene"  # Filename stem and target output folder.
LEAKAGE_COLS = [
    "Benzene_conversion_%",
    "Selectivity_to_cyclohexane_%",
    "Selectivity_to_cyclohexene_%",
    "Cyclohexane_yield_%",
]
ID_COLS = [
    "Author", "Source_study", "Reference", "Paper", "Experiment_ID",
    "Catalyst_ID2", "Catalyst_ID", "Catalyst", "Metal",
]

# True performs Bayesian optimisation (BO) for that model. False reuses the
# fixed base parameters in the corresponding BO-labelled comparisons; those
# comparisons must then be interpreted as untuned fits. OLS is always untuned.
RUN_XGB_BAYES_OPT = True
RUN_GPR_BAYES_OPT = True

# Each BO search evaluates BO_N_ITER configurations and maximises inner-CV R2.
# Inner CV uses shuffled row-wise KFold, including when outer CV is
# grouped. BO_CV_SPLITS is capped at half the training-row count. Choose it so every
# inner validation fold has at least two rows; R2 is undefined for one row.
# Increasing iterations/folds/seeds increases cost. Nested BO repeats the
# search separately inside every outer training fold.
BO_N_ITER = 20
BO_CV_SPLITS = 5
BO_RANDOM_STATE = RUN_SEEDS[0]

# Acquisition function used to select the next hyperparameter configuration:
#   "EI": expected improvement; "PI": probability of improvement.
#   "LCB": lower confidence bound; "UCB" is accepted as an alias for LCB
#       because scikit-optimize minimises the negative model score.
#   "gp_hedge": adaptively combines EI, PI and LCB using library defaults.
# Larger xi (EI/PI) or kappa (LCB/UCB) favours exploration. This script passes
# xi only for EI/PI and kappa only for LCB/UCB; neither is passed for gp_hedge.
ML_BO_ACQ_FUNC = "EI"
ML_BO_ACQ_KAPPA = 3.0
ML_BO_ACQ_XI = 0.05

# 1 uses one CPU worker; -1 uses all available workers. Keeping XGBoost at one
# worker during parallel BO reduces competing layers of CPU parallelism.
XGB_N_JOBS_DURING_BO = 1
XGB_N_JOBS_FINAL = -1
BO_SEARCH_N_JOBS = -1

# GPR kernel family (held fixed during BO):
#   "RBF": a very smooth response function.
#   "MATERN_1.5": a less smooth response function.
#   "MATERN_2.5": smoother than MATERN_1.5, less smooth than RBF.
# Select the smoothness assumption before evaluation; kernel-family selection
# using outer-test scores would add another tuning step outside this script.
# Covariance = ConstantKernel * selected kernel + WhiteKernel. BO varies the
# amplitude, length scale and white-noise level in gpr_search_space below.
# Feature scaling is fitted separately within each model's training data.
GPR_KERNEL = "RBF"

# Fixed diagonal variance added to the GPR covariance matrix; it supplements
# the WhiteKernel noise variance and can improve numerical stability. It is
# not tuned. With normalize_y=True, these variances use normalised-y units.
GPR_ALPHA_FIXED = 1e-3

# Remove binary descriptors with too few zeros or ones, and other descriptors
# with too few distinct values. This target-independent filter is applied once
# to the full predictor table BEFORE CV; it is not refitted inside each fold.
# Set False to retain all numeric descriptors after missing-value processing.
APPLY_RARE_FEATURE_FILTER_TO_ML = True #False if you want to disable descriptor filtering. The filter is applied to the full dataset before CV, and it is not refitted inside each fold.
MIN_BINARY_MINORITY_COUNT = 3
MIN_CONTINUOUS_UNIQUE_VALUES = 3

# Results are written to TARGET/CV_STRATEGY under the current working folder.
# Repeating the same target/strategy replaces files with the same names; save
# a separate copy before comparing different kernels or configuration values.
# The text report always contains the summary and all detailed result tables.
# Set SAVE_CSV_TABLES=False to omit optional audit CSVs. Plot-input CSVs are always saved.
SAVE_CSV_TABLES = True
# These options can also be selected on the command line; see README.md.
RUN_LEARNING_CURVES = True
LEARNING_TRAIN_FRACTIONS = [0.2, 0.4, 0.6, 0.8, 1.0]
OPTIONS = parse_training_options(
    SCRIPT_DIR, CV_STRATEGY, APPLY_RARE_FEATURE_FILTER_TO_ML,
    RUN_LEARNING_CURVES, BO_N_ITER, BO_CV_SPLITS,
)
INPUT_FILE = OPTIONS.input
CV_STRATEGY = OPTIONS.cv
APPLY_RARE_FEATURE_FILTER_TO_ML = OPTIONS.descriptor_filter
# LOO learning curves are deferred even if --learning-curves is supplied.
# The original model evaluations/tuning still run once and supply all model plots.
LOO_LEARNING_CURVES_DEFERRED = CV_STRATEGY == "leave_one_out"
RUN_LEARNING_CURVES = OPTIONS.learning_curves and not LOO_LEARNING_CURVES_DEFERRED
BO_N_ITER = OPTIONS.bo_iterations
BO_CV_SPLITS = OPTIONS.inner_folds
BO_SEARCH_N_JOBS = OPTIONS.jobs
RUN_SEEDS = [42] if CV_STRATEGY == "leave_one_out" else [42, 101, 202, 303, 404]
N_SEED_REPEATS = len(RUN_SEEDS)
KFOLD_RANDOM_STATE = BO_RANDOM_STATE = 42
FILTER_CASE = "filter_on" if APPLY_RARE_FEATURE_FILTER_TO_ML else "filter_off"
OUTPUT_ROOT = OPTIONS.output_root
OUT_DIR = OUTPUT_ROOT / "model_results" / FILTER_CASE / TARGET_NAME / CV_STRATEGY
RESULTS_FILE = OUT_DIR / f"{TARGET_NAME}_results_{CV_STRATEGY}.txt"
OUT_DIR.mkdir(parents=True, exist_ok=True)

# Store table snapshots for the consolidated text report.
RESULT_TABLES = []


def collect_result_table(table, csv_filename):
    """Collect a complete table for the text report and optionally export CSV."""
    RESULT_TABLES.append((Path(csv_filename).stem, table.copy()))
    if SAVE_CSV_TABLES:
        table.to_csv(OUT_DIR / csv_filename, index=False)


def write_results_report(summary):
    """Write the summary and untruncated, tab-delimited tables as UTF-8 text."""
    with RESULTS_FILE.open("w", encoding="utf-8", newline="") as results_file:
        results_file.write(summary + "\n\n")
        results_file.write("DETAILED RESULT TABLES\n" + "=" * 72 + "\n")
        results_file.write(
            "Tables below are tab-delimited and include every row and column.\n"
            "row_index and test_row_indices refer to the zero-based model table\n"
            "after rows with missing target values have been removed.\n"
        )
        for table_name, table in RESULT_TABLES:
            results_file.write(f"\n[{table_name}]\n")
            if table.empty:
                results_file.write("No rows available for this configuration.\n")
            else:
                table.to_csv(results_file, sep="\t", index=False, na_rep="NA")

# -----------------------
# General helpers
# -----------------------
def metrics(y_true, y_pred):
    """Calculate pooled R2, MAE and RMSE; return NaN R2 for a single row."""
    y_true = np.asarray(y_true, dtype=float)
    y_pred = np.asarray(y_pred, dtype=float)
    r2 = np.nan
    if len(y_true) >= 2:
        r2 = float(r2_score(y_true, y_pred))
    return {
        "R2": r2,
        "MAE": float(mean_absolute_error(y_true, y_pred)),
        "RMSE": float(np.sqrt(mean_squared_error(y_true, y_pred))),
    }


def metrics_safe(y_true, y_pred):
    return metrics(y_true, y_pred)


def configure_acquisition_function(acq_func, kappa, xi):
    """Translate the BO acquisition setting into scikit-optimize arguments."""
    acq = str(acq_func).upper()
    if acq == "UCB":
        # scikit-optimize uses LCB for UCB-style exploration under minimisation.
        acq = "LCB"
    allowed = {"LCB", "PI", "EI", "GP_HEDGE"}
    if acq not in allowed:
        raise ValueError("Acquisition function must be one of: LCB, UCB, PI, EI, gp_hedge")
    if acq == "GP_HEDGE":
        acq = "gp_hedge"
    kwargs = {}
    if acq == "LCB":
        kwargs["kappa"] = kappa
    elif acq in ["PI", "EI"]:
        kwargs["xi"] = xi
    return acq, kwargs


def safe_param_dict(params):
    """Convert NumPy scalar hyperparameters to native Python values."""
    out = {}
    for k, v in params.items():
        if hasattr(v, "item"):
            v = v.item()
        out[k] = v
    return out


def trim_rare_ml_features(X_df, min_binary_minority_count=3, min_continuous_unique_values=3):
    """Target-independent feature filter for ML models only."""
    X_df = pd.DataFrame(X_df).copy()
    keep_cols = []
    rows = []
    for col in X_df.columns:
        s = pd.to_numeric(X_df[col], errors="coerce")
        finite = s.replace([np.inf, -np.inf], np.nan).dropna()
        unique_vals = np.sort(finite.unique())
        is_binary = len(unique_vals) <= 2 and set(unique_vals).issubset({0, 1})
        if is_binary:
            count_0 = int((s == 0).sum())
            count_1 = int((s == 1).sum())
            minority = min(count_0, count_1)
            keep = minority >= int(min_binary_minority_count)
            reason = f"binary counts: 0={count_0}, 1={count_1}, minority={minority}, required={min_binary_minority_count}"
        else:
            n_unique = int(finite.nunique())
            keep = n_unique >= int(min_continuous_unique_values)
            reason = f"non-binary unique finite values={n_unique}, required={min_continuous_unique_values}"
        rows.append({"feature": col, "kept_for_ML": bool(keep), "reason": reason})
        if keep:
            keep_cols.append(col)
    if not keep_cols:
        raise RuntimeError("Rare-feature filtering removed every ML feature.")
    return X_df[keep_cols].copy(), pd.DataFrame(rows)


def build_inner_tuning_folds(n_train, fold_count, random_state=42):
    """Build shuffled row-wise folds for hyperparameter selection."""
    n_inner = min(int(fold_count), int(n_train) // 2)
    if n_inner < 2:
        raise ValueError("At least four training rows are needed for inner Bayesian optimization CV scored by R2.")
    return KFold(n_splits=n_inner, shuffle=True, random_state=random_state), n_inner


def build_group_labels(df_in, candidate_cols, fallback_prefix):
    """Choose the first valid source label per row, or a unique row label."""
    labels = []
    used_counts = {c: 0 for c in candidate_cols if c in df_in.columns}
    for pos, (_, row) in enumerate(df_in.iterrows()):
        label = None
        used_col = None
        for c in candidate_cols:
            if c not in df_in.columns:
                continue
            raw = row[c]
            if pd.notna(raw):
                raw_str = str(raw).strip()
                if raw_str and raw_str.lower() not in {"nan", "none", "na", "n/a"}:
                    label = f"{c}:{raw_str}"
                    used_col = c
                    break
        if label is None:
            label = f"{fallback_prefix}_unique_row_{pos}"
        labels.append(label)
        if used_col is not None:
            used_counts[used_col] += 1
    return np.asarray(labels, dtype=object), used_counts


# -----------------------
# Estimator classes
# -----------------------
class TunableGPR(BaseEstimator, RegressorMixin):
    """Standardized Gaussian Process Regression with BO-tunable kernel parameters."""

    def __init__(
        self,
        kernel_name="RBF",
        length_scale=2.0,
        constant_value=1.0,
        noise_level=0.20,
        alpha=1e-3,
        normalize_y=True,
        random_state=42,
    ):
        self.kernel_name = kernel_name
        self.length_scale = length_scale
        self.constant_value = constant_value
        self.noise_level = noise_level
        self.alpha = alpha
        self.normalize_y = normalize_y
        self.random_state = random_state

    def fit(self, X, y):
        X_df = pd.DataFrame(X).copy()
        self.feature_names_in_ = list(X_df.columns)
        y_arr = np.asarray(y, dtype=float)

        self.scaler_ = StandardScaler()
        X_scaled = self.scaler_.fit_transform(X_df)

        kernel_key = str(self.kernel_name).upper().strip()
        if kernel_key == "RBF":
            base_kernel = RBF(length_scale=float(self.length_scale), length_scale_bounds="fixed")
        elif kernel_key in {"MATERN_1.5", "MATERN15", "MATERN_15"}:
            base_kernel = Matern(length_scale=float(self.length_scale), length_scale_bounds="fixed", nu=1.5)
        elif kernel_key in {"MATERN_2.5", "MATERN25", "MATERN_25"}:
            base_kernel = Matern(length_scale=float(self.length_scale), length_scale_bounds="fixed", nu=2.5)
        else:
            raise ValueError("GPR kernel_name must be one of: RBF, MATERN_1.5, MATERN_2.5")

        kernel = ConstantKernel(float(self.constant_value), constant_value_bounds="fixed") * base_kernel + WhiteKernel(
            noise_level=float(self.noise_level), noise_level_bounds="fixed"
        )

        self.model_ = GaussianProcessRegressor(
            kernel=kernel,
            alpha=float(self.alpha),
            optimizer=None,
            normalize_y=self.normalize_y,
            random_state=self.random_state,
        )
        self.model_.fit(X_scaled, y_arr)
        self.kernel_ = self.model_.kernel_
        return self

    def predict(self, X):
        X_df = pd.DataFrame(X).copy()
        X_scaled = self.scaler_.transform(X_df)
        return self.model_.predict(X_scaled)


class OrdinaryLinearRegressor(BaseEstimator, RegressorMixin):
    """Conventional multiple linear regression (ordinary least squares) for ML comparison.

    The model is fit on standardized original descriptors. No L1/L2 penalty, no
    coefficient thresholding, and no Bayesian optimisation are applied. This gives
    a traditional linear baseline against XGBoost and GPR.
    """

    def __init__(self):
        pass

    def fit(self, X, y):
        X_df = pd.DataFrame(X).copy()
        self.feature_names_in_ = list(X_df.columns)
        y_arr = np.asarray(y, dtype=float)

        self.scaler_ = StandardScaler()
        X_scaled = self.scaler_.fit_transform(X_df)

        self.model_ = LinearRegression()
        self.model_.fit(X_scaled, y_arr)
        self.coef_scaled_ = np.asarray(self.model_.coef_, dtype=float)
        self.intercept_ = float(self.model_.intercept_)
        return self

    def predict(self, X):
        X_df = pd.DataFrame(X).copy()
        X_scaled = self.scaler_.transform(X_df)
        return self.model_.predict(X_scaled)


# -----------------------
# Read data
# -----------------------
log("Starting cyclohexene yield analysis")
log(f"Input file: {INPUT_FILE}")
log(f"Sheet: {SHEET_NAME}")
log(f"Output directory: {OUT_DIR}")
log(f"Target column: {TARGET}")
log(f"Selected CV strategy: {CV_STRATEGY}")

xls = pd.ExcelFile(INPUT_FILE)
if SHEET_NAME not in xls.sheet_names:
    log(f"Configured worksheet not found. Available sheets: {xls.sheet_names}. Using first sheet.")
    SHEET_NAME = xls.sheet_names[0]

df = pd.read_excel(INPUT_FILE, sheet_name=SHEET_NAME)
df.columns = [str(c).strip() for c in df.columns]
log(f"Loaded raw table: {df.shape[0]} rows x {df.shape[1]} columns")
plot_dataset_composition(df, OUT_DIR)
log(f"Seeds selected for {CV_STRATEGY}: {RUN_SEEDS}")
if LOO_LEARNING_CURVES_DEFERRED:
    log("LOO learning-curve fits and per-fraction optimization are skipped. "
        "Original model evaluations/BO remain enabled as configured; "
        "inputs for later fixed-parameter learning curves will be saved.")


if TARGET not in df.columns:
    raise ValueError(f"Target column '{TARGET}' was not found. Available columns: {list(df.columns)}")

df_model = df.dropna(subset=[TARGET]).copy()
drop_cols = [c for c in [TARGET] + LEAKAGE_COLS + ID_COLS if c in df_model.columns]
X_raw = df_model.drop(columns=drop_cols)
y = df_model[TARGET].astype(float).reset_index(drop=True)
X_raw = X_raw.reset_index(drop=True)
df_model = df_model.reset_index(drop=True)

log(f"Rows retained after dropping missing target values: {len(df_model)} / {len(df)}")
log(f"Excluded columns from features: {drop_cols}")

# Numeric conversion and missing values.
# Drop entirely nonnumeric columns; replace remaining missing numeric values with zero.
log("Converting feature columns to numeric. No median imputation is used.")
for c in X_raw.columns:
    X_raw[c] = pd.to_numeric(X_raw[c], errors="coerce")
missing_before_fill = X_raw.isna().sum().sort_values(ascending=False)
missing_before_fill = missing_before_fill[missing_before_fill > 0]
all_nan_cols = [c for c in X_raw.columns if X_raw[c].isna().all()]
if all_nan_cols:
    log("Dropping fully nonnumeric/all-NaN feature columns: " + ", ".join(all_nan_cols))
    X_raw = X_raw.drop(columns=all_nan_cols)

X_all = X_raw.replace([np.inf, -np.inf], np.nan).fillna(0)
X_all.columns = [str(c).strip() for c in X_all.columns]

# Apply the descriptor-frequency filter before constructing any CV folds.
if APPLY_RARE_FEATURE_FILTER_TO_ML:
    X_ml, rare_feature_filter_report_df = trim_rare_ml_features(
        X_all,
        min_binary_minority_count=MIN_BINARY_MINORITY_COUNT,
        min_continuous_unique_values=MIN_CONTINUOUS_UNIQUE_VALUES,
    )
else:
    X_ml = X_all.copy()
    rare_feature_filter_report_df = pd.DataFrame({
        "feature": X_ml.columns,
        "kept_for_ML": True,
        "reason": "rare-feature filter disabled",
    })

feature_cols_ml = list(X_ml.columns)
feature_cols_before_filter = list(X_all.columns)
log(f"ML feature matrix ready: {X_ml.shape[0]} rows x {X_ml.shape[1]} features")
log(f"Predictor matrix before filtering: {X_all.shape[0]} rows x {X_all.shape[1]} features")
if APPLY_RARE_FEATURE_FILTER_TO_ML:
    removed_ml_features = rare_feature_filter_report_df.loc[~rare_feature_filter_report_df["kept_for_ML"], "feature"].tolist()
    log(f"Rare-feature filter retained {len(feature_cols_ml)} of {len(feature_cols_before_filter)} ML features")
    if removed_ml_features:
        log("Rare/near-constant ML features removed: " + ", ".join(removed_ml_features))

missing_df = pd.DataFrame({
    "feature": missing_before_fill.index,
    "missing_count_before_zero_fill": missing_before_fill.values,
    "missing_fraction_before_zero_fill": missing_before_fill.values / len(df_model),
})

# -----------------------
# Cross-validation setup
# -----------------------
def build_outer_cv_splits(strategy):
    """Construct the configured held-out partitions and grouping metadata."""
    strategy = str(strategy).strip().lower()
    if len(y) < 2:
        raise ValueError("At least 2 rows are needed for cross-validation.")

    if strategy == "kfold_5":
        n_splits_local = min(N_SPLITS, len(y))
        splitter = KFold(n_splits=n_splits_local, shuffle=True, random_state=KFOLD_RANDOM_STATE)
        splits = list(splitter.split(X_ml, y))
        return {
            "strategy": strategy,
            "label": f"KFold_{n_splits_local}fold_shuffled",
            "splits": splits,
            "groups": None,
            "group_column_basis": "none",
            "description": "Random shuffled KFold; useful as an internal exploratory benchmark but can mix related catalyst/paper rows.",
        }

    if strategy == "groupkfold_catalyst":
        # Catalyst-grouped CV is defined strictly by the curated Catalyst_ID2 column.
        # No fallback to Catalyst_ID/Catalyst or unique-row grouping is allowed here:
        # if the curated group key is missing or invalid, stop rather than silently
        # changing the scientific meaning of the validation strategy.
        if "Catalyst_ID2" not in df_model.columns:
            raise ValueError(
                "groupkfold_catalyst requires the curated 'Catalyst_ID2' column."
            )

        catalyst_group_series = df_model["Catalyst_ID2"]
        if catalyst_group_series.isna().any():
            missing_rows = np.where(catalyst_group_series.isna().to_numpy())[0].tolist()
            raise ValueError(
                "Catalyst_ID2 contains missing values at model-row indices "
                f"{missing_rows}. Every experiment must have a catalyst group ID."
            )

        catalyst_group_text = catalyst_group_series.astype(str).str.strip()
        invalid_group_mask = catalyst_group_text.str.lower().isin({"", "nan", "none", "na", "n/a"})
        if invalid_group_mask.any():
            invalid_rows = np.where(invalid_group_mask.to_numpy())[0].tolist()
            raise ValueError(
                "Catalyst_ID2 contains blank/invalid values at model-row indices "
                f"{invalid_rows}. Every experiment must have a valid catalyst group ID."
            )

        groups = catalyst_group_text.to_numpy(dtype=object)
        n_groups = len(np.unique(groups))
        if n_groups < 2:
            raise ValueError("GroupKFold by catalyst requires at least two catalyst groups.")

        n_splits_local = min(N_SPLITS, n_groups)
        splitter = GroupKFold(n_splits=n_splits_local)
        splits = list(splitter.split(X_ml, y, groups))

        # Verify group separation and that every row belongs to one test fold.
        test_coverage = np.zeros(len(y), dtype=int)
        for fold_idx, (tr, te) in enumerate(splits, start=1):
            train_groups = set(groups[tr])
            test_groups = set(groups[te])
            overlap = train_groups.intersection(test_groups)
            if overlap:
                raise RuntimeError(
                    f"Catalyst leakage detected in GroupKFold fold {fold_idx}: "
                    f"{sorted(overlap)}"
                )
            test_coverage[te] += 1
            log(
                f"Catalyst GroupKFold fold {fold_idx}: "
                f"train rows={len(tr)}, test rows={len(te)}, "
                f"train catalysts={len(train_groups)}, test catalysts={len(test_groups)}, "
                "catalyst overlap=0"
            )

        if not np.all(test_coverage == 1):
            bad_rows = np.where(test_coverage != 1)[0].tolist()
            raise RuntimeError(
                "Catalyst GroupKFold test coverage is invalid; each row must appear "
                f"in exactly one outer test fold. Problem rows: {bad_rows}"
            )

        return {
            "strategy": strategy,
            "label": f"GroupKFold_by_catalyst_{n_splits_local}fold",
            "splits": splits,
            "groups": groups,
            "group_column_basis": "Catalyst_ID2 (curated catalyst group ID; no fallback)",
            "description": (
                "Grouped strictly by curated Catalyst_ID2; all experiments from the same "
                "catalyst group are kept together, with zero catalyst overlap between "
                "outer training and test folds."
            ),
            "group_source_counts": {"Catalyst_ID2": int(len(groups))},
            "n_groups": n_groups,
        }

    if strategy == "leave_one_out":
        splitter = LeaveOneOut()
        splits = list(splitter.split(X_ml, y))
        return {
            "strategy": strategy,
            "label": "LeaveOneOut_CV",
            "splits": splits,
            "groups": None,
            "group_column_basis": "none",
            "description": "Each row is tested once; useful for small datasets, but related rows can still leak across train/test.",
        }

    if strategy == "leave_one_paper_out":
        groups, source_counts = build_group_labels(
            df_model,
            candidate_cols=["Author", "Source_study", "Reference", "Paper"],
            fallback_prefix="paper",
        )
        n_groups = len(np.unique(groups))
        if n_groups < 2:
            raise ValueError("Leave-one-paper-out CV requires at least two paper/source groups.")
        splitter = LeaveOneGroupOut()
        splits = list(splitter.split(X_ml, y, groups))
        return {
            "strategy": strategy,
            "label": "LeaveOnePaperOut",
            "splits": splits,
            "groups": groups,
            "group_column_basis": "Author -> Source_study -> Reference -> Paper -> unique row fallback",
            "description": "Each source-label group is held out once; estimates transfer across studies when labels consistently identify publications.",
            "group_source_counts": source_counts,
            "n_groups": n_groups,
        }

    raise ValueError("CV_STRATEGY must be one of: kfold_5, groupkfold_catalyst, leave_one_out, leave_one_paper_out")


cv_plan = build_outer_cv_splits(CV_STRATEGY)
cv_splits = cv_plan["splits"]
n_splits = len(cv_splits)
CV_STRATEGY_LABEL = cv_plan["label"]
CV_GROUP_BASIS = cv_plan["group_column_basis"]
CV_DESCRIPTION = cv_plan["description"]
log(f"Active CV strategy: {CV_STRATEGY_LABEL} | folds={n_splits} | group basis={CV_GROUP_BASIS}")
cv_plan = build_outer_cv_splits(CV_STRATEGY)
cv_splits = cv_plan["splits"]
n_splits = len(cv_splits)
CV_STRATEGY_LABEL = cv_plan["label"]
CV_GROUP_BASIS = cv_plan["group_column_basis"]
CV_DESCRIPTION = cv_plan["description"]
CV_DISPLAY_NAMES = {
    "kfold_5": f"{n_splits}-Fold CV",
    "groupkfold_catalyst": f"{n_splits}-Fold Group CV by Catalyst",
    "leave_one_out": "Leave-One-Out CV",
    "leave_one_paper_out": "Leave-One-Paper-Out CV",
}

CV_DISPLAY_NAME = CV_DISPLAY_NAMES.get(CV_STRATEGY, CV_STRATEGY_LABEL)


# -----------------------
# Outer-fold reporting helpers
# -----------------------
def _clean_unique_text(series):
    """Return unique, non-empty text values while preserving first-seen order."""
    values = []
    seen = set()
    for raw in series:
        if pd.isna(raw):
            continue
        txt = str(raw).strip()
        if not txt or txt.lower() in {"nan", "none", "na", "n/a"}:
            continue
        if txt not in seen:
            seen.add(txt)
            values.append(txt)
    return values


def _join_values(values):
    return " | ".join(values) if values else ""


def get_outer_fold_metadata(fold, tr, te):
    """Describe what the selected outer CV fold is withholding.

    The returned fields are reporting metadata only; they do not affect model fitting.
    For LOPO, held_out_paper is taken from the exact grouping key used by
    LeaveOneGroupOut and is accompanied by Author/Source_study/Reference/Paper
    values from the test rows for transparent identification of the publication.
    """
    tr = np.asarray(tr, dtype=int)
    te = np.asarray(te, dtype=int)

    meta = {
        "cv_strategy": CV_STRATEGY,
        "cv_strategy_label": CV_STRATEGY_LABEL,
        "outer_fold": int(fold),
        "train_size": int(len(tr)),
        "test_size": int(len(te)),
        "held_out_unit": "",
        "held_out_group": "",
        "held_out_paper": "",
        "held_out_catalysts": "",
        "test_row_indices": ",".join(map(str, te.tolist())),
    }

    # Human-readable study metadata from the rows in the outer test fold.
    for col in ["Author", "Source_study", "Reference", "Paper"]:
        if col in df_model.columns:
            vals = _clean_unique_text(df_model.iloc[te][col])
            meta[f"test_{col}"] = _join_values(vals)
        else:
            meta[f"test_{col}"] = ""

    # Report exact group(s) used by grouped outer CV strategies.
    groups = cv_plan.get("groups")
    if groups is not None:
        held_groups = _clean_unique_text(np.asarray(groups, dtype=object)[te])
        meta["held_out_group"] = _join_values(held_groups)

        if CV_STRATEGY == "leave_one_paper_out":
            # build_group_labels prefixes the source column, e.g. "Author:Dini et al.(1973)".
            clean_groups = [re.sub(r"^(Author|Source_study|Reference|Paper):", "", g) for g in held_groups]
            meta["held_out_paper"] = _join_values(clean_groups)
            meta["held_out_unit"] = "paper"
        elif CV_STRATEGY == "groupkfold_catalyst":
            meta["held_out_catalysts"] = _join_values(held_groups)
            meta["held_out_unit"] = "catalyst group(s)"

    if CV_STRATEGY == "leave_one_out":
        meta["held_out_unit"] = "single experimental row"
    elif CV_STRATEGY == "kfold_5":
        meta["held_out_unit"] = "row-wise fold"

    return meta

selected_cv_metadata_df = pd.DataFrame([{
    "CV_STRATEGY": CV_STRATEGY,
    "CV_STRATEGY_LABEL": CV_STRATEGY_LABEL,
    "n_outer_folds": n_splits,
    "group_basis": CV_GROUP_BASIS,
    "description": CV_DESCRIPTION,
    "n_rows": len(y),
    "n_ml_features": X_ml.shape[1],
    "n_features_before_filter": X_all.shape[1],
}])

# -----------------------
# Mean baseline
# -----------------------
log(f"Computing mean baseline with {CV_STRATEGY_LABEL} out-of-fold prediction")
baseline_oof = np.zeros(len(y), dtype=float)
baseline_fold_rows = []
for fold, (tr, te) in enumerate(cv_splits, 1):
    train_mean = float(y.iloc[tr].mean())
    baseline_oof[te] = train_mean

    # Fold-level train and test performance for transparent overfitting/generalization reporting.
    train_pred = np.full(len(tr), train_mean, dtype=float)
    train_m = metrics_safe(y.iloc[tr], train_pred)
    test_m = metrics_safe(y.iloc[te], baseline_oof[te])
    fold_meta = get_outer_fold_metadata(fold, tr, te)

    m = dict(test_m)  # R2, MAE and RMSE contain outer-test scores
    m.update({
        "fold": fold,
        "model": "Mean baseline",
        "case": "training-fold mean baseline",
        "train_size": len(tr),
        "test_size": len(te),
        "train_R2": train_m["R2"],
        "train_MAE": train_m["MAE"],
        "train_RMSE": train_m["RMSE"],
        "test_R2": test_m["R2"],
        "test_MAE": test_m["MAE"],
        "test_RMSE": test_m["RMSE"],
        **fold_meta,
    })
    baseline_fold_rows.append(m)
baseline_metrics = metrics(y, baseline_oof)
baseline_full_pred = np.full(len(y), y.mean())
baseline_full_metrics = metrics(y, baseline_full_pred)
log(f"Mean baseline complete | R2={baseline_metrics['R2']:.4f}, MAE={baseline_metrics['MAE']:.4f}, RMSE={baseline_metrics['RMSE']:.4f}")

# -----------------------
# ML model settings
# -----------------------
# Fixed XGBoost configuration. n_estimators and max_depth set ensemble size
# and tree complexity; learning_rate scales each tree's contribution.
# subsample/colsample_bytree select row/feature fractions; reg_lambda/reg_alpha,
# min_child_weight and gamma constrain complexity. The ranges below define
# which values BO may compare; choose them before inspecting outer-test scores.
xgb_params_base = dict(
    n_estimators=120,
    max_depth=2,
    learning_rate=0.04,
    subsample=0.80,
    colsample_bytree=0.80,
    reg_lambda=10.0,
    reg_alpha=0.25,
    min_child_weight=4,
    gamma=0.5,
    objective="reg:squarederror",
    random_state=42,
    n_jobs=XGB_N_JOBS_FINAL,
)

# Integer ranges are discrete; log-uniform ranges sample positive values by ratio.
xgb_search_space = {
    "n_estimators": Integer(80, 300),
    "max_depth": Integer(1, 3),
    "learning_rate": Real(0.02, 0.10, prior="log-uniform"),
    "subsample": Real(0.70, 1.00),
    "colsample_bytree": Real(0.70, 1.00),
    "reg_lambda": Real(2.0, 50.0, prior="log-uniform"),
    "reg_alpha": Real(0.01, 5.0, prior="log-uniform"),
    "min_child_weight": Integer(3, 20),
    "gamma": Real(0.1, 5.0, prior="log-uniform"),
}

# Fixed GPR configuration in scaled feature coordinates. length_scale controls
# the distance over which predictions remain correlated; constant_value is
# signal variance, and noise_level is WhiteKernel variance. BO tunes only
# these three parameters; the selected kernel family and alpha stay fixed.
gpr_params_base = {
    "kernel_name": GPR_KERNEL,
    "length_scale": 2.0,
    "constant_value": 1.0,
    "noise_level": 0.20,
    "alpha": GPR_ALPHA_FIXED,
    "normalize_y": True,
    "random_state": 42,
}

gpr_search_space = {
    "length_scale": Real(0.8, 10.0, prior="log-uniform"),
    "constant_value": Real(0.20, 5.0, prior="log-uniform"),
    "noise_level": Real(0.03, 3.0, prior="log-uniform"),
}

linear_params_base = {
    "model": "Ordinary least squares linear regression",
    "fit_intercept": True,
    "feature_scaling": "StandardScaler applied inside the CV fold",
    "regularization": "none",
    "bayesian_optimization": "not applicable",
}


def build_xgboost_regressor(params):
    """Construct XGBoost from fixed settings and any selected overrides."""
    p = xgb_params_base.copy()
    p.update(params)
    p.update({"objective": "reg:squarederror", "random_state": BO_RANDOM_STATE, "n_jobs": XGB_N_JOBS_FINAL})
    return xgb.XGBRegressor(**p)


def build_gaussian_process_regressor(params):
    """Construct scaled GPR with the selected kernel and hyperparameters."""
    p = gpr_params_base.copy()
    p.update(params)
    p.update({"kernel_name": GPR_KERNEL, "alpha": GPR_ALPHA_FIXED, "normalize_y": True, "random_state": BO_RANDOM_STATE})
    return TunableGPR(**p)


def build_ordinary_least_squares_regressor(params=None):
    # params is accepted only to keep the same evaluation function signature.
    """Construct the scaled, unregularised linear regression baseline."""
    return OrdinaryLinearRegressor()


def extract_model_details(model):
    """Return fitted-kernel or linear-model metadata for result tables."""
    if isinstance(model, OrdinaryLinearRegressor):
        return {
            "n_model_features": len(getattr(model, "feature_names_in_", [])),
            "model_detail": "ordinary least squares; no Lasso penalty; no feature selection",
        }
    if isinstance(model, TunableGPR):
        return {"kernel_after_fit": str(getattr(model, "kernel_", ""))}
    return {}


def evaluate_fixed_model_cv(model_name, make_model_func, params, X_data, case_label, hyperparameter_source):
    """Fit each outer fold, collect predictions and metrics, then fit all rows."""
    log(f"Evaluating {model_name} {case_label} with {CV_STRATEGY_LABEL}")
    oof = np.zeros(len(y), dtype=float)
    fold_rows = []
    for fold, (tr, te) in enumerate(cv_splits, 1):
        fold_start = time.perf_counter()
        model = make_model_func(params)
        model.fit(X_data.iloc[tr], y.iloc[tr])

        # Calculate training and held-out metrics for the same fitted model.
        train_pred = model.predict(X_data.iloc[tr])
        test_pred = model.predict(X_data.iloc[te])
        oof[te] = test_pred
        train_m = metrics_safe(y.iloc[tr], train_pred)
        test_m = metrics_safe(y.iloc[te], test_pred)
        fold_meta = get_outer_fold_metadata(fold, tr, te)

        # R2, MAE and RMSE are aliases of the outer-test metrics.
        m = dict(test_m)
        m.update({
            "fold": fold,
            "model": model_name,
            "case": case_label,
            "train_size": len(tr),
            "test_size": len(te),
            "train_R2": train_m["R2"],
            "train_MAE": train_m["MAE"],
            "train_RMSE": train_m["RMSE"],
            "test_R2": test_m["R2"],
            "test_MAE": test_m["MAE"],
            "test_RMSE": test_m["RMSE"],
            "hyperparameter_source": hyperparameter_source,
            **fold_meta,
        })
        m.update(extract_model_details(model))
        fold_rows.append(m)

        held_out_txt = f" | held out={m.get('held_out_paper', '')}" if m.get("held_out_paper") else ""
        log(
            f"{model_name} {case_label} fold {fold}/{n_splits} complete in "
            f"{format_runtime(time.perf_counter() - fold_start)} | "
            f"test R2={test_m['R2']}, MAE={test_m['MAE']:.4f}, RMSE={test_m['RMSE']:.4f} | "
            f"train R2={train_m['R2']}, MAE={train_m['MAE']:.4f}, RMSE={train_m['RMSE']:.4f}"
            f"{held_out_txt}"
        )

    cv_metrics = metrics(y, oof)
    final_model = make_model_func(params)
    final_model.fit(X_data, y)
    full_pred = final_model.predict(X_data)
    full_metrics = metrics(y, full_pred)
    log(f"{model_name} {case_label} complete | CV R2={cv_metrics['R2']:.4f}, Full R2={full_metrics['R2']:.4f}")
    return oof, pd.DataFrame(fold_rows), cv_metrics, final_model, full_pred, full_metrics


def optimize_regression_hyperparameters(model_name, estimator, search_space, X_train, y_train, context_label, base_params_for_reporting):
    """Select hyperparameters by maximising mean inner-fold R2."""
    if BayesSearchCV is None:
        raise ImportError("Bayesian optimization requires scikit-optimize. Install it with: python -m pip install scikit-optimize")
    bo_acq_func, bo_acq_kwargs = configure_acquisition_function(ML_BO_ACQ_FUNC, ML_BO_ACQ_KAPPA, ML_BO_ACQ_XI)
    optimizer_kwargs = {"acq_func": bo_acq_func, "acq_func_kwargs": bo_acq_kwargs}
    bo_cv, bo_cv_splits = build_inner_tuning_folds(len(y_train), BO_CV_SPLITS, BO_RANDOM_STATE)

    log(
        f"{model_name} BO started for {context_label} | n_iter={BO_N_ITER}, inner_cv={bo_cv_splits}, "
        f"objective=inner-CV R2 maximisation, acquisition={bo_acq_func}"
    )
    start = time.perf_counter()
    search = BayesSearchCV(
        estimator=estimator,
        search_spaces=search_space,
        n_iter=BO_N_ITER,
        scoring="r2",
        cv=bo_cv,
        n_jobs=BO_SEARCH_N_JOBS,
        random_state=BO_RANDOM_STATE,
        optimizer_kwargs=optimizer_kwargs,
        refit=True,
        verbose=0,
        return_train_score=True,
    )
    search.fit(X_train, y_train)
    elapsed = time.perf_counter() - start
    best_params = safe_param_dict(search.best_params_)
    best_inner_r2 = float(search.best_score_)
    results_df = pd.DataFrame(search.cv_results_).sort_values("rank_test_score")
    results_df["context"] = context_label
    results_df["model"] = model_name
    results_df["bo_iteration"] = np.arange(1, len(results_df) + 1)
    results_df["mean_inner_cv_R2"] = results_df["mean_test_score"]
    results_df["std_inner_cv_R2"] = results_df["std_test_score"]

    best_rows = [{"model": model_name, "context": context_label, "parameter": k, "value": v} for k, v in best_params.items()]
    best_rows.extend([
        {"model": model_name, "context": context_label, "parameter": "best_inner_cv_R2", "value": best_inner_r2},
        {"model": model_name, "context": context_label, "parameter": "bo_objective", "value": "inner_cross_validated_R2"},
        {"model": model_name, "context": context_label, "parameter": "inner_cv_splits", "value": bo_cv_splits},
        {"model": model_name, "context": context_label, "parameter": "bo_runtime_seconds", "value": elapsed},
        {"model": model_name, "context": context_label, "parameter": "bo_acquisition_configured", "value": ML_BO_ACQ_FUNC},
        {"model": model_name, "context": context_label, "parameter": "bo_acquisition_used_by_skopt", "value": bo_acq_func},
        {"model": model_name, "context": context_label, "parameter": "bo_acquisition_kwargs", "value": json.dumps(bo_acq_kwargs)},
        {"model": model_name, "context": context_label, "parameter": "base_params_reference", "value": json.dumps(base_params_for_reporting, default=str)},
    ])
    best_df = pd.DataFrame(best_rows)
    log(f"{model_name} BO complete for {context_label} in {format_runtime(elapsed)} | best inner-CV R2={best_inner_r2:.4f}")
    return best_params, results_df, best_df, best_inner_r2, elapsed


def evaluate_non_nested_bo_cv(model_name, estimator, search_space, X_data, make_model_func, base_params, optimization_enabled):
    """Tune using all rows, then evaluate the selected configuration by outer CV."""
    if not optimization_enabled:
        log(f"{model_name} BO disabled; non-nested BO case reuses base parameters")
        best_params = {}
        bo_results_df = pd.DataFrame()
        bo_best_params_df = pd.DataFrame()
    else:
        best_params, bo_results_df, bo_best_params_df, best_r2, elapsed = optimize_regression_hyperparameters(
            model_name, estimator, search_space, X_data, y, "non_nested_full_data_tuning", base_params
        )
    params = base_params.copy()
    params.update(best_params)
    return (*evaluate_fixed_model_cv(
        model_name,
        make_model_func,
        params,
        X_data,
        "BO optimized (non-nested/tuning-informed)",
        "BO tuned once on all rows; CV metrics are tuning-informed",
    ), params, bo_results_df, bo_best_params_df)


def evaluate_nested_bo_cv(model_name, estimator_factory, search_space, X_data, make_model_func, base_params, optimization_enabled):
    """Tune within each outer training set and predict its held-out observations."""
    if not optimization_enabled:
        log(f"{model_name} BO disabled; nested BO case reuses base parameters")
        fixed = evaluate_fixed_model_cv(model_name, make_model_func, base_params, X_data, "Nested BO disabled/reused-base", "base parameters")
        return (*fixed[:3], pd.DataFrame(), pd.DataFrame())

    log(f"Running NESTED {model_name} BO with outer strategy {CV_STRATEGY_LABEL}")
    oof = np.zeros(len(y), dtype=float)
    fold_rows = []
    all_results = []
    all_best_params = []
    for fold, (tr, te) in enumerate(cv_splits, 1):
        fold_start = time.perf_counter()
        context = f"outer_fold_{fold}_of_{n_splits}"
        fold_meta = get_outer_fold_metadata(fold, tr, te)
        held_out_paper = fold_meta.get("held_out_paper", "")

        estimator = estimator_factory()
        best_params, res_df, best_df, best_inner_r2, elapsed = optimize_regression_hyperparameters(
            model_name,
            estimator,
            search_space,
            X_data.iloc[tr],
            y.iloc[tr],
            context,
            base_params,
        )
        params = base_params.copy()
        params.update(best_params)
        model = make_model_func(params)
        model.fit(X_data.iloc[tr], y.iloc[tr])

        # Evaluate the tuned fold model on its training rows and held-out rows.
        train_pred = model.predict(X_data.iloc[tr])
        test_pred = model.predict(X_data.iloc[te])
        oof[te] = test_pred
        train_m = metrics_safe(y.iloc[tr], train_pred)
        test_m = metrics_safe(y.iloc[te], test_pred)

        # R2, MAE and RMSE are aliases of the outer-test metrics.
        m = dict(test_m)
        m.update({
            "fold": fold,
            "model": model_name,
            "case": "Nested BO optimized",
            "train_size": len(tr),
            "test_size": len(te),
            "train_R2": train_m["R2"],
            "train_MAE": train_m["MAE"],
            "train_RMSE": train_m["RMSE"],
            "test_R2": test_m["R2"],
            "test_MAE": test_m["MAE"],
            "test_RMSE": test_m["RMSE"],
            "hyperparameter_source": "BO tuned only on this outer-training fold",
            "best_inner_cv_R2": best_inner_r2,
            "bo_runtime_seconds": elapsed,
            **fold_meta,
        })
        m.update(extract_model_details(model))
        fold_rows.append(m)

        # Attach held-out group metadata to each optimisation record.
        res_df.insert(0, "outer_fold", fold)
        res_df.insert(1, "held_out_paper", held_out_paper)
        res_df.insert(2, "held_out_group", fold_meta.get("held_out_group", ""))
        res_df.insert(3, "outer_train_size", len(tr))
        res_df.insert(4, "outer_test_size", len(te))
        best_df.insert(1, "outer_fold", fold)
        best_df.insert(2, "held_out_paper", held_out_paper)
        best_df.insert(3, "held_out_group", fold_meta.get("held_out_group", ""))
        best_df.insert(4, "outer_train_size", len(tr))
        best_df.insert(5, "outer_test_size", len(te))
        all_results.append(res_df)
        all_best_params.append(best_df)

        held_out_txt = f" | held out={held_out_paper}" if held_out_paper else ""
        log(
            f"Nested {model_name} BO outer fold {fold}/{n_splits} complete in {format_runtime(time.perf_counter() - fold_start)} | "
            f"test R2={test_m['R2']}, MAE={test_m['MAE']:.4f}, RMSE={test_m['RMSE']:.4f} | "
            f"train R2={train_m['R2']}, MAE={train_m['MAE']:.4f}, RMSE={train_m['RMSE']:.4f}"
            f"{held_out_txt}"
        )

    cv_metrics = metrics(y, oof)
    results_df = pd.concat(all_results, ignore_index=True) if all_results else pd.DataFrame()
    best_params_df = pd.concat(all_best_params, ignore_index=True) if all_best_params else pd.DataFrame()
    log(f"Nested {model_name} BO complete | CV R2={cv_metrics['R2']:.4f}, MAE={cv_metrics['MAE']:.4f}, RMSE={cv_metrics['RMSE']:.4f}")
    return oof, pd.DataFrame(fold_rows), cv_metrics, results_df, best_params_df

# -----------------------
# ML evaluations
# -----------------------
# Base models
xgb_base_oof, xgb_base_fold_metrics_df, xgb_base_metrics, final_xgb_base, xgb_base_full_pred, xgb_base_full_metrics = evaluate_fixed_model_cv(
    "XGBoost", build_xgboost_regressor, xgb_params_base, X_ml, "base case", "fixed base case"
)

gpr_base_oof, gpr_base_fold_metrics_df, gpr_base_metrics, final_gpr_base, gpr_base_full_pred, gpr_base_full_metrics = evaluate_fixed_model_cv(
    "GPR", build_gaussian_process_regressor, gpr_params_base, X_ml, "base case", "fixed base case"
)

linear_base_oof, linear_base_fold_metrics_df, linear_base_metrics, final_linear_base, linear_base_full_pred, linear_base_full_metrics = evaluate_fixed_model_cv(
    "Ordinary linear regression", build_ordinary_least_squares_regressor, {}, X_ml, "base case", "ordinary least squares; no regularization; no BO"
)

# Non-nested BO models, retained but labelled as tuning-informed.
xgb_estimator_for_bo = xgb.XGBRegressor(**{**xgb_params_base, "random_state": BO_RANDOM_STATE, "n_jobs": XGB_N_JOBS_DURING_BO})
gpr_estimator_for_bo = TunableGPR(**{**gpr_params_base, "random_state": BO_RANDOM_STATE})
xgb_bo_oof, xgb_bo_fold_metrics_df, xgb_bo_metrics, final_xgb_bo_tuning, xgb_bo_full_pred, xgb_bo_full_metrics, xgb_params_bo_final, xgb_bo_results_df, xgb_bo_best_params_df = evaluate_non_nested_bo_cv(
    "XGBoost", xgb_estimator_for_bo, xgb_search_space, X_ml, build_xgboost_regressor, xgb_params_base, RUN_XGB_BAYES_OPT
)

gpr_bo_oof, gpr_bo_fold_metrics_df, gpr_bo_metrics, final_gpr_bo_tuning, gpr_bo_full_pred, gpr_bo_full_metrics, gpr_params_bo_final, gpr_bo_results_df, gpr_bo_best_params_df = evaluate_non_nested_bo_cv(
    "GPR", gpr_estimator_for_bo, gpr_search_space, X_ml, build_gaussian_process_regressor, gpr_params_base, RUN_GPR_BAYES_OPT
)

# Nested BO models: these are the main predictive BO estimates.
xgb_nested_bo_oof, xgb_nested_bo_fold_metrics_df, xgb_nested_bo_metrics, xgb_nested_bo_results_df, xgb_nested_bo_best_params_df = evaluate_nested_bo_cv(
    "XGBoost", lambda: xgb.XGBRegressor(**{**xgb_params_base, "random_state": BO_RANDOM_STATE, "n_jobs": XGB_N_JOBS_DURING_BO}), xgb_search_space, X_ml, build_xgboost_regressor, xgb_params_base, RUN_XGB_BAYES_OPT
)

gpr_nested_bo_oof, gpr_nested_bo_fold_metrics_df, gpr_nested_bo_metrics, gpr_nested_bo_results_df, gpr_nested_bo_best_params_df = evaluate_nested_bo_cv(
    "GPR", lambda: TunableGPR(**{**gpr_params_base, "random_state": BO_RANDOM_STATE}), gpr_search_space, X_ml, build_gaussian_process_regressor, gpr_params_base, RUN_GPR_BAYES_OPT
)

# Final full-data BO models are used for full metrics and interpretation/SHAP only.
final_xgb_bo = build_xgboost_regressor(xgb_params_bo_final)
final_xgb_bo.fit(X_ml, y)
xgb_bo_final_full_pred = final_xgb_bo.predict(X_ml)
xgb_bo_final_full_metrics = metrics(y, xgb_bo_final_full_pred)

final_gpr_bo = build_gaussian_process_regressor(gpr_params_bo_final)
final_gpr_bo.fit(X_ml, y)
gpr_bo_final_full_pred = final_gpr_bo.predict(X_ml)
gpr_bo_final_full_metrics = metrics(y, gpr_bo_final_full_pred)

# ===========================================================
# Repeated-seed evaluation of metric stability
# ===========================================================
# Interpretation of repeated-seed standard deviations:
#   The mean +/- SD below quantifies variability of the modelling pipeline
#   across different random seeds (CV partitioning where applicable, BO search,
#   and stochastic model fitting). Confidence intervals and per-observation
#   probabilistic predictive uncertainty are not estimated by this summary.
#
#   - For shuffled KFold, the seed changes the outer folds as well as inner BO CV.
#   - GroupKFold, LOOCV and LOPO outer splits are deterministic in this script;
#     for those strategies the seed mainly changes BO and stochastic learners.
#   - Deterministic models with fixed splits can have SD = 0.


def _metric_seed_row(seed, model, case, bo_objective, metric_dict):
    return {
        "seed": int(seed),
        "model": model,
        "hyperparameter_case": case,
        "BO_objective": bo_objective,
        "R2": float(metric_dict["R2"]) if np.isfinite(metric_dict["R2"]) else np.nan,
        "MAE": float(metric_dict["MAE"]),
        "RMSE": float(metric_dict["RMSE"]),
    }


def _prediction_seed_frame(seed, model, case, pred):
    return pd.DataFrame({
        "seed": int(seed),
        "row_index": np.arange(len(y), dtype=int),
        "model": model,
        "hyperparameter_case": case,
        "actual": y.to_numpy(dtype=float),
        "oof_prediction": np.asarray(pred, dtype=float),
    })


def _evaluate_mean_baseline_for_current_cv():
    oof = np.zeros(len(y), dtype=float)
    fold_rows = []
    for fold, (tr, te) in enumerate(cv_splits, 1):
        train_mean = float(y.iloc[tr].mean())
        oof[te] = train_mean
        train_pred = np.full(len(tr), train_mean, dtype=float)
        train_m = metrics_safe(y.iloc[tr], train_pred)
        test_m = metrics_safe(y.iloc[te], oof[te])
        fold_meta = get_outer_fold_metadata(fold, tr, te)
        row = dict(test_m)
        row.update({
            "fold": fold,
            "model": "Mean baseline",
            "case": "training-fold mean baseline",
            "train_size": len(tr),
            "test_size": len(te),
            "train_R2": train_m["R2"],
            "train_MAE": train_m["MAE"],
            "train_RMSE": train_m["RMSE"],
            "test_R2": test_m["R2"],
            "test_MAE": test_m["MAE"],
            "test_RMSE": test_m["RMSE"],
            **fold_meta,
        })
        fold_rows.append(row)
    return oof, pd.DataFrame(fold_rows), metrics(y, oof)


# Include the completed first-seed evaluation in the stability summary.
_seed_metric_rows = [
    _metric_seed_row(RUN_SEEDS[0], "Mean baseline", "training-fold mean", "none", baseline_metrics),
    _metric_seed_row(RUN_SEEDS[0], "XGBoost", "base case", "none", xgb_base_metrics),
    _metric_seed_row(RUN_SEEDS[0], "XGBoost", "BO optimized", "non-nested inner-CV R2", xgb_bo_metrics),
    _metric_seed_row(RUN_SEEDS[0], "XGBoost", "Nested BO optimized", "nested inner-CV R2", xgb_nested_bo_metrics),
    _metric_seed_row(RUN_SEEDS[0], "GPR", "base case", "none", gpr_base_metrics),
    _metric_seed_row(RUN_SEEDS[0], "GPR", "BO optimized", "non-nested inner-CV R2", gpr_bo_metrics),
    _metric_seed_row(RUN_SEEDS[0], "GPR", "Nested BO optimized", "nested inner-CV R2", gpr_nested_bo_metrics),
    _metric_seed_row(RUN_SEEDS[0], "Ordinary linear regression", "base case", "none", linear_base_metrics),
]

_seed_prediction_frames = [
    _prediction_seed_frame(RUN_SEEDS[0], "Mean baseline", "training-fold mean", baseline_oof),
    _prediction_seed_frame(RUN_SEEDS[0], "XGBoost", "base case", xgb_base_oof),
    _prediction_seed_frame(RUN_SEEDS[0], "XGBoost", "BO optimized", xgb_bo_oof),
    _prediction_seed_frame(RUN_SEEDS[0], "XGBoost", "Nested BO optimized", xgb_nested_bo_oof),
    _prediction_seed_frame(RUN_SEEDS[0], "GPR", "base case", gpr_base_oof),
    _prediction_seed_frame(RUN_SEEDS[0], "GPR", "BO optimized", gpr_bo_oof),
    _prediction_seed_frame(RUN_SEEDS[0], "GPR", "Nested BO optimized", gpr_nested_bo_oof),
    _prediction_seed_frame(RUN_SEEDS[0], "Ordinary linear regression", "base case", linear_base_oof),
]

_seed_fold_frames = []
for _df in [
    pd.DataFrame(baseline_fold_rows),
    xgb_base_fold_metrics_df, xgb_bo_fold_metrics_df, xgb_nested_bo_fold_metrics_df,
    gpr_base_fold_metrics_df, gpr_bo_fold_metrics_df, gpr_nested_bo_fold_metrics_df,
    linear_base_fold_metrics_df,
]:
    if _df is not None and not _df.empty:
        _tmp = _df.copy()
        _tmp.insert(0, "seed", int(RUN_SEEDS[0]))
        _seed_fold_frames.append(_tmp)

_seed_non_nested_best_frames = []
for _model_name, _df in [("XGBoost", xgb_bo_best_params_df), ("GPR", gpr_bo_best_params_df)]:
    if _df is not None and not _df.empty:
        _tmp = _df.copy()
        _tmp.insert(0, "seed", int(RUN_SEEDS[0]))
        _tmp.insert(1, "model_family", _model_name)
        _seed_non_nested_best_frames.append(_tmp)

_seed_nested_best_frames = []
for _model_name, _df in [("XGBoost", xgb_nested_bo_best_params_df), ("GPR", gpr_nested_bo_best_params_df)]:
    if _df is not None and not _df.empty:
        _tmp = _df.copy()
        _tmp.insert(0, "seed", int(RUN_SEEDS[0]))
        _tmp.insert(1, "model_family", _model_name)
        _seed_nested_best_frames.append(_tmp)


# Repeat model fitting and optimisation for each remaining seed.
for _seed in RUN_SEEDS[1:]:
    log(f"Starting repeated-seed model evaluation for seed={_seed}")

    # Change only random seeds; all model settings/search spaces remain unchanged.
    KFOLD_RANDOM_STATE = int(_seed)
    BO_RANDOM_STATE = int(_seed)

    # Rebuild the selected outer CV plan. For shuffled KFold this changes the
    # folds; deterministic grouped/LOO/LOPO strategies retain their same folds.
    cv_plan = build_outer_cv_splits(CV_STRATEGY)
    cv_splits = cv_plan["splits"]
    n_splits = len(cv_splits)
    CV_STRATEGY_LABEL = cv_plan["label"]
    CV_GROUP_BASIS = cv_plan["group_column_basis"]
    CV_DESCRIPTION = cv_plan["description"]

    # Mean baseline.
    _baseline_oof, _baseline_fold_df, _baseline_metrics = _evaluate_mean_baseline_for_current_cv()

    # Fixed/base models.
    _xgb_base_oof, _xgb_base_fold_df, _xgb_base_metrics, _, _, _ = evaluate_fixed_model_cv(
        "XGBoost", build_xgboost_regressor, xgb_params_base, X_ml, "base case", "fixed base case"
    )
    _gpr_base_oof, _gpr_base_fold_df, _gpr_base_metrics, _, _, _ = evaluate_fixed_model_cv(
        "GPR", build_gaussian_process_regressor, gpr_params_base, X_ml, "base case", "fixed base case"
    )
    _ols_oof, _ols_fold_df, _ols_metrics, _, _, _ = evaluate_fixed_model_cv(
        "Ordinary linear regression", build_ordinary_least_squares_regressor, {}, X_ml, "base case", "ordinary least squares; no regularization; no BO"
    )

    # Non-nested BO models.
    _xgb_estimator = xgb.XGBRegressor(**{
        **xgb_params_base, "random_state": int(_seed), "n_jobs": XGB_N_JOBS_DURING_BO
    })
    _gpr_estimator = TunableGPR(**{**gpr_params_base, "random_state": int(_seed)})

    (_xgb_bo_oof, _xgb_bo_fold_df, _xgb_bo_metrics, _, _, _,
     _xgb_params_seed, _xgb_bo_trials_seed, _xgb_bo_best_seed) = evaluate_non_nested_bo_cv(
        "XGBoost", _xgb_estimator, xgb_search_space, X_ml, build_xgboost_regressor,
        xgb_params_base, RUN_XGB_BAYES_OPT
    )
    (_gpr_bo_oof, _gpr_bo_fold_df, _gpr_bo_metrics, _, _, _,
     _gpr_params_seed, _gpr_bo_trials_seed, _gpr_bo_best_seed) = evaluate_non_nested_bo_cv(
        "GPR", _gpr_estimator, gpr_search_space, X_ml, build_gaussian_process_regressor,
        gpr_params_base, RUN_GPR_BAYES_OPT
    )

    # Nested BO models.
    (_xgb_nested_oof, _xgb_nested_fold_df, _xgb_nested_metrics,
     _xgb_nested_trials_seed, _xgb_nested_best_seed) = evaluate_nested_bo_cv(
        "XGBoost",
        lambda: xgb.XGBRegressor(**{
            **xgb_params_base, "random_state": int(_seed), "n_jobs": XGB_N_JOBS_DURING_BO
        }),
        xgb_search_space, X_ml, build_xgboost_regressor, xgb_params_base, RUN_XGB_BAYES_OPT
    )
    (_gpr_nested_oof, _gpr_nested_fold_df, _gpr_nested_metrics,
     _gpr_nested_trials_seed, _gpr_nested_best_seed) = evaluate_nested_bo_cv(
        "GPR",
        lambda: TunableGPR(**{**gpr_params_base, "random_state": int(_seed)}),
        gpr_search_space, X_ml, build_gaussian_process_regressor, gpr_params_base, RUN_GPR_BAYES_OPT
    )

    # Overall OOF metrics for this seed.
    _seed_metric_rows.extend([
        _metric_seed_row(_seed, "Mean baseline", "training-fold mean", "none", _baseline_metrics),
        _metric_seed_row(_seed, "XGBoost", "base case", "none", _xgb_base_metrics),
        _metric_seed_row(_seed, "XGBoost", "BO optimized", "non-nested inner-CV R2", _xgb_bo_metrics),
        _metric_seed_row(_seed, "XGBoost", "Nested BO optimized", "nested inner-CV R2", _xgb_nested_metrics),
        _metric_seed_row(_seed, "GPR", "base case", "none", _gpr_base_metrics),
        _metric_seed_row(_seed, "GPR", "BO optimized", "non-nested inner-CV R2", _gpr_bo_metrics),
        _metric_seed_row(_seed, "GPR", "Nested BO optimized", "nested inner-CV R2", _gpr_nested_metrics),
        _metric_seed_row(_seed, "Ordinary linear regression", "base case", "none", _ols_metrics),
    ])

    # OOF predictions for prediction-level seed variability.
    _seed_prediction_frames.extend([
        _prediction_seed_frame(_seed, "Mean baseline", "training-fold mean", _baseline_oof),
        _prediction_seed_frame(_seed, "XGBoost", "base case", _xgb_base_oof),
        _prediction_seed_frame(_seed, "XGBoost", "BO optimized", _xgb_bo_oof),
        _prediction_seed_frame(_seed, "XGBoost", "Nested BO optimized", _xgb_nested_oof),
        _prediction_seed_frame(_seed, "GPR", "base case", _gpr_base_oof),
        _prediction_seed_frame(_seed, "GPR", "BO optimized", _gpr_bo_oof),
        _prediction_seed_frame(_seed, "GPR", "Nested BO optimized", _gpr_nested_oof),
        _prediction_seed_frame(_seed, "Ordinary linear regression", "base case", _ols_oof),
    ])

    # Fold-level outputs with seed identifier.
    for _df in [
        _baseline_fold_df,
        _xgb_base_fold_df, _xgb_bo_fold_df, _xgb_nested_fold_df,
        _gpr_base_fold_df, _gpr_bo_fold_df, _gpr_nested_fold_df,
        _ols_fold_df,
    ]:
        if _df is not None and not _df.empty:
            _tmp = _df.copy()
            _tmp.insert(0, "seed", int(_seed))
            _seed_fold_frames.append(_tmp)

    # BO hyperparameter audit across seeds.
    for _model_name, _df in [("XGBoost", _xgb_bo_best_seed), ("GPR", _gpr_bo_best_seed)]:
        if _df is not None and not _df.empty:
            _tmp = _df.copy()
            _tmp.insert(0, "seed", int(_seed))
            _tmp.insert(1, "model_family", _model_name)
            _seed_non_nested_best_frames.append(_tmp)

    for _model_name, _df in [("XGBoost", _xgb_nested_best_seed), ("GPR", _gpr_nested_best_seed)]:
        if _df is not None and not _df.empty:
            _tmp = _df.copy()
            _tmp.insert(0, "seed", int(_seed))
            _tmp.insert(1, "model_family", _model_name)
            _seed_nested_best_frames.append(_tmp)

    log(f"Completed repeated-seed model evaluation for seed={_seed}")


# Build long-form per-seed table and mean +/- sample-SD summary.
seed_metrics_long_df = pd.DataFrame(_seed_metric_rows)
_seed_group_cols = ["model", "hyperparameter_case", "BO_objective"]
seed_metrics_summary_df = (
    seed_metrics_long_df
    .groupby(_seed_group_cols, dropna=False)
    .agg(
        n_seeds=("seed", "nunique"),
        R2_mean=("R2", "mean"),
        R2_SD=("R2", lambda s: s.std(ddof=1)),
        MAE_mean=("MAE", "mean"),
        MAE_SD=("MAE", lambda s: s.std(ddof=1)),
        RMSE_mean=("RMSE", "mean"),
        RMSE_SD=("RMSE", lambda s: s.std(ddof=1)),
    )
    .reset_index()
)

# Human-readable formatted columns for direct manuscript/table use.
seed_metrics_summary_df["R2_mean_plusminus_SD"] = seed_metrics_summary_df.apply(
    lambda r: format_mean_sd(r["R2_mean"], r["R2_SD"]), axis=1
)
seed_metrics_summary_df["MAE_mean_plusminus_SD"] = seed_metrics_summary_df.apply(
    lambda r: format_mean_sd(r["MAE_mean"], r["MAE_SD"]), axis=1
)
seed_metrics_summary_df["RMSE_mean_plusminus_SD"] = seed_metrics_summary_df.apply(
    lambda r: format_mean_sd(r["RMSE_mean"], r["RMSE_SD"]), axis=1
)

# Per-observation OOF prediction variability across seeds.
seed_predictions_long_df = pd.concat(_seed_prediction_frames, ignore_index=True)
seed_predictions_summary_df = (
    seed_predictions_long_df
    .groupby(["row_index", "model", "hyperparameter_case"], dropna=False)
    .agg(
        actual=("actual", "first"),
        n_seeds=("seed", "nunique"),
        oof_prediction_mean=("oof_prediction", "mean"),
        oof_prediction_SD=("oof_prediction", lambda s: s.std(ddof=1)),
        oof_prediction_min=("oof_prediction", "min"),
        oof_prediction_max=("oof_prediction", "max"),
    )
    .reset_index()
)

multi_seed_outer_fold_metrics_df = (
    pd.concat(_seed_fold_frames, ignore_index=True, sort=False)
    if _seed_fold_frames else pd.DataFrame()
)
multi_seed_non_nested_best_params_df = (
    pd.concat(_seed_non_nested_best_frames, ignore_index=True, sort=False)
    if _seed_non_nested_best_frames else pd.DataFrame()
)
multi_seed_nested_best_params_df = (
    pd.concat(_seed_nested_best_frames, ignore_index=True, sort=False)
    if _seed_nested_best_frames else pd.DataFrame()
)

# Restore the first seed and its CV folds for the detailed tables and plots.
KFOLD_RANDOM_STATE = int(RUN_SEEDS[0])
BO_RANDOM_STATE = int(RUN_SEEDS[0])
cv_plan = build_outer_cv_splits(CV_STRATEGY)
cv_splits = cv_plan["splits"]
n_splits = len(cv_splits)
CV_STRATEGY_LABEL = cv_plan["label"]
CV_GROUP_BASIS = cv_plan["group_column_basis"]
CV_DESCRIPTION = cv_plan["description"]
CV_DISPLAY_NAMES = {
    "kfold_5": f"{n_splits}-Fold CV",
    "groupkfold_catalyst": f"{n_splits}-Fold Group CV by Catalyst",
    "leave_one_out": "Leave-One-Out CV",
    "leave_one_paper_out": "Leave-One-Paper-Out CV",
}
CV_DISPLAY_NAME = CV_DISPLAY_NAMES.get(CV_STRATEGY, CV_STRATEGY_LABEL)

log(f"Metric stability evaluation complete for {N_SEED_REPEATS} seeds")
log(f"{N_SEED_REPEATS}-seed metric summary:\n" + seed_metrics_summary_df.to_string(index=False))

# -----------------------
# SHAP on final Bayesian-optimised XGBoost
# -----------------------
log("Computing SHAP values for final non-nested/full-data BO XGBoost model")
shap_values = np.array(shap.TreeExplainer(final_xgb_bo).shap_values(X_ml))
if shap_values.ndim == 3:
    shap_values = shap_values[:, :, 0]
ind_shap = pd.DataFrame({
    "feature": feature_cols_ml,
    "mean_abs_SHAP_yield_pct_points": np.abs(shap_values).mean(axis=0),
}).sort_values("mean_abs_SHAP_yield_pct_points", ascending=False)

# Group mapping is tolerant to missing filtered columns.
groups = {
    "Metal identity": ["Metal_Pt", "Metal_Pd", "Metal_Ni", "Metal_Ru"],
    "Metal loading / ratio": ["Metal_ratio_%"],
    "Zn promoter": ["Is_Zn", "Zn/Ru_g"],
    "Water / benzene amount": ["Is_water_volume_reported", "Reaction_water_ml", "Is_benzene_volume_reported", "Reaction_benzene_ml"],
    "Crosslinking": ["Is_Crosslinked", "Is_crosslinker_methylene_bisacrylamide", "Is_crosslinker_divinylbenzene", "Crosslinker_mol_%"],
    "Pressure / H\u2082 ratio": ["Reaction_Pressure_bar", "Is_pressure_reported", "Reaction_H2_pressure_bar", "Is_H2_pressure_reported", "Is_H2/C6H6_ratio_reported", "H2_to_Benzene_ratio"],
    "Preparation conditions": ["Preparation_time_h", "Preparation_temperature_C"],
    "Polymer/support identity": [
        "Is_CS-N-n-Propyl-Membrane", "Is_PVP_clinopti", "Is_clinoptilolite",
        "Is_unsupported_metal", "Is_Carbon", "Is_S4NR", "Is_P4NR", "Is_S8NR", "Is_M4KR",
        "Is_NY6", "Is_NY3", "Is_PAA", "Is_PFT", "Is_PAAO", "Is_PAN"
    ],
    "Reaction temperature": ["Reaction_temperature_C"],
    "Reaction/contact time": ["Is_Reaction_time_reported", "Reaction_time_min", "Is_Contact_time_reported", "Contact_time_s"],
}
feature_to_idx = {c: i for i, c in enumerate(feature_cols_ml)}
group_rows = []
for group, cols in groups.items():
    idx = [feature_to_idx[c] for c in cols if c in feature_to_idx]
    if not idx:
        continue
    group_shap = shap_values[:, idx].sum(axis=1)
    group_rows.append({
        "descriptor_group": group,
        "mean_abs_group_SHAP_yield_pct_points": float(np.abs(group_shap).mean()),
        "n_features_in_group": len(idx),
        "features_in_group": ", ".join([feature_cols_ml[i] for i in idx]),
    })
group_shap_df = pd.DataFrame(group_rows)
if not group_shap_df.empty:
    group_shap_df = group_shap_df.sort_values("mean_abs_group_SHAP_yield_pct_points", ascending=False)

# -----------------------
# ML-only results tables
# -----------------------
def make_metric_row(model, hyperparameter_case, bo_objective, cv_metrics, full_metrics, notes=""):
    """Combine held-out and full-data fit metrics for one model configuration."""
    return {
        "model": model,
        "hyperparameter_case": hyperparameter_case,
        "BO_objective": bo_objective,
        "R2": cv_metrics["R2"],
        "MAE": cv_metrics["MAE"],
        "RMSE": cv_metrics["RMSE"],
        "Full_R2": full_metrics["R2"],
        "Full_MAE": full_metrics["MAE"],
        "Full_RMSE": full_metrics["RMSE"],
        "notes": notes,
    }

metrics_rows = [
    make_metric_row("Mean baseline", "training-fold mean", "none", baseline_metrics, baseline_full_metrics, "No-learning reference."),
    make_metric_row("XGBoost", "base case", "none", xgb_base_metrics, xgb_base_full_metrics),
    make_metric_row("XGBoost", "BO optimized", "non-nested inner-CV R2", xgb_bo_metrics, xgb_bo_full_metrics, "Tuning-informed CV; retained for comparison."),
    make_metric_row("XGBoost", "Nested BO optimized", "nested inner-CV R2", xgb_nested_bo_metrics, xgb_bo_final_full_metrics, "Main predictive BO estimate."),
    make_metric_row("GPR", "base case", "none", gpr_base_metrics, gpr_base_full_metrics),
    make_metric_row("GPR", "BO optimized", "non-nested inner-CV R2", gpr_bo_metrics, gpr_bo_full_metrics, "Tuning-informed CV; retained for comparison."),
    make_metric_row("GPR", "Nested BO optimized", "nested inner-CV R2", gpr_nested_bo_metrics, gpr_bo_final_full_metrics, "Main predictive BO estimate."),
    make_metric_row("Ordinary linear regression", "base case", "none", linear_base_metrics, linear_base_full_metrics, "Classical OLS baseline; no regularization and no BO."),
]
metrics_df = pd.DataFrame(metrics_rows)
full_r2_summary_df = metrics_df[["model", "hyperparameter_case", "BO_objective", "Full_R2", "Full_MAE", "Full_RMSE"]].copy()

hyperparameter_summary_rows = []
def append_hyperparameter_summary(case, params):
    """Append the parameter values for one named model configuration."""
    for k, v in params.items():
        hyperparameter_summary_rows.append({"case": case, "parameter": k, "value": v})

append_hyperparameter_summary("XGBoost base case", xgb_params_base)
append_hyperparameter_summary("XGBoost final BO hyperparameters", xgb_params_bo_final)
append_hyperparameter_summary("GPR base case", gpr_params_base)
append_hyperparameter_summary("GPR final BO hyperparameters", gpr_params_bo_final)
append_hyperparameter_summary("Ordinary linear regression base case", linear_params_base)
hyperparameter_summary_df = pd.DataFrame(hyperparameter_summary_rows)

# -------------------------------------------------------------------
# Consolidated ML hyperparameter reporting
# -------------------------------------------------------------------
# This table makes the three ML hyperparameter cases directly comparable:
#   1) fixed base-case configuration,
#   2) one non-nested BO configuration selected on the full dataset, and
#   3) fold-specific nested-BO configurations selected independently inside
#      each outer training fold.
#
# For nested BO, the complete applied configuration is reconstructed by
# combining the fixed/base settings with the BO-selected values for that fold.
# Each configuration includes both tuned and fixed parameters.

def _append_hyperparameter_config_rows(
    rows, model, case, params, tuned_parameter_names=None,
    outer_fold=np.nan, held_out_paper='', held_out_group='',
    hyperparameter_source=''
):
    tuned_parameter_names = set(tuned_parameter_names or [])
    for parameter, value in params.items():
        rows.append({
            'model': model,
            'case': case,
            'outer_fold': outer_fold,
            'held_out_paper': held_out_paper,
            'held_out_group': held_out_group,
            'parameter': parameter,
            'value': value,
            'parameter_role': 'BO-tuned' if parameter in tuned_parameter_names else 'fixed',
            'hyperparameter_source': hyperparameter_source,
        })


def _append_nested_hyperparameter_configs(
    rows, model, base_params, nested_best_df, tuned_parameter_names
):
    tuned_parameter_names = list(tuned_parameter_names)
    if nested_best_df is None or nested_best_df.empty:
        return

    for outer_fold, fold_df in nested_best_df.groupby('outer_fold', sort=True):
        selected = fold_df[fold_df['parameter'].isin(tuned_parameter_names)].copy()
        selected_params = {
            str(r['parameter']): r['value']
            for _, r in selected.iterrows()
        }

        # Complete model configuration actually used in this outer fold.
        full_params = base_params.copy()
        full_params.update(selected_params)

        held_out_paper = ''
        held_out_group = ''
        if 'held_out_paper' in fold_df.columns:
            vals = [str(v) for v in fold_df['held_out_paper'].dropna().unique() if str(v).strip()]
            held_out_paper = ' | '.join(vals)
        if 'held_out_group' in fold_df.columns:
            vals = [str(v) for v in fold_df['held_out_group'].dropna().unique() if str(v).strip()]
            held_out_group = ' | '.join(vals)

        _append_hyperparameter_config_rows(
            rows=rows,
            model=model,
            case='Nested BO optimized',
            params=full_params,
            tuned_parameter_names=tuned_parameter_names,
            outer_fold=int(outer_fold),
            held_out_paper=held_out_paper,
            held_out_group=held_out_group,
            hyperparameter_source='BO selected independently inside this outer training fold',
        )


ml_hyperparameter_rows = []

# XGBoost base and non-nested BO configurations.
_append_hyperparameter_config_rows(
    ml_hyperparameter_rows,
    'XGBoost',
    'Base case',
    xgb_params_base,
    tuned_parameter_names=[],
    hyperparameter_source='Fixed base-case configuration; no BO',
)
_append_hyperparameter_config_rows(
    ml_hyperparameter_rows,
    'XGBoost',
    'Non-nested BO optimized',
    xgb_params_bo_final,
    tuned_parameter_names=xgb_search_space.keys(),
    hyperparameter_source='Single BO search on the full dataset',
)
_append_nested_hyperparameter_configs(
    ml_hyperparameter_rows,
    'XGBoost',
    xgb_params_base,
    xgb_nested_bo_best_params_df,
    xgb_search_space.keys(),
)

# GPR base and non-nested BO configurations.
_append_hyperparameter_config_rows(
    ml_hyperparameter_rows,
    'GPR',
    'Base case',
    gpr_params_base,
    tuned_parameter_names=[],
    hyperparameter_source='Fixed base-case configuration; no BO',
)
_append_hyperparameter_config_rows(
    ml_hyperparameter_rows,
    'GPR',
    'Non-nested BO optimized',
    gpr_params_bo_final,
    tuned_parameter_names=gpr_search_space.keys(),
    hyperparameter_source='Single BO search on the full dataset',
)
_append_nested_hyperparameter_configs(
    ml_hyperparameter_rows,
    'GPR',
    gpr_params_base,
    gpr_nested_bo_best_params_df,
    gpr_search_space.keys(),
)

# Ordinary linear regression has no BO-tuned parameters, but is included for
# completeness as a fixed base-case model.
_append_hyperparameter_config_rows(
    ml_hyperparameter_rows,
    'Ordinary linear regression',
    'Base case',
    linear_params_base,
    tuned_parameter_names=[],
    hyperparameter_source='Fixed OLS reference model; no BO',
)

ml_hyperparameters_complete_long_df = pd.DataFrame(ml_hyperparameter_rows)

# Wide version: one row per model/case/outer fold, convenient for inspection
# and supplementary reporting.
if not ml_hyperparameters_complete_long_df.empty:
    _hp_wide_source = ml_hyperparameters_complete_long_df.copy()
    # Use a text label so base/non-nested rows are retained in the pivot rather
    # than being dropped because their outer_fold is not applicable.
    _hp_wide_source['outer_fold_label'] = _hp_wide_source['outer_fold'].apply(
        lambda v: str(int(v)) if pd.notna(v) else 'not_applicable'
    )
    _hp_index_cols = [
        'model', 'case', 'outer_fold_label', 'held_out_paper', 'held_out_group',
        'hyperparameter_source'
    ]
    # Pivot first, then prefix parameter columns BEFORE reset_index().
    # This avoids a name collision when a hyperparameter itself is called
    # "model" (the OLS reporting dictionary contains a parameter named model)
    # while "model" is also one of the index/metadata columns.
    ml_hyperparameters_complete_wide_df = _hp_wide_source.pivot_table(
        index=_hp_index_cols,
        columns='parameter',
        values='value',
        aggfunc='first',
        dropna=False,
    )
    ml_hyperparameters_complete_wide_df.columns = [
        f"param__{c}" for c in ml_hyperparameters_complete_wide_df.columns
    ]
    ml_hyperparameters_complete_wide_df = ml_hyperparameters_complete_wide_df.reset_index()
    ml_hyperparameters_complete_wide_df.columns.name = None
else:
    ml_hyperparameters_complete_wide_df = pd.DataFrame()


# Prediction table — ML models only.
pred_df = df_model[[c for c in ID_COLS if c in df_model.columns]].copy()
pred_df["actual_Cyclohexene_yield_%"] = y.values
pred_df["mean_baseline_oof_pred_%"] = baseline_oof
pred_df["mean_baseline_full_data_pred_%"] = baseline_full_pred
pred_df["xgboost_base_oof_pred_%"] = xgb_base_oof
pred_df["xgboost_bo_non_nested_oof_pred_%"] = xgb_bo_oof
pred_df["xgboost_nested_bo_oof_pred_%"] = xgb_nested_bo_oof
pred_df["xgboost_base_full_data_pred_%"] = xgb_base_full_pred
pred_df["xgboost_bo_final_full_data_pred_%"] = xgb_bo_final_full_pred
pred_df["gpr_base_oof_pred_%"] = gpr_base_oof
pred_df["gpr_bo_non_nested_oof_pred_%"] = gpr_bo_oof
pred_df["gpr_nested_bo_oof_pred_%"] = gpr_nested_bo_oof
pred_df["gpr_base_full_data_pred_%"] = gpr_base_full_pred
pred_df["gpr_bo_final_full_data_pred_%"] = gpr_bo_final_full_pred
pred_df["ordinary_linear_regression_oof_pred_%"] = linear_base_oof
pred_df["ordinary_linear_regression_full_data_pred_%"] = linear_base_full_pred
pred_df.insert(0, "seed", 42)
pred_df.insert(1, "cv_strategy", CV_STRATEGY)

# -----------------------
# Consolidated outer-fold performance reporting
# -----------------------
# One long-form table covering baseline, fixed models, non-nested BO models,
# and nested BO models. R2/MAE/RMSE columns in the individual fold files remain
# outer-test metrics; explicit train_* and test_* columns are added for clarity.
baseline_fold_metrics_df = pd.DataFrame(baseline_fold_rows)

_outer_fold_frames = [
    baseline_fold_metrics_df,
    xgb_base_fold_metrics_df,
    xgb_bo_fold_metrics_df,
    xgb_nested_bo_fold_metrics_df,
    gpr_base_fold_metrics_df,
    gpr_bo_fold_metrics_df,
    gpr_nested_bo_fold_metrics_df,
    linear_base_fold_metrics_df,
]
outer_fold_performance_all_models_df = pd.concat(
    [d for d in _outer_fold_frames if d is not None and not d.empty],
    ignore_index=True,
    sort=False,
)

# Preferred reporting order.
_fold_report_cols = [
    "cv_strategy", "cv_strategy_label", "outer_fold", "fold",
    "held_out_unit", "held_out_paper", "held_out_group", "held_out_catalysts",
    "test_Author", "test_Source_study", "test_Reference", "test_Paper",
    "model", "case", "hyperparameter_source",
    "train_size", "test_size",
    "train_R2", "train_MAE", "train_RMSE",
    "test_R2", "test_MAE", "test_RMSE",
    "best_inner_cv_R2", "bo_runtime_seconds", "test_row_indices",
]
_fold_report_cols = [c for c in _fold_report_cols if c in outer_fold_performance_all_models_df.columns]
_other_cols = [c for c in outer_fold_performance_all_models_df.columns if c not in _fold_report_cols]
outer_fold_performance_all_models_df = outer_fold_performance_all_models_df[_fold_report_cols + _other_cols]

# Dedicated LOPO table: one row per model/case/paper with the paper explicitly named.
if CV_STRATEGY == "leave_one_paper_out":
    lopo_per_paper_performance_df = outer_fold_performance_all_models_df.copy()
    lopo_per_paper_performance_df["model_case"] = (
        lopo_per_paper_performance_df["model"].astype(str)
        + " | "
        + lopo_per_paper_performance_df["case"].astype(str)
    )

    # Compact wide table for manuscript inspection: held-out paper × model/case × metric.
    lopo_per_paper_test_metrics_wide_df = lopo_per_paper_performance_df.pivot_table(
        index=["outer_fold", "held_out_paper", "test_size"],
        columns="model_case",
        values=["test_R2", "test_MAE", "test_RMSE"],
        aggfunc="first",
    )
    lopo_per_paper_test_metrics_wide_df.columns = [
        f"{model_case} | {metric}" for metric, model_case in lopo_per_paper_test_metrics_wide_df.columns
    ]
    lopo_per_paper_test_metrics_wide_df = lopo_per_paper_test_metrics_wide_df.reset_index()
else:
    lopo_per_paper_performance_df = pd.DataFrame()
    lopo_per_paper_test_metrics_wide_df = pd.DataFrame()

# -----------------------
# Save ML-only outputs
# -----------------------
log("Collecting regression result tables")
collect_result_table(metrics_df, "model_metrics.csv")
collect_result_table(full_r2_summary_df, "model_full_R2_summary.csv")
collect_result_table(hyperparameter_summary_df, "hyperparameter_summary_base_and_BO.csv")
collect_result_table(ml_hyperparameters_complete_long_df, "ML_hyperparameters_base_non_nested_nested_LONG.csv")
collect_result_table(ml_hyperparameters_complete_wide_df, "ML_hyperparameters_base_non_nested_nested_WIDE.csv")
collect_result_table(rare_feature_filter_report_df, "rare_feature_filter_report.csv")
collect_result_table(missing_df, "missing_values_before_zero_fill.csv")
collect_result_table(selected_cv_metadata_df, "selected_cv_strategy_metadata.csv")
collect_result_table(ind_shap, "xgboost_BO_individual_SHAP_importance.csv")
collect_result_table(group_shap_df, "xgboost_BO_grouped_SHAP_importance.csv")
collect_result_table(pred_df, "out_of_fold_and_full_data_predictions.csv")

# Repeated-seed stability tables.
collect_result_table(seed_metrics_long_df, f"model_metrics_by_seed_{N_SEED_REPEATS}runs.csv")
collect_result_table(seed_metrics_summary_df, f"model_metrics_mean_SD_{N_SEED_REPEATS}seeds.csv")
collect_result_table(seed_predictions_long_df, f"OOF_predictions_by_seed_{N_SEED_REPEATS}runs_LONG.csv")
collect_result_table(seed_predictions_summary_df, f"OOF_predictions_mean_SD_{N_SEED_REPEATS}seeds.csv")
collect_result_table(multi_seed_outer_fold_metrics_df, f"outer_fold_metrics_all_models_all_{N_SEED_REPEATS}seeds.csv")
collect_result_table(multi_seed_non_nested_best_params_df, f"non_nested_BO_best_params_all_{N_SEED_REPEATS}seeds.csv")
collect_result_table(multi_seed_nested_best_params_df, f"nested_BO_best_params_all_{N_SEED_REPEATS}seeds.csv")

collect_result_table(baseline_fold_metrics_df, "mean_baseline_fold_metrics.csv")
collect_result_table(outer_fold_performance_all_models_df, "outer_fold_performance_all_models.csv")
if CV_STRATEGY == "leave_one_paper_out":
    collect_result_table(lopo_per_paper_performance_df, "LOPO_per_paper_outer_fold_performance.csv")
    collect_result_table(lopo_per_paper_test_metrics_wide_df, "LOPO_per_paper_test_metrics_wide.csv")
collect_result_table(xgb_base_fold_metrics_df, "xgboost_base_fold_metrics.csv")
collect_result_table(xgb_bo_fold_metrics_df, "xgboost_BO_non_nested_fold_metrics.csv")
collect_result_table(xgb_nested_bo_fold_metrics_df, "xgboost_nested_BO_fold_metrics.csv")
collect_result_table(gpr_base_fold_metrics_df, "gpr_base_fold_metrics.csv")
collect_result_table(gpr_bo_fold_metrics_df, "gpr_BO_non_nested_fold_metrics.csv")
collect_result_table(gpr_nested_bo_fold_metrics_df, "gpr_nested_BO_fold_metrics.csv")
collect_result_table(linear_base_fold_metrics_df, "ordinary_linear_regression_fold_metrics.csv")

collect_result_table(xgb_bo_results_df, "xgboost_BO_non_nested_trials.csv")
collect_result_table(xgb_bo_best_params_df, "xgboost_BO_non_nested_best_params.csv")
collect_result_table(xgb_nested_bo_results_df, "xgboost_nested_BO_trials_by_outer_fold.csv")
collect_result_table(xgb_nested_bo_best_params_df, "xgboost_nested_BO_best_params_by_outer_fold.csv")
collect_result_table(gpr_bo_results_df, "gpr_BO_non_nested_trials.csv")
collect_result_table(gpr_bo_best_params_df, "gpr_BO_non_nested_best_params.csv")
collect_result_table(gpr_nested_bo_results_df, "gpr_nested_BO_trials_by_outer_fold.csv")
collect_result_table(gpr_nested_bo_best_params_df, "gpr_nested_BO_best_params_by_outer_fold.csv")


def export_deferred_loo_learning_inputs():
    """Save seed-42 LOO learning-curve inputs without fitting/tuning any model.

    Later curve generation can fix each fold's existing nested-BO parameters
    and refit only reduced training subsets. At fraction 1, reuse the saved
    validation and pooled training scores; no new fit is needed there either.
    """
    import hashlib

    bundle = OUT_DIR / "learning_curve_inputs_seed42"
    bundle.mkdir(parents=True, exist_ok=True)
    features = X_ml.copy()
    features.insert(0, "row_index", np.arange(len(y), dtype=int))
    features.to_csv(bundle / "processed_features_seed42.csv", index=False)
    observations = pred_df.copy()
    observations.insert(0, "row_index", np.arange(len(y), dtype=int))
    observations.to_csv(bundle / "OOF_predictions_seed42.csv", index=False)
    splits = [
        {"outer_fold": int(fold), "train_indices": np.asarray(tr, dtype=int).tolist(),
         "test_indices": np.asarray(te, dtype=int).tolist()}
        for fold, (tr, te) in enumerate(cv_splits, 1)
    ]
    (bundle / "outer_cv_splits_seed42.json").write_text(
        json.dumps(splits, indent=2), encoding="utf-8")

    frames = {
        "xgboost_nested_BO_best_params_by_outer_fold.csv": xgb_nested_bo_best_params_df,
        "gpr_nested_BO_best_params_by_outer_fold.csv": gpr_nested_bo_best_params_df,
        "xgboost_nested_BO_fold_metrics.csv": xgb_nested_bo_fold_metrics_df,
        "gpr_nested_BO_fold_metrics.csv": gpr_nested_bo_fold_metrics_df,
        "ordinary_linear_regression_fold_metrics.csv": linear_base_fold_metrics_df,
        "rare_feature_filter_report.csv": rare_feature_filter_report_df,
    }
    for filename, frame in frames.items():
        frame.to_csv(bundle / filename, index=False)
    settings = {
        "xgboost_base_parameters": xgb_params_base,
        "gpr_base_parameters": gpr_params_base,
        "gpr_kernel": GPR_KERNEL, "gpr_alpha_fixed": GPR_ALPHA_FIXED,
        "xgboost_bo_enabled": RUN_XGB_BAYES_OPT, "gpr_bo_enabled": RUN_GPR_BAYES_OPT,
        "descriptor_filter_enabled": APPLY_RARE_FEATURE_FILTER_TO_ML,
        "feature_columns": list(X_ml.columns),
        "scaling": "GPR and OLS fit StandardScaler within each training subset",
        "estimator_definitions": "See the copy of this training script in the parent result folder",
    }
    (bundle / "model_settings_seed42.json").write_text(
        json.dumps(settings, indent=2, default=str), encoding="utf-8")

    # Pool training metrics from the already-saved fold scores. RMSE squared
    # gives fold SSE/n, so no training predictions or new model fits are needed.
    repeated_train_actual = np.concatenate([
        y.iloc[np.asarray(tr, dtype=int)].to_numpy(dtype=float) for tr, _ in cv_splits
    ])
    pooled_train_sst = float(np.sum((repeated_train_actual - repeated_train_actual.mean()) ** 2))
    sizes = np.asarray([len(tr) for tr, _ in cv_splits], dtype=float)
    endpoint_rows = []
    for model_name, folds, oof in (
        ("XGBoost nested BO", xgb_nested_bo_fold_metrics_df, xgb_nested_bo_oof),
        ("GPR nested BO", gpr_nested_bo_fold_metrics_df, gpr_nested_bo_oof),
        ("Ordinary linear regression", linear_base_fold_metrics_df, linear_base_oof),
    ):
        fold_key = "outer_fold" if "outer_fold" in folds else "fold"
        folds = folds.sort_values(fold_key)
        if folds[fold_key].tolist() != list(range(1, len(cv_splits) + 1)):
            raise ValueError(f"Incomplete fold metrics for deferred LOO curve: {model_name}")
        weights = pd.to_numeric(folds["train_size"], errors="raise").to_numpy(dtype=float)
        if not np.array_equal(weights, sizes):
            raise ValueError(f"Training sizes do not match the saved LOO splits: {model_name}")
        rmse = pd.to_numeric(folds["train_RMSE"], errors="raise").to_numpy(dtype=float)
        mae = pd.to_numeric(folds["train_MAE"], errors="raise").to_numpy(dtype=float)
        if not np.isfinite(rmse).all() or not np.isfinite(mae).all():
            raise ValueError(f"Nonfinite training metrics for deferred LOO curve: {model_name}")
        sse = float(np.sum(weights * rmse ** 2))
        if pooled_train_sst > 0:
            train_r2 = 1.0 - sse / pooled_train_sst
        else:
            # Match the existing finite R2 convention for a constant target.
            train_r2 = 1.0 if sse == 0 else 0.0
        validation = metrics_safe(y, oof)
        endpoint_rows.append({
            "cv_strategy": CV_STRATEGY, "seed": 42, "model": model_name,
            "train_fraction": 1.0, "mean_outer_train_rows_used": float(sizes.mean()),
            "min_outer_train_rows_used": int(sizes.min()),
            "max_outer_train_rows_used": int(sizes.max()),
            "train_R2": train_r2, "train_MAE": float(np.average(mae, weights=weights)),
            "train_RMSE": float(np.sqrt(sse / weights.sum())),
            **{f"validation_{key}": value for key, value in validation.items()},
            "validation_aggregation": "pooled outer-test predictions",
            "training_aggregation": "pooled original outer-training rows",
            "source": "reused original seed-42 LOO results; no extra fitting or tuning",
        })
    endpoint = pd.DataFrame(endpoint_rows)
    filename = "learning_curve_full_size_metrics_seed42.csv"
    endpoint.to_csv(bundle / filename, index=False)
    endpoint.to_csv(OUT_DIR / filename, index=False)
    collect_result_table(endpoint, filename)
    manifest = {
        "target": TARGET_NAME, "cv_strategy": CV_STRATEGY, "seed": 42,
        "n_rows": len(y), "n_outer_folds": len(cv_splits),
        "workbook_sha256": hashlib.sha256(Path(INPUT_FILE).read_bytes()).hexdigest(),
        "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "row_indices": "zero-based positions shared by features, observations, and splits",
        "smaller_fraction_learning_curves_generated": False,
        "full_size_metrics_reused": True,
        "later_method": "Reuse fold-specific nested BO parameters. Refit reduced training subsets only; do not run Bayesian optimization again.",
        "parameter_fallback": "If a model's BO was disabled, use its saved base parameters.",
    }
    (bundle / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    log(f"Saved LOO inputs for later learning curves, without additional fits: {bundle}")
    return bundle


# Always export dedicated plotting inputs, independently of SAVE_CSV_TABLES.
# LOO skips all learning-curve fraction fits/tuning; original model plots follow.
learning_curve_df = generate_learning_curves(globals()) if RUN_LEARNING_CURVES else None
export_plot_inputs(globals(), learning_curve_df)
DEFERRED_LOO_INPUTS_DIR = None
if LOO_LEARNING_CURVES_DEFERRED:
    DEFERRED_LOO_INPUTS_DIR = export_deferred_loo_learning_inputs()
    _plot_case_dir = OUTPUT_ROOT / "oof_learning_curves" / FILTER_CASE / TARGET_NAME / CV_STRATEGY
    shutil.copytree(DEFERRED_LOO_INPUTS_DIR, _plot_case_dir / DEFERRED_LOO_INPUTS_DIR.name, dirs_exist_ok=True)
    _metadata_path = OUT_DIR / "run_metadata.json"
    _metadata = json.loads(_metadata_path.read_text(encoding="utf-8"))
    _metadata.update(learning_curves_deferred=True,
                     learning_curve_inputs_directory=DEFERRED_LOO_INPUTS_DIR.name,
                     learning_curve_full_size_metrics_reused=True)
    _metadata_path.write_text(json.dumps(_metadata, indent=2), encoding="utf-8")

# -----------------------
# Plots
# -----------------------


log("Generating plots")

# ===========================================================
# Dataset-level target, support-distribution and model plots
# Figures use the first seed for model predictions and SHAP interpretation.
# ===========================================================
DPI = 300
TARGET_LABEL = "Cyclohexene yield (%)"
DATASET_PLOT_TITLE = "Literature dataset"

# Use consistent typography for all exported figures.
plt.rcParams.update({
    "font.family": "sans-serif",
    "font.sans-serif": ["DejaVu Sans", "Arial", "Liberation Sans"],
    "font.size": 12,
    "axes.titlesize": 13,
    "axes.labelsize": 12,
    "xtick.labelsize": 10.5,
    "ytick.labelsize": 10.5,
    "legend.fontsize": 11,
    "figure.titlesize": 15,
    "axes.linewidth": 0.9,
    "savefig.dpi": DPI,
})

# Assign a consistent colour to each model and tuning case.
MODEL_COLORS = {
    "xgb_base": "tab:blue",
    "xgb_bo": "tab:orange",
    "xgb_nested": "tab:green",
    "gpr_base": "tab:green",
    "gpr_bo": "tab:red",
    "gpr_nested": "tab:purple",
    "ols": "tab:brown",
}


def style_axis(ax, grid=False, grid_axis="both"):
    """Apply axis-line widths, tick styling and an optional light grid."""
    if grid:
        ax.grid(True, axis=grid_axis, alpha=0.20, linewidth=0.8)
    for spine in ax.spines.values():
        spine.set_linewidth(0.9)
    ax.tick_params(width=0.9)


# Display labels for descriptor names used in SHAP figures.
READABLE_FEATURE_NAME_MAP = {
    "Metal_Pt": "Metal: Pt",
    "Metal_Pd": "Metal: Pd",
    "Metal_Ni": "Metal: Ni",
    "Metal_Ru": "Metal: Ru",
    "Metal_ratio_%": "Metal ratio (%)",
    "Is_Zn": "Zn promoter present",
    "Zn/Ru_g": "Zn/Ru ratio",
    "Is_water_volume_reported": "Water amount reported",
    "Reaction_water_ml": "Reaction water (ml)",
    "Is_benzene_volume_reported": "Benzene amount reported",
    "Reaction_benzene_ml": "Reaction benzene (ml)",
    "Is_Crosslinked": "Crosslinked polymer",
    "Is_crosslinker_methylene_bisacrylamide": "Crosslinker: MBA",
    "Is_crosslinker_divinylbenzene": "Crosslinker: DVB",
    "Crosslinker_mol_%": "Crosslinker (mol%)",
    "Reaction_Pressure_bar": "Reaction pressure (bar)",
    "Is_pressure_reported": "Pressure reported",
    "Reaction_H2_pressure_bar": "H\u2082 pressure (bar)",
    "Is_H2_pressure_reported": "H\u2082 pressure reported",
    "Is_H2/C6H6_ratio_reported": "H\u2082/benzene ratio reported",
    "H2_to_Benzene_ratio": "H\u2082/benzene ratio",
    "Preparation_time_h": "Preparation time (h)",
    "Preparation_temperature_C": "Preparation temperature (°C)",
    "Reaction_temperature_C": "Reaction temperature (°C)",
    "Is_Reaction_time_reported": "Reaction time reported",
    "Reaction_time_min": "Reaction time (min)",
    "Is_Contact_time_reported": "Contact time reported",
    "Contact_time_s": "Contact time (s)",
    "Is_CS-N-n-Propyl-Membrane": "Support: N-n-propyl chitosan membrane",
    "Is_PVP_clinopti": "Support: PVP-clinoptilolite",
    "Is_unsupported_metal": "Unsupported (Powder/Nano-clusters)",
    "Is_Carbon": "Support: carbon",
    "Is_S4NR": "Support: S4NR",
    "Is_P4NR": "Support: P4NR",
    "Is_S8NR": "Support: S8NR",
    "Is_M4KR": "Support: M4KR",
    "Is_NY6": "Support: Nylon-6",
    "Is_NY3": "Support: Nylon-3",
    "Is_PAA": "Support: Polyacrylamide (PAA)",
    "Is_PFT": "Support: Poly-p-phenyleneterephthalamide (PFT)",
    "Is_PAAO": "Support: Polyacrylamideoxime (PAAO)",
    "Is_PAN": "Support: Polyacrylonitrile (PAN)",
}


def readable_feature_name(name):
    """Map a descriptor column to its display label for figures."""
    if name in READABLE_FEATURE_NAME_MAP:
        return READABLE_FEATURE_NAME_MAP[name]
    # Conservative fallback: improve readability without changing meaning.
    return str(name).replace("_", " ").replace("H2", "H\u2082").strip()


X_shap_readable = X_ml.rename(columns={c: readable_feature_name(c) for c in X_ml.columns})

SUPPORT_DESCRIPTOR_MAP = {
    "Is_CS-N-n-Propyl-Membrane": "N-n-propyl chitosan membrane",
    "Is_PVP_clinopti": "PVP-Clinoptilolite",
    "Is_unsupported_metal": "Unsupported (Powder/Nano-clusters)",
    "Is_Carbon": "Carbon",
    "Is_S4NR": "S4NR",
    "Is_P4NR": "P4NR",
    "Is_S8NR": "S8NR",
    "Is_M4KR": "M4KR",
    "Is_NY6": "Nylon-6 (NY6)",
    "Is_NY3": "Nylon-3 (NY3)",
    "Is_PAA": "Polyacrylamide (PAA)",
    "Is_PFT": "Poly-p-phenyleneterephthalamide (PFT)",
    "Is_PAAO": "Polyacrylamideoxime (PAAO)",
    "Is_PAN": "Polyacrylonitrile (PAN)",
}

SUPPORT_DESCRIPTOR_COLS = [c for c in SUPPORT_DESCRIPTOR_MAP if c in df_model.columns]
missing_support_cols = [c for c in SUPPORT_DESCRIPTOR_MAP if c not in df_model.columns]
if missing_support_cols:
    log("Support descriptor columns not found and skipped: " + ", ".join(missing_support_cols))
if not SUPPORT_DESCRIPTOR_COLS:
    raise ValueError("No support descriptor columns were found in df_model. Check SUPPORT_DESCRIPTOR_MAP.")

# Distribution of observed target values across experiments.
fig, ax = plt.subplots(figsize=(8, 5))
ax.hist(y, bins=12, edgecolor="black", linewidth=0.9, alpha=0.85, color="tab:blue")
ax.set_xlabel(TARGET_LABEL)
ax.set_ylabel("Number of experiments")
ax.set_title(f"{DATASET_PLOT_TITLE}\nTarget distribution")
style_axis(ax)
fig.tight_layout()
fig.savefig(os.path.join(OUT_DIR, "01_target_distribution_histogram.png"), dpi=DPI, bbox_inches="tight")
plt.close(fig)

# Construct occurrence-based long table for support descriptors.
# An experiment can contribute to several support categories.
support_long_rows = []
support_signature_rows = []
for idx, row in df_model.iterrows():
    active_supports = []
    for col in SUPPORT_DESCRIPTOR_COLS:
        val = pd.to_numeric(row.get(col, 0), errors="coerce")
        if pd.notna(val) and float(val) >= 0.5:
            support_name = SUPPORT_DESCRIPTOR_MAP[col]
            active_supports.append(support_name)
            support_long_rows.append({
                "row_index": int(idx),
                "support_column": col,
                "support_type": support_name,
                TARGET: float(row[TARGET]),
                "Author": row.get("Author", ""),
                "Catalyst_ID2": row.get("Catalyst_ID2", ""),
                "Catalyst": row.get("Catalyst", ""),
            })
    support_signature_rows.append({
        "row_index": int(idx),
        "support_signature": " + ".join(active_supports) if active_supports else "No active support descriptor",
        "n_active_support_descriptors": len(active_supports),
        TARGET: float(row[TARGET]),
        "Author": row.get("Author", ""),
        "Catalyst_ID2": row.get("Catalyst_ID2", ""),
        "Catalyst": row.get("Catalyst", ""),
    })

support_long_df = pd.DataFrame(support_long_rows)
support_signature_df = pd.DataFrame(support_signature_rows)
if support_long_df.empty:
    raise ValueError("No active support descriptors were found. Check that support columns use 1/0 encoding.")

support_count_order = support_long_df["support_type"].value_counts().index.tolist()
support_counts = support_long_df["support_type"].value_counts().rename("n_occurrences").reset_index()
support_counts.columns = ["support_type", "n_occurrences"]
support_stats_df = (
    support_long_df.groupby("support_type")[TARGET]
    .agg(n_occurrences="count", mean_yield="mean", median_yield="median", std_yield="std", min_yield="min", max_yield="max")
    .reindex(support_count_order)
    .reset_index()
)
support_stats_df["std_yield"] = support_stats_df["std_yield"].fillna(0.0)

support_signature_counts_df = (
    support_signature_df["support_signature"].value_counts().rename("n_experiments").reset_index()
)
support_signature_counts_df.columns = ["support_signature", "n_experiments"]

collect_result_table(support_long_df, "support_occurrence_yield_long_table.csv")
collect_result_table(support_stats_df, "support_occurrence_yield_summary.csv")
collect_result_table(support_signature_df, "support_signature_by_experiment.csv")
collect_result_table(support_signature_counts_df, "support_signature_counts.csv")
log("Support occurrence summary collected. Active support descriptors: " + ", ".join([f"{r.support_type} (n={int(r.n_occurrences)})" for r in support_stats_df.itertuples()]))

# Use a categorical palette to distinguish support descriptors.
base_palette = sns.color_palette("tab20", n_colors=max(20, len(support_count_order)))
support_palette = {name: base_palette[i % len(base_palette)] for i, name in enumerate(support_count_order)}
support_labels_with_n = {
    row["support_type"]: f"{row['support_type']}\n(n={int(row['n_occurrences'])})"
    for _, row in support_stats_df.iterrows()
}
support_long_df["support_label"] = support_long_df["support_type"].map(support_labels_with_n)
support_order_labels = [support_labels_with_n[s] for s in support_count_order]
support_palette_labels = {support_labels_with_n[k]: v for k, v in support_palette.items()}

# 1) Boxplot + individual observations by support occurrence.
fig, ax = plt.subplots(figsize=(max(11, 0.75 * len(support_count_order)), 6.5))
sns.boxplot(
    data=support_long_df, x="support_label", y=TARGET, hue="support_label",
    order=support_order_labels, hue_order=support_order_labels,
    palette=support_palette_labels, legend=False, showfliers=True, linewidth=1.1, ax=ax,
)
sns.stripplot(
    data=support_long_df, x="support_label", y=TARGET, order=support_order_labels,
    color="black", alpha=0.50, size=3.2, jitter=True, ax=ax,
)
ax.set_xlabel("Support descriptor occurrence")
ax.set_ylabel(TARGET_LABEL)
ax.set_title(f"{DATASET_PLOT_TITLE}\nCyclohexene yield distribution by support descriptor")
ax.tick_params(axis="x", rotation=40)
for label in ax.get_xticklabels():
    label.set_ha("right")
style_axis(ax)
fig.tight_layout()
fig.savefig(os.path.join(OUT_DIR, "11_boxplot_yield_by_support_occurrence.png"), dpi=DPI, bbox_inches="tight")
plt.close(fig)

# 2) Violin + box + individual observations by support occurrence.
fig, ax = plt.subplots(figsize=(max(11, 0.75 * len(support_count_order)), 6.5))
sns.violinplot(
    data=support_long_df, x="support_label", y=TARGET, hue="support_label",
    order=support_order_labels, hue_order=support_order_labels,
    palette=support_palette_labels, legend=False, inner=None, cut=0, linewidth=1.0, ax=ax,
)
sns.boxplot(
    data=support_long_df, x="support_label", y=TARGET, order=support_order_labels,
    width=0.18, color="white", showcaps=True, showfliers=False,
    boxprops={"facecolor": "white", "edgecolor": "black", "alpha": 0.90},
    medianprops={"color": "black", "linewidth": 1.2},
    whiskerprops={"color": "black", "linewidth": 1.0},
    capprops={"color": "black", "linewidth": 1.0}, ax=ax,
)
sns.stripplot(
    data=support_long_df, x="support_label", y=TARGET, order=support_order_labels,
    color="black", alpha=0.42, size=3.0, jitter=True, ax=ax,
)
ax.set_xlabel("Support descriptor occurrence")
ax.set_ylabel(TARGET_LABEL)
ax.set_title(f"{DATASET_PLOT_TITLE}\nCyclohexene yield distribution by support descriptor")
ax.tick_params(axis="x", rotation=40)
for label in ax.get_xticklabels():
    label.set_ha("right")
style_axis(ax)
fig.tight_layout()
fig.savefig(os.path.join(OUT_DIR, "12_violin_yield_by_support_occurrence.png"), dpi=DPI, bbox_inches="tight")
plt.close(fig)

# 3) Stacked target-distribution chart by support occurrence.
yield_min = float(np.nanmin(y))
yield_max = float(np.nanmax(y))
yield_upper = max(0, np.ceil(yield_max / 5.0) * 5.0)
yield_bins = np.arange(0.0, yield_upper + 5.0, 5.0)
if yield_bins[-1] < yield_max:
    yield_bins = np.append(yield_bins, yield_max)
yield_labels = [f"{int(yield_bins[i])}-{int(yield_bins[i + 1])}" for i in range(len(yield_bins) - 1)]
support_long_df["yield_range"] = pd.cut(
    support_long_df[TARGET], bins=yield_bins, labels=yield_labels, include_lowest=True, right=True,
)
stack_table = pd.crosstab(support_long_df["yield_range"], support_long_df["support_type"])
stack_table = stack_table.reindex(index=yield_labels, columns=support_count_order, fill_value=0)
legend_labels = [
    f"{s} (n={int(support_stats_df.loc[support_stats_df['support_type'] == s, 'n_occurrences'].iloc[0])})"
    for s in support_count_order
]
ax = stack_table.plot(
    kind="bar", stacked=True, figsize=(max(10, 0.75 * len(yield_labels)), 6.5),
    width=0.78, color=[support_palette[s] for s in support_count_order], edgecolor="black", linewidth=0.35,
)
ax.set_xlabel("Cyclohexene yield range (%)")
ax.set_ylabel("Number of support occurrences")
ax.set_title("Target distribution: Cyclohexene yield")
ax.set_yticks(np.arange(0, ax.get_ylim()[1] + 5, 5)) 
ax.tick_params(axis="x", rotation=35)
for label in ax.get_xticklabels():
    label.set_ha("right")
handles, _labels = ax.get_legend_handles_labels()
ax.legend(handles, legend_labels, title="Catalyst support", bbox_to_anchor=(1.02, 1), loc="upper left", fontsize=9, title_fontsize=10, frameon=True)
style_axis(ax)
ax.figure.tight_layout()
ax.figure.savefig(os.path.join(OUT_DIR, "13_stacked_target_distribution_by_support_occurrence.png"), dpi=DPI, bbox_inches="tight")
plt.close(ax.figure)

# 4) Mean yield ± SD by support occurrence.
fig, ax = plt.subplots(figsize=(max(11, 0.75 * len(support_count_order)), 6.5))
bar_x = np.arange(len(support_stats_df))
bar_labels = [support_labels_with_n[s] for s in support_stats_df["support_type"]]
bar_colors = [support_palette[s] for s in support_stats_df["support_type"]]
ax.bar(
    bar_x, support_stats_df["mean_yield"], yerr=support_stats_df["std_yield"], capsize=4,
    edgecolor="black", linewidth=0.8, color=bar_colors, alpha=0.88,
)
ax.set_xticks(bar_x)
ax.set_xticklabels(bar_labels, rotation=40, ha="right")
ax.set_xlabel("Support descriptor occurrence")
ax.set_ylabel("Mean cyclohexene yield (%)")
ax.set_title("Average cyclohexene yield by catalyst support")
style_axis(ax, grid=True, grid_axis="y")
fig.tight_layout()
fig.savefig(os.path.join(OUT_DIR, "14_mean_yield_by_support_occurrence.png"), dpi=DPI, bbox_inches="tight")
plt.close(fig)

# 5) Exact support-combination counts per experiment.
plot_sig = support_signature_counts_df.head(20).iloc[::-1]
fig, ax = plt.subplots(figsize=(10, max(5.5, 0.33 * len(plot_sig))))
ax.barh(plot_sig["support_signature"], plot_sig["n_experiments"], edgecolor="black", linewidth=0.7, color="tab:blue", alpha=0.85)
ax.set_xlabel("Number of experiments")
ax.set_ylabel("Exact active support-descriptor combination")
ax.set_title("Support-descriptor combinations")
style_axis(ax, grid=True, grid_axis="x")
fig.tight_layout()
fig.savefig(os.path.join(OUT_DIR, "15_support_signature_counts.png"), dpi=DPI, bbox_inches="tight")
plt.close(fig)

# 6) Number of experiments per literature source.
PAPER_COL = "Reference" if "Reference" in df_model.columns else ("Author" if "Author" in df_model.columns else None)
if PAPER_COL is not None:
    paper_counts = df_model[PAPER_COL].astype(str).value_counts()
    fig, ax = plt.subplots(figsize=(9, max(5, 0.35 * len(paper_counts))))
    ax.barh(paper_counts.index[::-1], paper_counts.values[::-1], edgecolor="black", linewidth=0.7, color="tab:blue", alpha=0.85)
    ax.set_xlabel("Number of experiments")
    ax.set_ylabel(PAPER_COL)
    ax.set_title("Experiments contributed by each study")
    style_axis(ax, grid=True, grid_axis="x")
    fig.tight_layout()
    fig.savefig(os.path.join(OUT_DIR, "16_experiments_per_paper.png"), dpi=DPI, bbox_inches="tight")
    plt.close(fig)


def _prediction_limits(actual, pred_arrays):
    actual_arr = np.asarray(actual, dtype=float)
    all_pred = np.concatenate([np.asarray(p, dtype=float) for p in pred_arrays])
    minv = min(float(np.nanmin(actual_arr)), float(np.nanmin(all_pred)))
    maxv = max(float(np.nanmax(actual_arr)), float(np.nanmax(all_pred)))
    pad = 0.05 * (maxv - minv) if maxv > minv else 1.0
    return minv - pad, maxv + pad


def _metric_box_text(actual, pred):
    m = metrics(actual, pred)
    return f"CV R² = {m['R2']:.3f}\nCV MAE = {m['MAE']:.3f}\nCV RMSE = {m['RMSE']:.3f}"


def plot_predictions_against_observations(pred, title, filename, color="tab:blue", marker="o", ylabel=None):
    """Plot held-out predictions against observations with a 1:1 reference line."""
    pred = np.asarray(pred, dtype=float)
    ylabel = ylabel or f"OOF predicted {TARGET_LABEL.lower()}"
    fig, ax = plt.subplots(figsize=(6.5, 6))
    ax.scatter(y, pred, alpha=0.80, s=60, edgecolor="black", linewidth=0.7, color=color, marker=marker)
    lo, hi = _prediction_limits(y, [pred])
    ax.plot([lo, hi], [lo, hi], linestyle="--", color="black", linewidth=1.2)
    ax.set_xlim(lo, hi)
    ax.set_ylim(lo, hi)
    ax.set_xlabel(f"Actual {TARGET_LABEL.lower()}")
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    style_axis(ax, grid=True)
    fig.tight_layout()
    fig.savefig(os.path.join(OUT_DIR, filename), dpi=DPI, bbox_inches="tight")
    plt.close(fig)


def plot_model_tuning_comparison(actual, pred_list, titles, case_labels, colors, filename, fig_title):
    """Compare base, non-nested BO and nested BO predictions for one model family."""
    actual_arr = np.asarray(actual, dtype=float)
    pred_arrays = [np.asarray(p, dtype=float) for p in pred_list]
    fig, axes = plt.subplots(1, 3, figsize=(18, 8), sharex=False, sharey=False)
    lo, hi = _prediction_limits(actual_arr, pred_arrays)

    handles = []
    for i, ax in enumerate(axes):
        pred = pred_arrays[i]
        sc = ax.scatter(
            actual_arr, pred, s=60, marker="o", color=colors[i], alpha=0.82,
            edgecolor="black", linewidth=0.7, label=case_labels[i],
        )
        handles.append(sc)
        ax.plot([lo, hi], [lo, hi], linestyle="--", color="black", linewidth=1.2)
        ax.set_xlim(lo, hi)
        ax.set_ylim(lo, hi)
        ax.set_title(titles[i], fontsize=11)
        ax.set_xlabel(f"Actual {TARGET_LABEL.lower()}")
        if i == 0:
            ax.set_ylabel(f"OOF predicted {TARGET_LABEL.lower()}")
        ax.text(
            0.05, 0.95, _metric_box_text(actual_arr, pred), transform=ax.transAxes,
            va="top", ha="left", fontsize=11,
            bbox=dict(boxstyle="round", facecolor="white", alpha=0.85, edgecolor="gray"),
        )
        ax.text(0.5, -0.18, f"({chr(97+i)})", transform=ax.transAxes, ha="center", va="top", fontsize=15)
        style_axis(ax, grid=True)

    fig.legend(handles=handles, labels=case_labels, loc="lower center", bbox_to_anchor=(0.5, -0.05), ncol=3, frameon=True)
    fig.suptitle(fig_title, fontsize=17, y=1.03)
    fig.tight_layout()
    save_path = os.path.join(OUT_DIR, filename)
    fig.savefig(save_path, dpi=DPI, bbox_inches="tight")
    plt.close(fig)
    log(f"Saved 3-panel comparison plot: {save_path}")


# Predicted-versus-observed figures for each model and tuning case.
plot_predictions_against_observations(xgb_base_oof, f"XGBoost base-case CV\n{CV_DISPLAY_NAME}", "02a_xgboost_base_cv_predicted_vs_actual.png", color=MODEL_COLORS["xgb_base"])
plot_predictions_against_observations(xgb_bo_oof, f"XGBoost non-nested BO CV\n{CV_DISPLAY_NAME}", "02b_xgboost_BO_non_nested_cv_predicted_vs_actual.png", color=MODEL_COLORS["xgb_bo"])
plot_predictions_against_observations(xgb_nested_bo_oof, f"XGBoost nested BO CV\n{CV_DISPLAY_NAME}", "02c_xgboost_nested_BO_cv_predicted_vs_actual.png", color=MODEL_COLORS["xgb_nested"])
plot_predictions_against_observations(gpr_base_oof, f"GPR base-case CV\n{CV_DISPLAY_NAME}", "02d1_gpr_base_cv_predicted_vs_actual.png", color=MODEL_COLORS["gpr_base"])
plot_predictions_against_observations(gpr_bo_oof, f"GPR non-nested BO CV\n{CV_DISPLAY_NAME}", "02d2_gpr_BO_non_nested_cv_predicted_vs_actual.png", color=MODEL_COLORS["gpr_bo"])
plot_predictions_against_observations(gpr_nested_bo_oof, f"GPR nested BO CV\n{CV_DISPLAY_NAME}", "02d3_gpr_nested_BO_cv_predicted_vs_actual.png", color=MODEL_COLORS["gpr_nested"])
plot_predictions_against_observations(linear_base_oof, f"Ordinary linear regression CV\n{CV_DISPLAY_NAME}", "02e_ordinary_linear_regression_cv_predicted_vs_actual.png", color=MODEL_COLORS["ols"], marker="o")

# Three-panel comparisons of base, non-nested BO and nested BO predictions.
plot_model_tuning_comparison(
    y,
    [xgb_base_oof, xgb_bo_oof, xgb_nested_bo_oof],
    ["XGBoost base-case CV", "XGBoost non-nested BO CV", "XGBoost nested BO CV"],
    ["Base-case XGBoost", "Non-nested BO XGBoost", "Nested BO XGBoost"],
    [MODEL_COLORS["xgb_base"], MODEL_COLORS["xgb_bo"], MODEL_COLORS["xgb_nested"]],
    "02g_xgboost_base_non_nested_nested_3panel.png",
    f"XGBoost CV comparison | {CV_DISPLAY_NAME}",
)

plot_model_tuning_comparison(
    y,
    [gpr_base_oof, gpr_bo_oof, gpr_nested_bo_oof],
    ["GPR base-case CV", "GPR non-nested BO CV", "GPR nested BO CV"],
    ["Base-case GPR", "Non-nested BO GPR", "Nested BO GPR"],
    [MODEL_COLORS["gpr_base"], MODEL_COLORS["gpr_bo"], MODEL_COLORS["gpr_nested"]],
    "02h_gpr_base_non_nested_nested_3panel.png",
    f"GPR CV comparison | {CV_DISPLAY_NAME}",
)

# Compare nested-BO predictions with the OLS baseline in one figure.
fig, ax = plt.subplots(figsize=(7, 6))
ax.scatter(y, xgb_nested_bo_oof, s=60, marker="o", alpha=0.80, edgecolor="black", linewidth=0.7, color="tab:blue", label="XGBoost nested BO")
ax.scatter(y, gpr_nested_bo_oof, s=65, marker="o", alpha=0.80, edgecolor="black", linewidth=0.7, color="tab:orange", label="GPR nested BO")
ax.scatter(y, linear_base_oof, s=65, marker="o", alpha=0.80, edgecolor="black", linewidth=0.7, color="tab:green", label="Ordinary linear regression")
lo, hi = _prediction_limits(y, [xgb_nested_bo_oof, gpr_nested_bo_oof, linear_base_oof])
ax.plot([lo, hi], [lo, hi], linestyle="--", color="black", linewidth=1.2)
ax.set_xlim(lo, hi)
ax.set_ylim(lo, hi)
ax.set_xlabel(f"Actual {TARGET_LABEL.lower()}")
ax.set_ylabel(f"OOF predicted {TARGET_LABEL.lower()}")
ax.set_title(f"Optimized ML model comparison\n{CV_DISPLAY_NAME}")
ax.legend(fontsize=11, frameon=True)
style_axis(ax, grid=True)
fig.tight_layout()
fig.savefig(os.path.join(OUT_DIR, "02f_optimized_XGBoost_GPR_OLS_OOF_comparison.png"), dpi=DPI, bbox_inches="tight")
plt.close(fig)


# Compare pooled out-of-fold MAE and RMSE across all model configurations.
plot_df = metrics_df.dropna(subset=["MAE", "RMSE"]).copy()
plot_df["label"] = plot_df["model"] + "\n" + plot_df["hyperparameter_case"]
fig, ax = plt.subplots(figsize=(15, 6.5))
xpos = np.arange(len(plot_df))
width = 0.35
ax.bar(xpos - width / 2, plot_df["MAE"], width, label="CV MAE", color="tab:blue", edgecolor="black", linewidth=0.5, alpha=0.85)
ax.bar(xpos + width / 2, plot_df["RMSE"], width, label="CV RMSE", color="tab:orange", edgecolor="black", linewidth=0.5, alpha=0.85)
ax.set_xticks(xpos)
ax.set_xticklabels(plot_df["label"], rotation=35, ha="right", fontsize=8.5)
ax.set_ylabel("Yield percentage points")
ax.set_title("Cross-validated error comparison across all models")
ax.legend(frameon=True)
style_axis(ax, grid=True, grid_axis="y")
fig.tight_layout()
fig.savefig(os.path.join(OUT_DIR, "04_model_error_comparison_all_models.png"), dpi=DPI, bbox_inches="tight")
plt.close(fig)


# Grouped and individual SHAP importance for the full-data XGBoost fit.
fig, ax = plt.subplots(figsize=(8, 5))
if len(group_shap_df) > 0:
    gdf = group_shap_df.sort_values("mean_abs_group_SHAP_yield_pct_points", ascending=True)
    ax.barh(gdf["descriptor_group"], gdf["mean_abs_group_SHAP_yield_pct_points"], color="tab:blue", edgecolor="black", linewidth=0.6, alpha=0.85)
ax.set_xlabel("Mean|grouped SHAP|yield %-points")
ax.set_title("BO-XGBoost\nSHAP grouped importance")
style_axis(ax, grid=True, grid_axis="x")
fig.tight_layout()
fig.savefig(os.path.join(OUT_DIR, "05_xgboost_BO_grouped_shap_importance.png"), dpi=DPI, bbox_inches="tight")
plt.close(fig)

fig, ax = plt.subplots(figsize=(8, 6))
top = ind_shap.head(15).sort_values("mean_abs_SHAP_yield_pct_points", ascending=True)
ax.barh([readable_feature_name(f) for f in top["feature"]], top["mean_abs_SHAP_yield_pct_points"], color="tab:blue", edgecolor="black", linewidth=0.6, alpha=0.85)
ax.set_xlabel("Mean|SHAP|yield %-points")
ax.set_title("BO-XGBoost\nIndividual SHAP importance: top 15")
style_axis(ax, grid=True, grid_axis="x")
fig.tight_layout()
fig.savefig(os.path.join(OUT_DIR, "06_xgboost_BO_individual_shap_importance.png"), dpi=DPI, bbox_inches="tight")
plt.close(fig)

# Standard SHAP beeswarm with readable descriptor labels.
fig = plt.figure(figsize=(8, 6))
shap.summary_plot(shap_values, X_shap_readable, feature_names=list(X_shap_readable.columns), show=False, max_display=15)
ax = plt.gca()
ax.set_title("BO-XGBoost\nSHAP beeswarm")
ax.tick_params(axis="both", labelsize=10)
fig = plt.gcf()
fig.tight_layout()
fig.savefig(os.path.join(OUT_DIR, "07_xgboost_BO_shap_beeswarm.png"), dpi=DPI, bbox_inches="tight")
plt.close(fig)

# Combined 3-panel XGBoost/SHAP figure:
# (a) non-nested BO XGBoost OOF predictions,
# (b) grouped SHAP from final full-data BO-XGBoost,
# (c) SHAP beeswarm from final full-data BO-XGBoost.
fig, axes = plt.subplots(1, 3, figsize=(20, 6.5))

# (a) Non-nested BO XGBoost OOF actual-vs-predicted.
axes[0].scatter(
    y,
    xgb_bo_oof,
    alpha=0.82,
    s=62,
    edgecolor="black",
    linewidth=0.7,
    color=MODEL_COLORS["xgb_bo"],
)

lo, hi = _prediction_limits(y, [xgb_bo_oof])
axes[0].plot([lo, hi], [lo, hi], linestyle="--", color="black", linewidth=1.2)
axes[0].set_xlim(lo, hi)
axes[0].set_ylim(lo, hi)
axes[0].set_xlabel(f"Actual {TARGET_LABEL.lower()}")
axes[0].set_ylabel(f"OOF predicted {TARGET_LABEL.lower()}")
axes[0].set_title("Non-nested BO-XGBoost\nOOF vs Actual")
style_axis(axes[0], grid=True)

metrics_box = (
    f"CV R² = {xgb_bo_metrics['R2']:.3f}\n"
    f"CV MAE = {xgb_bo_metrics['MAE']:.2f}\n"
    f"CV RMSE = {xgb_bo_metrics['RMSE']:.2f}"
)
axes[0].text(
    0.04, 0.96,
    metrics_box,
    transform=axes[0].transAxes,
    ha="left",
    va="top",
    fontsize=9.5,
    bbox=dict(boxstyle="round,pad=0.35", facecolor="white", edgecolor="black", alpha=0.92),
)
axes[0].text(0.5, -0.16, "(a)", transform=axes[0].transAxes, ha="center", fontsize=13)

# (b) Grouped SHAP importance for the final full-data BO-XGBoost model.
gdf_combined = group_shap_df.sort_values("mean_abs_group_SHAP_yield_pct_points", ascending=True)
axes[1].barh(
    gdf_combined["descriptor_group"],
    gdf_combined["mean_abs_group_SHAP_yield_pct_points"],
    color="tab:blue",
    edgecolor="black",
    linewidth=0.5,
    alpha=0.85,
)
axes[1].set_xlabel("Mean |grouped SHAP| yield %-points")
axes[1].set_title("BO-XGBoost\nSHAP grouped importance")
style_axis(axes[1], grid=True, grid_axis="x")
axes[1].text(0.5, -0.16, "(b)", transform=axes[1].transAxes, ha="center", fontsize=13)

# (c) SHAP beeswarm from the same final full-data BO-XGBoost model.
plt.sca(axes[2])
shap.summary_plot(
    shap_values,
    X_shap_readable,
    feature_names=list(X_shap_readable.columns),
    show=False,
    max_display=15,
    plot_size=None,
)
axes[2].set_title("BO-XGBoost\nSHAP beeswarm")
axes[2].tick_params(axis="both", labelsize=9.5)
axes[2].text(0.5, -0.16, "(c)", transform=axes[2].transAxes, ha="center", fontsize=13)

fig.suptitle(f" SHAP based model interpretation | {TARGET_LABEL}", fontsize=15, y=1.02)
fig.tight_layout()
combined_xgb_shap_path = os.path.join(OUT_DIR, "07b_combined_XGBoostBO_groupedSHAP_beeswarm.png")
fig.savefig(combined_xgb_shap_path, dpi=DPI, bbox_inches="tight")
plt.close(fig)
log(f"Saved combined XGBoost/SHAP 3-panel plot: {combined_xgb_shap_path}")


# -----------------------
# Consolidated text results
# -----------------------
report = f"""
{TARGET_NAME.capitalize()} yield regression results
===================================================================
Input workbook: {INPUT_FILE.name}
Worksheet: {SHEET_NAME}
Rows used: {len(df_model)}
Target column: {TARGET}
Predictors before filtering: {X_all.shape[1]}
Predictors used: {X_ml.shape[1]}
Runtime at report generation: {format_runtime(elapsed_seconds())}

Data preparation
----------------
Other measured outcomes and identifiers are excluded from predictors.
Rows with missing target values are removed. Predictor columns are converted
to numeric; entirely nonnumeric/all-missing columns are dropped. Remaining
missing or infinite predictor values are filled with zero. Zero filling is a
data-encoding assumption and should be assessed for the supplied descriptors.
Rare-feature filter enabled: {APPLY_RARE_FEATURE_FILTER_TO_ML}
Minimum binary minority count: {MIN_BINARY_MINORITY_COUNT}
Minimum distinct non-binary values: {MIN_CONTINUOUS_UNIQUE_VALUES}
The target-independent feature filter is applied to the complete predictor
table before CV. GPR and OLS scaling is fitted within each training subset.

Validation design
-----------------
Outer CV strategy: {CV_STRATEGY}
CV label: {CV_STRATEGY_LABEL}
Outer folds: {n_splits}
Group basis: {CV_GROUP_BASIS}
Description: {CV_DESCRIPTION}
Inner tuning: shuffled row-wise KFold, up to {BO_CV_SPLITS} folds.
Inner folds are row-wise even when the outer folds are grouped. LOPO uses
the first available source label per row; missing labels become unique-row
groups. The detailed fold tables identify the actual held-out groups.

Model fitting and hyperparameter selection
-----------------------------------------
XGBoost BO enabled: {RUN_XGB_BAYES_OPT}
GPR BO enabled: {RUN_GPR_BAYES_OPT}
BO configurations per search: {BO_N_ITER}
BO objective: mean inner-validation R2
Acquisition setting: {ML_BO_ACQ_FUNC}; kappa={ML_BO_ACQ_KAPPA}; xi={ML_BO_ACQ_XI}
kappa applies to LCB/UCB; xi applies to EI/PI. gp_hedge uses library defaults.
GPR kernel family: {GPR_KERNEL}; fixed alpha: {GPR_ALPHA_FIXED}
GPR covariance: ConstantKernel * selected kernel + WhiteKernel.
GPR length scale, amplitude and noise level are selected by BO when enabled;
the internal GPR optimiser is disabled. OLS uses no regularisation or tuning.

Base-case models use fixed hyperparameters. Non-nested BO selects parameters
using all observations, so its subsequent CV scores are tuning-informed.
Nested BO selects parameters within each outer training set; its held-out
predictions evaluate that tuning procedure. If BO is disabled for a model,
the BO-labelled comparisons reuse its base parameters.

Metric interpretation
---------------------
R2, MAE and RMSE are calculated from pooled out-of-fold predictions.
MAE and RMSE are in yield percentage points. Fold-specific R2 is NA when
the held-out set has fewer than two rows. Full_R2, Full_MAE and Full_RMSE
describe training fit on all rows, not performance on an independent set.
The full-data metrics displayed beside nested-BO rows come from the final
non-nested full-data model, not from a single nested-BO fitted model.

Learning-curve generation
-------------------------
LOO learning curves deferred: {LOO_LEARNING_CURVES_DEFERRED}
Learning curves generated during this run: {RUN_LEARNING_CURVES}
Saved LOO inputs directory: {DEFERRED_LOO_INPUTS_DIR}
For LOO, original model tuning runs as configured, but no fraction-specific
learning-curve fits or optimization are performed. The saved bundle contains
processed features, observations/OOF predictions, exact splits, fold-specific
parameters, fold scores and the reused full-size learning-curve point.

Model metrics: reference seed {RUN_SEEDS[0]}
-------------------------------------------
{metrics_df.to_string(index=False)}

Metric stability across {N_SEED_REPEATS} seeds
---------------------------------------------
Seeds: {RUN_SEEDS}
Values are mean +/- sample SD across complete model evaluation procedures.
Shuffled outer folds vary by seed; grouped, LOOCV and LOPO outer folds remain
fixed. SD describes variation due to seeds, not confidence intervals or
per-observation predictive uncertainty. SD is undefined for a single seed.

{seed_metrics_summary_df.to_string(index=False)}

SHAP interpretation
-------------------
SHAP values describe the final full-data XGBoost model using the non-nested
BO settings (base settings when BO is disabled). They explain that fitted
model rather than held-out performance or causal effects. Group importance
is the mean absolute value of the sum of SHAP values within each descriptor
group; individual contributions can cancel before the absolute value.

{group_shap_df.to_string(index=False) if not group_shap_df.empty else 'No grouped SHAP rows available.'}

Output contents
---------------
The tables below include hyperparameters, fold-level training/test metrics,
predictions, seed summaries, BO search records, feature processing, SHAP and
support-descriptor summaries. Detailed BO trials are for the first seed;
selected parameter records are also included for the remaining seeds.
Figures and a copy of this script are saved beside this text report.
Separate CSV copies enabled: {SAVE_CSV_TABLES}
""".strip()

write_results_report(report)
log(f"Text results saved: {RESULTS_FILE}")

try:
    shutil.copyfile(__file__, OUT_DIR / Path(__file__).name)
except Exception as exc:
    log(f"Script copy skipped: {exc}")

RUN_COMPLETED = True
log("Yield regression evaluation completed successfully")
log(f"Total runtime: {format_runtime(elapsed_seconds())}")
print("OUT_DIR", OUT_DIR)
print("METRICS")
print(metrics_df.to_string(index=False))
print("SEED 42 METRICS (single run; across-seed SD undefined)" if N_SEED_REPEATS == 1 else f"{N_SEED_REPEATS}-SEED METRIC MEAN +/- SD")
print(seed_metrics_summary_df.to_string(index=False))
print("COMPLETE ML HYPERPARAMETERS")
print(ml_hyperparameters_complete_long_df.to_string(index=False))
print("GROUP SHAP")
print(group_shap_df.to_string(index=False) if not group_shap_df.empty else "No grouped SHAP rows")
