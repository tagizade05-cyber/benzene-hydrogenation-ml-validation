#!/usr/bin/env python3
"""Create publication-ready heatmaps from five-seed CV summaries.

Main addition: can create ONE merged 2x3 figure with:
- Row 1: cyclohexane
- Row 2: cyclohexene
- Columns: CV R², CV MAE (%), CV RMSE (%)

By default, only the two available outer-validation strategies are used:
- Catalyst Group 5-fold
- LOPO

Both "Non-nested BO" and "Nested BO" are selected by default.
Untuned "Base case" rows can be added with --include-base.

Install: pip install pandas numpy matplotlib
Run combined figure only:
    python plot_nested_bo_three_panel_heatmaps_merged.py --layout merged
Run separate and merged figures:
    python plot_nested_bo_three_panel_heatmaps_merged.py --layout all
Include untuned base cases too:
    python plot_nested_bo_three_panel_heatmaps_merged.py --layout merged --include-base
"""

from __future__ import annotations

import argparse
from pathlib import Path
import warnings

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import Normalize, TwoSlopeNorm
import numpy as np
import pandas as pd
from mpl_toolkits.axes_grid1 import make_axes_locatable


SCRIPT_DIR = Path(__file__).resolve().parent
STRATEGIES = [
    ("groupkfold_catalyst", "Catalyst Group\n5-fold"),
    ("leave_one_paper_out", "LOPO"),
]
MODELS = ["XGBoost", "GPR"]
METRICS = [
    ("R2",   "(a) Cross-validated R² (mean ± SD)",   "Mean CV R²",       "RdBu"),
    ("MAE",  "(b) Cross-validated MAE (%) (mean ± SD)",  "Mean CV MAE (%)",  "YlOrRd"),
    ("RMSE", "(c) Cross-validated RMSE (%) (mean ± SD)", "Mean CV RMSE (%)", "YlOrRd"),
]

# ---- Appearance settings -------------------------------------------------
FIGURE_WIDTH_INCHES = 14.6
SEPARATE_HEIGHT_NO_BASE = 5.4
SEPARATE_HEIGHT_WITH_BASE = 6.6
MERGED_HEIGHT_NO_BASE = 8.8
MERGED_HEIGHT_WITH_BASE = 10.2
FONT_FAMILY = "DejaVu Sans"
PANEL_TITLE_SIZE = 11.2
MAIN_TITLE_SIZE = 14.8
ROW_LABEL_SIZE = 10.6
COLUMN_LABEL_SIZE = 10.4
CELL_FONT_SIZE = 9.2
AXIS_TITLE_SIZE = 9.5
COLORBAR_TICK_SIZE = 8.5
ROW_HEADING_SIZE = 12.3
DPI = 350
# -------------------------------------------------------------------------


def load_and_select(path: Path, *, include_base: bool) -> pd.DataFrame:
    if not path.exists():
        raise FileNotFoundError(f"CSV not found: {path}")
    df = pd.read_csv(path)
    required = {"outer_strategy", "model", "BO_case"}
    required |= {f"{m}_{part}" for m in ("R2", "MAE", "RMSE") for part in ("mean", "SD")}
    if missing := (required - set(df.columns)):
        raise ValueError(f"{path.name}: missing columns: {sorted(missing)}")

    selected_cases = ["Base case", "Non-nested BO", "Nested BO"] if include_base else ["Non-nested BO", "Nested BO"]
    df = df.loc[
        df["outer_strategy"].isin([name for name, _ in STRATEGIES])
        & df["model"].isin(MODELS)
        & df["BO_case"].isin(selected_cases)
    ].copy()

    if "inner_strategy" in df.columns:
        nested_rows = df["BO_case"].eq("Nested BO")
        aligned = (
            df.loc[nested_rows, "inner_strategy"].astype(str).str.strip().str.casefold()
            == df.loc[nested_rows, "outer_strategy"].astype(str).str.strip().str.casefold()
        )
        df = df.drop(index=aligned.index[~aligned])
    else:
        warnings.warn(
            f"{path.name}: inner_strategy not provided; selecting labeled Nested BO rows "
            "but cannot verify inner–outer CV strategy matching.",
            stacklevel=2,
        )

    expected = len(STRATEGIES) * len(MODELS) * len(selected_cases)
    key = ["outer_strategy", "model", "BO_case"]
    if df.duplicated(key).any():
        raise ValueError(f"Duplicate metric entries for the same CV/model/BO case in {path.name}.")
    if len(df) != expected:
        found = set(map(tuple, df[key].to_numpy()))
        absent = [
            (outer, model, bo)
            for outer, _ in STRATEGIES for model in MODELS for bo in selected_cases
            if (outer, model, bo) not in found
        ]
        raise ValueError(f"{path.name}: missing {len(absent)} required combinations: {absent}")
    return df.set_index(key)


def build_matrix(df: pd.DataFrame, metric: str, include_base: bool):
    rows = [
        (model, bo)
        for model in MODELS
        for bo in (["Base case", "Non-nested BO", "Nested BO"] if include_base else ["Non-nested BO", "Nested BO"])
    ]
    vals = np.array([
        [df.loc[(strategy, model, bo), f"{metric}_mean"] for strategy, _ in STRATEGIES]
        for model, bo in rows
    ], dtype=float)
    sd = np.array([
        [df.loc[(strategy, model, bo), f"{metric}_SD"] for strategy, _ in STRATEGIES]
        for model, bo in rows
    ], dtype=float)
    labels = [
        f"{model} — {'Base' if bo == 'Base case' else ('Non-nested BO' if bo == 'Non-nested BO' else 'Nested BO')}"
        for model, bo in rows
    ]
    return vals, sd, labels


def sd_as_text(value: float, metric: str) -> str:
    if value == 0:
        return "0.000" if metric == "R2" else "0.00"
    ndec = 3 if metric == "R2" else 2
    while ndec < 4 and round(value, ndec) == 0:
        ndec += 1
    return f"{value:.{ndec}f}"


def annotation(mean: float, sd: float, metric: str) -> str:
    return f"{mean:.{3 if metric == 'R2' else 2}f} ± {sd_as_text(sd, metric)}"


def text_color(rgba) -> str:
    rgb = np.array(rgba[:3])
    linear = np.where(rgb <= 0.04045, rgb / 12.92, ((rgb + 0.055) / 1.055) ** 2.4)
    luminance = float(linear @ np.array([0.2126, 0.7152, 0.0722]))
    return "#ffffff" if luminance < 0.28 else "#202020"


def metric_norm(all_values: list[np.ndarray], metric: str):
    concat = np.concatenate([arr.ravel() for arr in all_values])
    min_value = float(np.min(concat))
    max_value = float(np.max(concat))
    if metric == "R2":
        return TwoSlopeNorm(vmin=min(-1.0, min_value - 0.1), vcenter=0, vmax=max(1.0, max_value + 0.05))
    return Normalize(vmin=0.0, vmax=max_value * 1.08 if max_value > 0 else 1.0)


def apply_heatmap(ax, values, sd, row_labels, metric, title, cmap_name, norm, *, show_ylabels: bool, show_xlabel: bool):
    nrows = values.shape[0]
    cmap = plt.get_cmap(cmap_name)
    im = ax.imshow(values, cmap=cmap, norm=norm, aspect="auto", interpolation="none")

    ax.set_xticks(np.arange(-0.5, len(STRATEGIES), 1), minor=True)
    ax.set_yticks(np.arange(-0.5, nrows, 1), minor=True)
    ax.grid(which="minor", color="white", linewidth=2.0)
    ax.tick_params(which="minor", bottom=False, left=False)

    ax.set_xticks(range(len(STRATEGIES)))
    ax.set_xticklabels([label for _, label in STRATEGIES], fontsize=COLUMN_LABEL_SIZE)
    ax.set_yticks(range(nrows))
    ax.set_yticklabels(row_labels if show_ylabels else [], fontsize=ROW_LABEL_SIZE)
    ax.tick_params(axis="both", length=0, pad=7)
    if show_xlabel:
        ax.set_xlabel("Cross-validation strategy", fontsize=AXIS_TITLE_SIZE, labelpad=9)
    else:
        ax.set_xlabel("")
    ax.set_title(title, fontsize=PANEL_TITLE_SIZE, fontweight="semibold", pad=11)

    for r in range(nrows):
        for c in range(values.shape[1]):
            value, error = values[r, c], sd[r, c]
            ax.text(
                c, r, annotation(value, error, metric),
                ha="center", va="center", fontsize=CELL_FONT_SIZE,
                color=text_color(cmap(norm(value))), fontweight="medium"
            )
    return im


def draw_heatmaps(df: pd.DataFrame, target: str, out_dir: Path, *, include_base: bool):
    plt.rcParams.update({
        "font.family": FONT_FAMILY,
        "svg.fonttype": "none",
        "pdf.fonttype": 42,
        "axes.spines.top": False,
        "axes.spines.right": False,
    })
    height = SEPARATE_HEIGHT_WITH_BASE if include_base else SEPARATE_HEIGHT_NO_BASE
    fig, axes = plt.subplots(1, 3, figsize=(FIGURE_WIDTH_INCHES, height))
    fig.subplots_adjust(left=0.142, right=0.975, top=0.78,
                        bottom=0.22 if include_base else 0.255, wspace=0.45)

    for panel_idx, (metric, title, cbar_label, cmap_name) in enumerate(METRICS):
        ax = axes[panel_idx]
        values, sd, row_labels = build_matrix(df, metric, include_base)
        norm = metric_norm([values], metric)
        im = apply_heatmap(
            ax, values, sd, row_labels, metric, title, cmap_name, norm,
            show_ylabels=(panel_idx == 0), show_xlabel=True
        )
        divider = make_axes_locatable(ax)
        cax = divider.append_axes("right", size="3.8%", pad=0.10)
        cb = fig.colorbar(im, cax=cax)
        cb.ax.tick_params(labelsize=COLORBAR_TICK_SIZE, length=2)
        cb.set_label(cbar_label, fontsize=9.2, labelpad=7)
        cb.outline.set_visible(False)

    mode = "Base + non-nested + nested BO" if include_base else "Non-nested vs nested BO"
    fig.suptitle(f"{target.capitalize()} yield | {mode} | five seeds",
                 fontsize=MAIN_TITLE_SIZE, fontweight="semibold", y=0.965)
    out_dir.mkdir(parents=True, exist_ok=True)
    suffix = "all_cases" if include_base else "both_bo_cases"
    stem = f"{target}_three_panel_{suffix}"
    outputs = []
    for ext in ("png", "svg"):
        out = out_dir / f"{stem}.{ext}"
        fig.savefig(out, dpi=DPI, bbox_inches="tight", pad_inches=0.18, facecolor="white")
        outputs.append(out)
    plt.close(fig)
    return outputs


def draw_merged_heatmaps(data_by_target: dict[str, pd.DataFrame], out_dir: Path, *, include_base: bool):
    plt.rcParams.update({
        "font.family": FONT_FAMILY,
        "svg.fonttype": "none",
        "pdf.fonttype": 42,
        "axes.spines.top": False,
        "axes.spines.right": False,
    })

    targets = ["cyclohexane", "cyclohexene"]
    matrices = {target: {} for target in targets}
    row_labels = None
    for target in targets:
        for metric, *_ in METRICS:
            vals, sd, labels = build_matrix(data_by_target[target], metric, include_base)
            matrices[target][metric] = (vals, sd)
            if row_labels is None:
                row_labels = labels

    norms = {
        metric: metric_norm([matrices[t][metric][0] for t in targets], metric)
        for metric, *_ in METRICS
    }

    height = MERGED_HEIGHT_WITH_BASE if include_base else MERGED_HEIGHT_NO_BASE
    fig, axes = plt.subplots(2, 3, figsize=(FIGURE_WIDTH_INCHES, height))
    fig.subplots_adjust(left=0.155, right=0.94, top=0.87, bottom=0.12, wspace=0.36, hspace=0.42)

    for col, (metric, title, cbar_label, cmap_name) in enumerate(METRICS):
        for row, target in enumerate(targets):
            ax = axes[row, col]
            vals, sd = matrices[target][metric]
            im = apply_heatmap(
                ax, vals, sd, row_labels, metric,
                title if row == 0 else "",
                cmap_name, norms[metric],
                show_ylabels=(col == 0),
                show_xlabel=(row == 1),
            )
            if row == 0:
                ax.set_title(title, fontsize=PANEL_TITLE_SIZE, fontweight="semibold", pad=11)
            else:
                ax.set_title("")

            if col == 0:
                ax.set_ylabel(
                    "Cyclohexane yield" if row == 0 else "Cyclohexene yield",
                    fontsize=ROW_HEADING_SIZE,
                    fontweight="semibold",
                    labelpad=16,
                )

        cb = fig.colorbar(im, ax=[axes[0, col], axes[1, col]], fraction=0.046, pad=0.02)
        cb.ax.tick_params(labelsize=COLORBAR_TICK_SIZE, length=2)
        cb.set_label(cbar_label, fontsize=9.2, labelpad=7)
        cb.outline.set_visible(False)

    mode = "Base + non-nested + nested BO" if include_base else "Non-nested vs nested BO"
    

    out_dir.mkdir(parents=True, exist_ok=True)
    suffix = "all_cases" if include_base else "both_bo_cases"
    stem = f"merged_cyclohexane_cyclohexene_three_panel_{suffix}"
    outputs = []
    for ext in ("png", "svg"):
        out = out_dir / f"{stem}.{ext}"
        fig.savefig(out, dpi=DPI, bbox_inches="tight", pad_inches=0.18, facecolor="white")
        outputs.append(out)
    plt.close(fig)
    return outputs


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--cyclohexane-csv", type=Path,
                        default=SCRIPT_DIR / "cyclohexane_model_metrics_mean_SD_5seeds.csv")
    parser.add_argument("--cyclohexene-csv", type=Path,
                        default=SCRIPT_DIR / "cylohexene_model_metrics_mean_SD_5seeds.csv")
    parser.add_argument("--out-dir", type=Path, default=SCRIPT_DIR / "merged_cv_both_bo_updated")
    parser.add_argument("--include-base", action="store_true",
                        help="Also show untuned Base case rows alongside Non-nested BO and Nested BO")
    parser.add_argument("--layout", choices=["merged", "separate", "all"], default="merged",
                        help="Choose whether to create the merged figure, separate figures, or both.")
    args = parser.parse_args()

    cyclohexane = load_and_select(args.cyclohexane_csv, include_base=args.include_base)
    cyclohexene = load_and_select(args.cyclohexene_csv, include_base=args.include_base)
    data_by_target = {"cyclohexane": cyclohexane, "cyclohexene": cyclohexene}

    created = []
    if args.layout in {"merged", "all"}:
        created.extend(draw_merged_heatmaps(data_by_target, args.out_dir, include_base=args.include_base))
    if args.layout in {"separate", "all"}:
        created.extend(draw_heatmaps(cyclohexane, "cyclohexane", args.out_dir, include_base=args.include_base))
        created.extend(draw_heatmaps(cyclohexene, "cyclohexene", args.out_dir, include_base=args.include_base))

    for path in created:
        print(f"Saved: {path}")


if __name__ == "__main__":
    main()
