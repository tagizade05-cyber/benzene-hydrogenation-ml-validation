"""Cyclohexene yield: matched inner/outer grouped validation.

This script evaluates XGBoost and GPR under catalyst GroupKFold and LOPO.
Both the starting models and the search bounds match the current main ML code.
The intentional scientific difference is the INNER splitter: catalyst groups
stay together for both inner and outer GroupKFold; whole papers stay together
for both inner and outer LOPO. Outer-test responses never enter nested tuning.

Run this file normally after placing it beside the updated workbook. The
settings below can be edited, or overridden using --help. Completed BO searches
are cached: repeating the same run refits the small outer models but does not
repeat successful optimization. Plotting is handled by the separate merged
plotter and requires no model training. This file is safe to import.
"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import importlib.metadata
import json
import platform
import shutil
import sys
import time
import uuid
import warnings

import numpy as np
import pandas as pd
import xgboost as xgb
from sklearn.base import BaseEstimator, RegressorMixin
from sklearn.preprocessing import StandardScaler
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import ConstantKernel, RBF, Matern, WhiteKernel
from sklearn.model_selection import GroupKFold, LeaveOneGroupOut
from skopt import BayesSearchCV
from skopt.space import Real, Integer
from joblib import parallel_backend, effective_n_jobs
from threadpoolctl import threadpool_limits

for _stream in (sys.stdout, sys.stderr):
    if hasattr(_stream, "reconfigure"):
        _stream.reconfigure(encoding="utf-8", errors="replace")

# ---------------- Settings normally edited by the researcher ----------------
SCRIPT_DIR = Path(__file__).resolve().parent
INPUT_FILE = SCRIPT_DIR / "DATA_ML_Benzene_Hydrogenation.xlsx"
SHEET_NAME = "FullDataset"
TARGET = "Cyclohexene_yield_%"
TARGET_NAME = "cyclohexene"
TARGET_DISPLAY = "Cyclohexene"
RESULTS_ROOT = SCRIPT_DIR / "results" / "matched_cv_bo"

# Preserve the original matched-analysis seed-42 default. To reproduce the main
# five-seed stability assessment, use [42, 101, 202, 303, 404] or --seeds below.
RUN_SEEDS = [42]
STRATEGIES = ("groupkfold_catalyst", "leave_one_paper_out")
OUTER_GROUP_FOLDS = 5
INNER_GROUP_FOLDS = 5

# Prefer the exact saved main outer folds, avoiding library-version changes in
# how equal-size catalyst groups are assigned. No target values are read from
# those reference results. A new workbook without compatible main results uses
# freshly generated GROUPED folds; --require-main-outer-splits forbids that.
PREFER_SAVED_MAIN_OUTER_SPLITS = True
MAIN_RESULTS_ROOT = SCRIPT_DIR / "results" / "model_results"

# Same descriptor-screening policy as the main workflow. This predictor-only
# screen is performed ONCE on the full feature table, before CV. It is not a
# training-fold-only screen; retaining this policy keeps the comparisons aligned.
APPLY_RARE_FEATURE_FILTER_TO_ML = True
MIN_BINARY_MINORITY_COUNT = 3
MIN_CONTINUOUS_UNIQUE_VALUES = 3

# Each search tests 20 configurations and maximizes MEAN INNER-FOLD R2.
# Grouping is matched; the number of LOPO inner folds follows the number of
# available training papers. Four total papers give three inner LOPO folds
# after one paper is held out, each using two papers to predict the third.
BO_N_ITER = 20
ML_BO_ACQ_FUNC = "EI"
ML_BO_ACQ_KAPPA = 3.0
ML_BO_ACQ_XI = 0.05
BO_SEARCH_N_JOBS = -1
XGB_N_JOBS_DURING_BO = 1
XGB_N_JOBS_FINAL = -1
GPR_KERNEL = "RBF"
GPR_ALPHA_FIXED = 1e-3

# Hash of the main source used when aligning the settings. This is provenance,
# not a dependency: importing the large main workflow would launch its models.
MAIN_REFERENCE_FILENAME = "CYCLOHEXENE_ML_MODELS.py"
MAIN_REFERENCE_SHA256 = "372c0d184807e47f35b7f21bd3eaa6f2ff537a08198120bcba4a8dd985350124"

# Copied from the corresponding current main ML workflow.
LEAKAGE_COLS = [
    "Benzene_conversion_%",
    "Selectivity_to_cyclohexane_%",
    "Selectivity_to_cyclohexene_%",
    "Cyclohexane_yield_%",
]


# Copied from the corresponding current main ML workflow.
ID_COLS = [
    "Author", "Source_study", "Reference", "Paper", "Experiment_ID",
    "Catalyst_ID2", "Catalyst_ID", "Catalyst", "Metal",
]


# Copied from the corresponding current main ML workflow.
def configure_acquisition_function(acq_func, kappa, xi):
    """Translate the BO acquisition setting into scikit-optimize arguments."""
    acq = str(acq_func).upper()
    if acq == "UCB":
        # scikit-optimize uses LCB for UCB-style exploration under minimisation.
        acq = "LCB"
    allowed = {"LCB", "PI", "EI", "GP_HEDGE"}
    if acq not in allowed:
        raise ValueError("Acquisition function must be one of: LCB, UCB, PI, EI, gp_hedge")
    if acq == "GP_HEDGE":
        acq = "gp_hedge"
    kwargs = {}
    if acq == "LCB":
        kwargs["kappa"] = kappa
    elif acq in ["PI", "EI"]:
        kwargs["xi"] = xi
    return acq, kwargs


# Copied from the corresponding current main ML workflow.
def safe_param_dict(params):
    """Convert NumPy scalar hyperparameters to native Python values."""
    out = {}
    for k, v in params.items():
        if hasattr(v, "item"):
            v = v.item()
        out[k] = v
    return out


# Copied from the corresponding current main ML workflow.
def trim_rare_ml_features(X_df, min_binary_minority_count=3, min_continuous_unique_values=3):
    """Target-independent feature filter for ML models only."""
    X_df = pd.DataFrame(X_df).copy()
    keep_cols = []
    rows = []
    for col in X_df.columns:
        s = pd.to_numeric(X_df[col], errors="coerce")
        finite = s.replace([np.inf, -np.inf], np.nan).dropna()
        unique_vals = np.sort(finite.unique())
        is_binary = len(unique_vals) <= 2 and set(unique_vals).issubset({0, 1})
        if is_binary:
            count_0 = int((s == 0).sum())
            count_1 = int((s == 1).sum())
            minority = min(count_0, count_1)
            keep = minority >= int(min_binary_minority_count)
            reason = f"binary counts: 0={count_0}, 1={count_1}, minority={minority}, required={min_binary_minority_count}"
        else:
            n_unique = int(finite.nunique())
            keep = n_unique >= int(min_continuous_unique_values)
            reason = f"non-binary unique finite values={n_unique}, required={min_continuous_unique_values}"
        rows.append({"feature": col, "kept_for_ML": bool(keep), "reason": reason})
        if keep:
            keep_cols.append(col)
    if not keep_cols:
        raise RuntimeError("Rare-feature filtering removed every ML feature.")
    return X_df[keep_cols].copy(), pd.DataFrame(rows)


# Copied from the corresponding current main ML workflow.
class TunableGPR(BaseEstimator, RegressorMixin):
    """Standardized Gaussian Process Regression with BO-tunable kernel parameters."""

    def __init__(
        self,
        kernel_name="RBF",
        length_scale=2.0,
        constant_value=1.0,
        noise_level=0.20,
        alpha=1e-3,
        normalize_y=True,
        random_state=42,
    ):
        self.kernel_name = kernel_name
        self.length_scale = length_scale
        self.constant_value = constant_value
        self.noise_level = noise_level
        self.alpha = alpha
        self.normalize_y = normalize_y
        self.random_state = random_state

    def fit(self, X, y):
        X_df = pd.DataFrame(X).copy()
        self.feature_names_in_ = list(X_df.columns)
        y_arr = np.asarray(y, dtype=float)

        self.scaler_ = StandardScaler()
        X_scaled = self.scaler_.fit_transform(X_df)

        kernel_key = str(self.kernel_name).upper().strip()
        if kernel_key == "RBF":
            base_kernel = RBF(length_scale=float(self.length_scale), length_scale_bounds="fixed")
        elif kernel_key in {"MATERN_1.5", "MATERN15", "MATERN_15"}:
            base_kernel = Matern(length_scale=float(self.length_scale), length_scale_bounds="fixed", nu=1.5)
        elif kernel_key in {"MATERN_2.5", "MATERN25", "MATERN_25"}:
            base_kernel = Matern(length_scale=float(self.length_scale), length_scale_bounds="fixed", nu=2.5)
        else:
            raise ValueError("GPR kernel_name must be one of: RBF, MATERN_1.5, MATERN_2.5")

        kernel = ConstantKernel(float(self.constant_value), constant_value_bounds="fixed") * base_kernel + WhiteKernel(
            noise_level=float(self.noise_level), noise_level_bounds="fixed"
        )

        self.model_ = GaussianProcessRegressor(
            kernel=kernel,
            alpha=float(self.alpha),
            optimizer=None,
            normalize_y=self.normalize_y,
            random_state=self.random_state,
        )
        self.model_.fit(X_scaled, y_arr)
        self.kernel_ = self.model_.kernel_
        return self

    def predict(self, X):
        X_df = pd.DataFrame(X).copy()
        X_scaled = self.scaler_.transform(X_df)
        return self.model_.predict(X_scaled)


# Copied from the corresponding current main ML workflow.
xgb_params_base = dict(
    n_estimators=120,
    max_depth=2,
    learning_rate=0.04,
    subsample=0.80,
    colsample_bytree=0.80,
    reg_lambda=10.0,
    reg_alpha=0.25,
    min_child_weight=4,
    gamma=0.5,
    objective="reg:squarederror",
    random_state=42,
    n_jobs=XGB_N_JOBS_FINAL,
)


# Copied from the corresponding current main ML workflow.
xgb_search_space = {
    "n_estimators": Integer(80, 300),
    "max_depth": Integer(1, 3),
    "learning_rate": Real(0.02, 0.10, prior="log-uniform"),
    "subsample": Real(0.70, 1.00),
    "colsample_bytree": Real(0.70, 1.00),
    "reg_lambda": Real(2.0, 50.0, prior="log-uniform"),
    "reg_alpha": Real(0.01, 5.0, prior="log-uniform"),
    "min_child_weight": Integer(3, 20),
    "gamma": Real(0.1, 5.0, prior="log-uniform"),
}


# Copied from the corresponding current main ML workflow.
gpr_params_base = {
    "kernel_name": GPR_KERNEL,
    "length_scale": 2.0,
    "constant_value": 1.0,
    "noise_level": 0.20,
    "alpha": GPR_ALPHA_FIXED,
    "normalize_y": True,
    "random_state": 42,
}


# Copied from the corresponding current main ML workflow.
gpr_search_space = {
    "length_scale": Real(0.8, 10.0, prior="log-uniform"),
    "constant_value": Real(0.20, 5.0, prior="log-uniform"),
    "noise_level": Real(0.03, 3.0, prior="log-uniform"),
}


def log(message):
    print(f"[{datetime.now():%Y-%m-%d %H:%M:%S}] {message}", flush=True)


def digest(value):
    """Stable configuration fingerprint; output paths and timestamps are excluded."""
    return hashlib.sha256(json.dumps(value, sort_keys=True, default=str).encode()).hexdigest()


def file_sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_json(path, value):
    """Replace a completed JSON only after its temporary file is fully written."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    temporary.replace(path)


def write_csv(path, frame):
    """Atomic replacement avoids leaving a truncated CSV if writing is interrupted.

    Close result CSVs in Excel before a rerun. If Windows locks a destination,
    the cached BO parameters still allow the same run to finish without retuning.
    """
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    frame.to_csv(temporary, index=False)
    temporary.replace(path)


def metrics(y_true, y_pred):
    """Pooled metrics: concatenate held-out predictions before computing R2."""
    actual = np.asarray(y_true, dtype=float)
    predicted = np.asarray(y_pred, dtype=float)
    if actual.shape != predicted.shape or not np.isfinite(predicted).all():
        raise ValueError("Predictions must have the same shape as finite actual yields.")
    residual = actual - predicted
    sst = np.sum((actual - actual.mean()) ** 2)
    r2 = (1.0 - np.sum(residual ** 2) / sst) if sst > 0 else (1.0 if np.all(residual == 0) else 0.0)
    return {"R2": float(r2) if len(actual) > 1 else np.nan,
            "MAE": float(np.abs(residual).mean()),
            "RMSE": float(np.sqrt(np.mean(residual ** 2)))}


def space_description(space):
    return {key: {"type": type(d).__name__, "low": float(d.low),
                  "high": float(d.high), "prior": d.prior} for key, d in space.items()}


def clean_group_column(series, name):
    """Require genuine group labels; never invent one-row papers as a fallback."""
    invalid = series.isna() | series.astype(str).str.strip().str.lower().isin(["", "nan", "none", "na", "n/a"])
    if invalid.any():
        raise ValueError(f"{name}: missing/invalid group labels at rows {np.flatnonzero(invalid).tolist()}.")
    return series.astype(str).str.strip().to_numpy(dtype=object)


def read_dataset(options):
    """Apply the same outcome exclusions, zero filling and filter as main code."""
    df = pd.read_excel(options.input, sheet_name=SHEET_NAME)
    df.columns = [str(c).strip() for c in df.columns]
    if TARGET not in df or "Is_unsupported_metal" not in df:
        raise ValueError("Use the updated workbook with the requested yield and Is_unsupported_metal columns.")
    df = df.loc[df[TARGET].notna()].copy()
    df.insert(0, "workbook_row_index", df.index.to_numpy())
    df = df.reset_index(drop=True)
    if len(df) < 6:
        raise ValueError("Too few observations for matched nested validation.")
    y = pd.to_numeric(df[TARGET], errors="raise").astype(float)
    if not np.isfinite(y).all():
        raise ValueError("The target contains infinite values.")
    excluded = [c for c in [TARGET] + LEAKAGE_COLS + ID_COLS + ["workbook_row_index"] if c in df]
    raw = df.drop(columns=excluded).apply(pd.to_numeric, errors="coerce")
    missing = raw.replace([np.inf, -np.inf], np.nan).isna().sum().rename_axis("feature").reset_index(name="missing_count")
    raw = raw.drop(columns=[c for c in raw if raw[c].isna().all()])
    all_features = raw.replace([np.inf, -np.inf], np.nan).fillna(0.0)
    if options.descriptor_filter:
        X, report = trim_rare_ml_features(all_features, MIN_BINARY_MINORITY_COUNT, MIN_CONTINUOUS_UNIQUE_VALUES)
    else:
        X = all_features.copy()
        report = pd.DataFrame({"feature": X.columns, "kept_for_ML": True,
                               "reason": "rare-feature filter disabled"})
    if "Catalyst_ID2" not in df:
        raise ValueError("Catalyst grouping requires Catalyst_ID2.")
    catalyst = clean_group_column(df.Catalyst_ID2, "Catalyst_ID2")
    source_column = next((c for c in ["Author", "Source_study", "Reference", "Paper"]
                          if c in df and df[c].notna().all()
                          and not df[c].astype(str).str.strip().str.lower().isin(["", "nan", "none", "na", "n/a"]).any()), None)
    if source_column is None:
        raise ValueError("LOPO requires a complete source-paper label column.")
    paper = np.array([source_column + ":" + s for s in clean_group_column(df[source_column], source_column)], dtype=object)
    return df, y, X, all_features, report, missing, catalyst, paper, source_column, excluded


def validate_partition(splits, groups, context):
    """Every validation row occurs once and no group crosses a train/test split."""
    coverage = np.zeros(len(groups), dtype=int)
    for tr, va in splits:
        if len(tr) < 2 or len(va) < 2:
            raise ValueError(f"{context}: each training/validation split needs at least two rows for R2 tuning.")
        if np.intersect1d(tr, va).size or set(groups[tr]) & set(groups[va]):
            raise RuntimeError(f"Group leakage detected in {context}.")
        coverage[va] += 1
    if not np.all(coverage == 1):
        raise RuntimeError(f"{context}: validation coverage must be exactly once per row.")


def matched_splits(strategy, X, y, groups, requested_folds, context):
    """There is deliberately no shuffled KFold fallback anywhere in this script."""
    count = len(np.unique(groups))
    if count < 2:
        raise ValueError(f"{context}: at least two distinct groups are needed.")
    splitter = GroupKFold(n_splits=min(requested_folds, count)) if strategy == "groupkfold_catalyst" else LeaveOneGroupOut()
    splits = [(np.asarray(tr), np.asarray(va)) for tr, va in splitter.split(X, y, groups)]
    validate_partition(splits, groups, context)
    return splits


def split_record(tr, va, groups, global_rows, **labels):
    return {**labels, "train_row_indices": global_rows[tr].tolist(),
            "validation_row_indices": global_rows[va].tolist(),
            "train_group_labels": sorted(set(map(str, groups[tr]))),
            "validation_group_labels": sorted(set(map(str, groups[va]))),
            "group_overlap": 0, "train_rows": len(tr), "validation_rows": len(va)}


def choose_main_outer_splits(options, strategy, groups, n_rows):
    """Use only main partitions proven to describe this workbook and group task.

    Group folds depend on identities, not descriptor filtering. If a matching
    filter-tag reference is unavailable, another filter tag of the SAME workbook
    may supply the same outer identities; all fitted features still follow the
    selected filter option. The provenance records which reference was used.
    """
    if options.fresh_outer_splits:
        return None, {"method": "fresh_grouped_splitter_explicitly_requested"}
    preferred = "filter_on" if options.descriptor_filter else "filter_off"
    tags = [preferred] + [tag for tag in ["filter_on", "filter_off"] if tag != preferred]
    workbook_hash = file_sha(options.input)
    for tag in tags:
        folder = options.main_results_root / tag / TARGET_NAME / strategy
        info_file = folder / "run_metadata.json"
        folds_file = folder / "xgboost_base_fold_metrics.csv"
        if not info_file.is_file() or not folds_file.is_file():
            continue
        info = json.loads(info_file.read_text(encoding="utf-8"))
        if info.get("workbook_sha256") != workbook_hash or info.get("target") != TARGET_NAME or info.get("cv_strategy") != strategy:
            continue
        frame = pd.read_csv(folds_file).sort_values("fold")
        if "seed" in frame:
            frame = frame.loc[frame.seed.eq(42)]
        splits = []
        for _, row in frame.iterrows():
            text = str(row.test_row_indices).strip().strip("[]")
            test = np.array([int(value.strip()) for value in text.split(",") if value.strip()], dtype=int)
            if len(test) == 0 or np.any(test < 0) or np.any(test >= n_rows):
                raise ValueError(f"Invalid saved main test-row indices in {folds_file}.")
            train = np.setdiff1d(np.arange(n_rows), test)
            if int(row.test_size) != len(test) or int(row.train_size) != len(train):
                raise ValueError(f"Saved main fold sizes do not match this dataset: {folds_file}.")
            splits.append((train, test))
        validate_partition(splits, groups, "saved main " + strategy)
        if len(splits) != (min(OUTER_GROUP_FOLDS, len(np.unique(groups))) if strategy == "groupkfold_catalyst" else len(np.unique(groups))):
            raise ValueError(f"The saved main fold count is inconsistent: {folds_file}.")
        return splits, {"method": "saved_main_outer_folds", "reference_filter_tag": tag,
                        "fold_file": str(folds_file.resolve()), "fold_file_sha256": file_sha(folds_file),
                        "metadata_file_sha256": file_sha(info_file)}
    if options.require_main_outer_splits:
        raise FileNotFoundError(f"No compatible saved main outer folds for {TARGET_NAME}/{strategy} in {options.main_results_root}.")
    log(f"No compatible saved main folds for {strategy}; generating fresh GROUPED outer folds.")
    return None, {"method": "fresh_grouped_splitter_no_compatible_main_reference"}


def make_plan(strategy, X, y, groups, outer_override=None, source_info=None):
    """Build exact outer and inner folds up front, before fitting any models."""
    outer = outer_override if outer_override is not None else matched_splits(strategy, X, y, groups, OUTER_GROUP_FOLDS, "outer " + strategy)
    validate_partition(outer, groups, "outer " + strategy)
    if strategy == "leave_one_paper_out" and len(np.unique(groups)) < 3:
        raise ValueError("Nested LOPO requires at least three total papers; two leave no valid inner LOPO.")
    label = f"Catalyst GroupKFold ({len(outer)}-fold)" if strategy == "groupkfold_catalyst" else "Leave-One-Paper-Out (LOPO)"
    global_rows = np.arange(len(y), dtype=int)
    # On all rows, the matched non-nested tuning partition is the same grouped
    # partition as the outer evaluation, including any saved-main tie choices.
    full_inner = [(tr.copy(), te.copy()) for tr, te in outer]
    audits = [split_record(tr, va, groups, global_rows, strategy=strategy,
                           BO_case="Non-nested BO", outer_fold=0, inner_fold=i)
              for i, (tr, va) in enumerate(full_inner, 1)]
    nested_inner = {}
    for fold, (tr, te) in enumerate(outer, 1):
        inner = matched_splits(strategy, X.iloc[tr], y.iloc[tr], groups[tr], INNER_GROUP_FOLDS,
                               f"nested {strategy} outer fold {fold}")
        nested_inner[fold] = inner
        for i, (a, b) in enumerate(inner, 1):
            row = split_record(a, b, groups[tr], tr, strategy=strategy,
                               BO_case="Nested BO", outer_fold=fold, inner_fold=i)
            if set(row["train_row_indices"] + row["validation_row_indices"]) & set(te):
                raise RuntimeError("Outer-test rows entered a nested inner split.")
            row["outer_test_row_indices"] = te.tolist()
            audits.append(row)
    return {"strategy": strategy, "label": label, "groups": groups, "outer": outer,
            "outer_split_source": source_info or {"method": "fresh_grouped_splitter"},
            "full_inner": full_inner, "nested_inner": nested_inner, "inner_audit": audits,
            "outer_audit": [split_record(tr, te, groups, global_rows, strategy=strategy, outer_fold=i)
                            for i, (tr, te) in enumerate(outer, 1)]}


def model_params(model_name, overrides, seed, options, for_search=False):
    params = (xgb_params_base if model_name == "XGBoost" else gpr_params_base).copy()
    params.update(overrides)
    params["random_state"] = seed
    if model_name == "XGBoost":
        params.update(objective="reg:squarederror", n_jobs=(XGB_N_JOBS_DURING_BO if for_search else options.xgb_jobs))
    else:
        params.update(kernel_name=GPR_KERNEL, alpha=GPR_ALPHA_FIXED, normalize_y=True)
    return params


def make_model(model_name, overrides, seed, options, for_search=False):
    params = model_params(model_name, overrides, seed, options, for_search)
    return xgb.XGBRegressor(**params) if model_name == "XGBoost" else TunableGPR(**params)


def run_search(model_name, X, y, splits, seed, options, cache_dir, signature, context, counters):
    """Reuse only a complete cache with exactly the same data/code/settings hash."""
    cache_dir.mkdir(parents=True, exist_ok=True)
    info_path = cache_dir / "search.json"
    trials_path = cache_dir / "trials.csv"
    if not options.force_retune and info_path.exists() and trials_path.exists():
        saved = json.loads(info_path.read_text(encoding="utf-8"))
        if (saved.get("analysis_signature") == signature and saved.get("context") == context
                and saved.get("model") == model_name and saved.get("seed") == seed
                and saved.get("trials_sha256") == file_sha(trials_path)):
            counters["cached"] += 1
            log(f"Reusing completed BO: seed {seed} | {model_name} | {context}")
            return saved["best_params"], pd.read_csv(trials_path), saved["best_inner_cv_R2"], saved["elapsed_seconds"]
    log(f"BO started: seed {seed} | {model_name} | {context} | matched inner folds={len(splits)} | trials={options.bo_iterations}")
    acq, kwargs = configure_acquisition_function(ML_BO_ACQ_FUNC, ML_BO_ACQ_KAPPA, ML_BO_ACQ_XI)
    search = BayesSearchCV(
        estimator=make_model(model_name, {}, seed, options, for_search=True),
        search_spaces=xgb_search_space if model_name == "XGBoost" else gpr_search_space,
        n_iter=options.bo_iterations, scoring="r2", cv=splits,
        n_jobs=min(len(splits), effective_n_jobs(options.jobs)),
        random_state=seed, optimizer_kwargs={"acq_func": acq, "acq_func_kwargs": kwargs},
        refit=True, return_train_score=True, error_score="raise", verbose=0,
    )
    started = time.perf_counter()
    # Prevent nested BLAS thread pools competing with parallel CV workers.
    # Warnings are intentionally not globally suppressed.
    with parallel_backend("loky", inner_max_num_threads=1):
        search.fit(X, y)
    elapsed = time.perf_counter() - started
    if not np.isfinite(search.best_score_):
        raise RuntimeError(f"Non-finite BO score in {context}; do not publish this search.")
    best = safe_param_dict(search.best_params_)
    trials = pd.DataFrame(search.cv_results_)
    # Keep true evaluation order. Sorting by rank before assigning an iteration
    # number would mislabel optimization history as an acquisition sequence.
    trials.insert(0, "bo_iteration", np.arange(1, len(trials) + 1))
    trials["mean_inner_cv_R2"] = trials.mean_test_score
    trials["context"] = context
    trials["model"] = model_name
    trials["seed"] = seed
    write_csv(trials_path, trials)
    write_json(info_path, {"analysis_signature": signature, "context": context, "model": model_name, "seed": seed,
                          "best_params": best, "best_inner_cv_R2": float(search.best_score_),
                          "elapsed_seconds": elapsed, "trials_sha256": file_sha(trials_path)})
    counters["new"] += 1
    log(f"BO complete: {model_name} | {context} | mean inner R2={search.best_score_:.5f}")
    return best, trials, float(search.best_score_), elapsed


def evaluate_case(model_name, case, plan, X, y, observations, seed, options, out_dir, signature, counters):
    """Base uses fixed settings; non-nested tunes on all rows; nested tunes within each outer training fold."""
    strategy = plan["strategy"]
    cache_base = out_dir / "bo_cache" / f"s{seed}" / ("cat" if strategy == "groupkfold_catalyst" else "lopo") / ("xgb" if model_name == "XGBoost" else "gpr")
    predictions = np.full(len(y), np.nan)
    fold_ids = np.zeros(len(y), dtype=int)
    fold_rows, all_trials, best_rows = [], [], []
    fixed = {}
    full_score, full_elapsed = np.nan, 0.0
    if case == "Non-nested BO":
        fixed, trials, best_score, elapsed = run_search(model_name, X, y, plan["full_inner"], seed,
            options, cache_base / "full", signature, "full_data_" + strategy, counters)
        full_score, full_elapsed = best_score, elapsed
        trials["outer_strategy"] = strategy
        trials["outer_fold"] = 0
        trials["BO_case"] = case
        all_trials.append(trials)
        best_rows.append({"seed": seed, "model": model_name, "BO_case": case,
                          "outer_strategy": strategy, "outer_fold": 0,
                          "best_inner_cv_R2": best_score, "parameters_json": json.dumps(fixed, sort_keys=True)})
    for fold, (tr, te) in enumerate(plan["outer"], 1):
        params = fixed.copy()
        score = full_score
        elapsed = full_elapsed
        if case == "Nested BO":
            params, trials, score, elapsed = run_search(model_name, X.iloc[tr], y.iloc[tr],
                plan["nested_inner"][fold], seed, options, cache_base / f"o{fold}", signature,
                f"{strategy}_outer_{fold}", counters)
            trials["outer_strategy"] = strategy
            trials["outer_fold"] = fold
            trials["BO_case"] = case
            all_trials.append(trials)
            best_rows.append({"seed": seed, "model": model_name, "BO_case": case,
                              "outer_strategy": strategy, "outer_fold": fold,
                              "best_inner_cv_R2": score, "parameters_json": json.dumps(params, sort_keys=True)})
        model = make_model(model_name, params, seed, options)
        model.fit(X.iloc[tr], y.iloc[tr])
        train_prediction, test_prediction = model.predict(X.iloc[tr]), model.predict(X.iloc[te])
        if np.isfinite(predictions[te]).any():
            raise RuntimeError("An observation received more than one OOF prediction.")
        predictions[te] = test_prediction
        fold_ids[te] = fold
        train_metrics, test_metrics = metrics(y.iloc[tr], train_prediction), metrics(y.iloc[te], test_prediction)
        fold_rows.append({"seed": seed, "outer_validation": plan["label"], "outer_strategy": strategy,
            "model": model_name, "BO_case": case, "outer_fold": fold,
            "train_rows": len(tr), "test_rows": len(te),
            "train_row_indices": json.dumps(tr.tolist()), "test_row_indices": json.dumps(te.tolist()),
            "held_out_groups": json.dumps(sorted(set(map(str, plan["groups"][te])))),
            "group_overlap": 0, "best_inner_cv_R2": score, "bo_elapsed_seconds": elapsed,
            "parameters_used_json": json.dumps(model_params(model_name, params, seed, options), sort_keys=True),
            **{"train_" + key: val for key, val in train_metrics.items()},
            **{"test_" + key: val for key, val in test_metrics.items()}})
    if not np.isfinite(predictions).all():
        raise RuntimeError("The OOF prediction vector is incomplete.")
    row = {"seed": seed, "outer_validation": plan["label"], "outer_strategy": strategy,
           "inner_BO_validation": "not applicable" if case == "Base case" else strategy,
           "model": model_name, "BO_case": case, "n_rows": len(y), "n_outer_folds": len(plan["outer"]),
           "metric_aggregation": "pooled out-of-fold predictions", **metrics(y, predictions)}
    P = observations.copy()
    P["seed"] = seed
    P["outer_validation"] = plan["label"]
    P["outer_strategy"] = strategy
    P["model"] = model_name
    P["BO_case"] = case
    P["outer_fold"] = fold_ids
    P["actual"] = y.to_numpy()
    P["oof_prediction"] = predictions
    log(f"OOF complete: seed {seed} | {strategy} | {model_name} | {case} | R2={row['R2']:.5f}, RMSE={row['RMSE']:.5f} pp")
    return row, P, pd.DataFrame(fold_rows), all_trials, best_rows


def parse_options(argv=None):
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--input", type=Path, default=INPUT_FILE)
    p.add_argument("--output-root", type=Path, default=RESULTS_ROOT,
                   help="Root folder; filter_on/off and the target name are appended.")
    p.add_argument("--main-results-root", type=Path, default=MAIN_RESULTS_ROOT, help="Main-result folds used to keep the outer test rows identical.")
    p.add_argument("--fresh-outer-splits", action="store_true", default=not PREFER_SAVED_MAIN_OUTER_SPLITS)
    p.add_argument("--require-main-outer-splits", action="store_true", help="Fail rather than generate new outer folds if compatible main results are unavailable.")
    p.add_argument("--seeds", nargs="+", type=int, default=RUN_SEEDS,
                   help="Default 42. For the main five seeds: --seeds 42 101 202 303 404")
    p.add_argument("--bo-iterations", type=int, default=BO_N_ITER)
    p.add_argument("--jobs", type=int, default=BO_SEARCH_N_JOBS, help="Parallel CV workers; 1 is useful on small datasets.")
    p.add_argument("--xgb-jobs", type=int, default=XGB_N_JOBS_FINAL)
    p.add_argument("--descriptor-filter", dest="descriptor_filter", action="store_true")
    p.add_argument("--no-descriptor-filter", dest="descriptor_filter", action="store_false")
    p.set_defaults(descriptor_filter=APPLY_RARE_FEATURE_FILTER_TO_ML)
    p.add_argument("--force-retune", action="store_true", help="Ignore completed BO caches and optimize again.")
    p.add_argument("--check-config", action="store_true", help="Validate data and all exact group splits without fitting or writing results.")
    opts = p.parse_args(argv)
    if opts.bo_iterations < 1 or opts.jobs == 0 or opts.xgb_jobs == 0:
        p.error("BO iterations must be positive; worker counts cannot be zero.")
    if opts.fresh_outer_splits and opts.require_main_outer_splits:
        p.error("--fresh-outer-splits and --require-main-outer-splits cannot be combined.")
    if not opts.seeds or len(set(opts.seeds)) != len(opts.seeds) or any(seed < 0 for seed in opts.seeds):
        p.error("Provide distinct nonnegative seeds.")
    return opts


def run_workflow(options):
    started = time.perf_counter()
    df, y, X, all_features, report, missing, catalyst, paper, paper_source, excluded = read_dataset(options)
    plans = []
    for strategy in STRATEGIES:
        groups = catalyst if strategy == "groupkfold_catalyst" else paper
        saved, source_info = choose_main_outer_splits(options, strategy, groups, len(y))
        plans.append(make_plan(strategy, X, y, groups, saved, source_info))
    log(f"{TARGET_DISPLAY}: {len(y)} rows, {X.shape[1]} descriptors, seeds={options.seeds}, descriptor filter={options.descriptor_filter}")
    for plan in plans:
        log(f"Matched {plan['label']}: {len(plan['outer'])} outer folds; inner-fold counts={[len(v) for v in plan['nested_inner'].values()]}; outer source={plan['outer_split_source']['method']}")
    if options.check_config:
        log("All inner/outer group checks passed. No models fitted and no output files written.")
        return
    tag = "filter_on" if options.descriptor_filter else "filter_off"
    parent = options.output_root / tag
    out = parent / TARGET_NAME
    out.mkdir(parents=True, exist_ok=True)
    reference = SCRIPT_DIR / MAIN_REFERENCE_FILENAME
    if reference.exists() and file_sha(reference) != MAIN_REFERENCE_SHA256:
        warnings.warn("The main ML source changed after alignment. Compare settings before a formal comparison.")
    configuration = {"target": TARGET_NAME, "seeds": options.seeds, "descriptor_filter": options.descriptor_filter,
        "filter_scope": "predictor-only full-table screen before CV, matching main workflow",
        "binary_minority_count": MIN_BINARY_MINORITY_COUNT, "continuous_unique_values": MIN_CONTINUOUS_UNIQUE_VALUES,
        "xgb_base": xgb_params_base, "gpr_base": gpr_params_base,
        "xgb_search_space": space_description(xgb_search_space), "gpr_search_space": space_description(gpr_search_space),
        "bo_iterations": options.bo_iterations, "scoring": "mean inner-fold R2", "acquisition": ML_BO_ACQ_FUNC,
        "acquisition_kappa": ML_BO_ACQ_KAPPA, "acquisition_xi": ML_BO_ACQ_XI,
        "outer_group_folds": OUTER_GROUP_FOLDS, "inner_group_folds": INNER_GROUP_FOLDS,
        "outer_split_sources": {plan["strategy"]: plan["outer_split_source"] for plan in plans},
        "exact_outer_splits": {plan["strategy"]: [te.tolist() for tr, te in plan["outer"]] for plan in plans},
        "inner_policy": "matched_grouping_no_rowwise_fallback", "jobs": options.jobs, "xgb_jobs": options.xgb_jobs,
        "feature_columns": list(X.columns), "excluded_columns": excluded,
        "workbook_sha256": file_sha(options.input), "script_sha256": file_sha(__file__),
        "data_matrix_sha256": hashlib.sha256(X.to_csv(index=False, float_format="%.17g").encode()).hexdigest(),
        "libraries": {name: importlib.metadata.version(name) for name in ["numpy", "pandas", "scikit-learn", "xgboost", "scikit-optimize"]}}
    signature = digest(configuration)
    metadata = {"status": "running", "run_id": uuid.uuid4().hex, "analysis_signature": signature,
        "created_utc": datetime.now(timezone.utc).isoformat(), "input_file": str(options.input.resolve()),
        "script_file": str(Path(__file__).resolve()), "main_reference_sha256": MAIN_REFERENCE_SHA256,
        "n_rows": len(y), "n_features": X.shape[1], "paper_label_column": paper_source,
        "python_version": platform.python_version(), "configuration": configuration}
    write_json(out / "run_metadata.json", metadata)
    observations = df[[c for c in ["workbook_row_index"] + ID_COLS if c in df]].copy()
    observations.insert(0, "row_index", np.arange(len(y)))
    observations["catalyst_group"] = catalyst
    observations["paper_group"] = paper
    observations["actual"] = y.to_numpy()
    write_csv(out / "observations_and_groups.csv", observations)
    write_csv(out / "processed_features.csv", X.assign(row_index=np.arange(len(y))))
    write_csv(out / "features_before_filter.csv", all_features.assign(row_index=np.arange(len(y))))
    write_csv(out / "descriptor_filter_report.csv", report)
    write_csv(out / "missing_values_before_zero_fill.csv", missing)
    write_json(out / "configuration.json", configuration)
    all_inner = [r for plan in plans for r in plan["inner_audit"]]
    all_outer = [r for plan in plans for r in plan["outer_audit"]]
    split_payload = {"row_index_basis": "zero-based retained rows", "outer": all_outer, "inner": all_inner}
    write_json(out / "inner_outer_splits.json", split_payload)
    audit = pd.DataFrame(all_inner)
    for c in ["train_row_indices", "validation_row_indices", "outer_test_row_indices", "train_group_labels", "validation_group_labels"]:
        audit[c] = audit[c].map(lambda value: json.dumps(value) if isinstance(value, list) else "")
    write_csv(out / f"{TARGET_DISPLAY}_matched_CV_BO_inner_CV_group_audit.csv", audit)
    shutil.copy2(__file__, out / Path(__file__).name)
    metric_rows, pred_frames, fold_frames, trials, best = [], [], [], [], []
    counters = {"new": 0, "cached": 0}
    try:
        for seed in options.seeds:
            for plan in plans:
                for model_name in ["XGBoost", "GPR"]:
                    for case in ["Base case", "Non-nested BO", "Nested BO"]:
                        row, pred, folds, t, b = evaluate_case(model_name, case, plan, X, y, observations,
                            seed, options, out, signature, counters)
                        metric_rows.append(row); pred_frames.append(pred); fold_frames.append(folds)
                        trials.extend(t); best.extend(b)
                        # A clearly labelled partial table is useful after interruption;
                        # it is never published as a completed plotting snapshot.
                        write_csv(out / "progress_metrics_partial.csv", pd.DataFrame(metric_rows))
        tables = {"metrics": pd.DataFrame(metric_rows), "OOF_predictions_LONG": pd.concat(pred_frames, ignore_index=True),
                  "outer_fold_metrics": pd.concat(fold_frames, ignore_index=True),
                  "all_trials": pd.concat(trials, ignore_index=True), "best_params": pd.DataFrame(best)}
        for name, table in tables.items():
            table["target"] = TARGET_NAME
            table["descriptor_filter"] = options.descriptor_filter
            table["workbook_sha256"] = configuration["workbook_sha256"]
            table["analysis_signature"] = signature
            table["run_id"] = metadata["run_id"]
            write_csv(out / f"{TARGET_DISPLAY}_matched_CV_BO_{name}.csv", table)
        grouped = tables["metrics"].groupby(["outer_validation", "outer_strategy", "model", "BO_case"], sort=False)
        mean_sd = grouped.agg(n_seeds=("seed", "nunique"), R2_mean=("R2", "mean"), R2_SD=("R2", "std"),
                              MAE_mean=("MAE", "mean"), MAE_SD=("MAE", "std"), RMSE_mean=("RMSE", "mean"), RMSE_SD=("RMSE", "std")).reset_index()
        write_csv(out / "metrics_mean_SD.csv", mean_sd)
        metadata.update(status="complete", elapsed_seconds=time.perf_counter() - started, searches=counters)
        write_json(out / "run_metadata.json", metadata)
        # Both targets publish into one flat snapshot folder: these are exactly
        # the four prefixed CSVs expected by the merged plotting script.
        snapshot = parent / "plotting_snapshot"
        snapshot.mkdir(parents=True, exist_ok=True)
        published = {}
        for name in ["metrics", "OOF_predictions_LONG", "outer_fold_metrics", "all_trials"]:
            filename = f"{TARGET_DISPLAY}_matched_CV_BO_{name}.csv"
            shutil.copy2(out / filename, snapshot / filename)
            published[filename] = file_sha(snapshot / filename)
        write_json(snapshot / f"{TARGET_DISPLAY}_snapshot_manifest.json", {
            "status": "complete", "target": TARGET_NAME, "run_id": metadata["run_id"],
            "analysis_signature": signature, "workbook_sha256": configuration["workbook_sha256"],
            "descriptor_filter": options.descriptor_filter, "seeds": options.seeds,
            "bo_iterations": options.bo_iterations, "inner_policy": configuration["inner_policy"],
            "outer_splits_sha256": digest({p["strategy"]: [te.tolist() for tr, te in p["outer"]] for p in plans}),
            "n_rows": len(y), "files": published,
            "source_results_relative_path": "../" + TARGET_NAME})
        log(f"Completed {TARGET_DISPLAY}: {out}")
        log(f"Plot-ready snapshot: {snapshot}; new searches={counters['new']}, cached searches={counters['cached']}")
    except BaseException as exc:
        metadata.update(status="failed", error=str(exc), searches=counters)
        write_json(out / "run_metadata.json", metadata)
        raise


if __name__ == "__main__":
    with threadpool_limits(limits=1):
        run_workflow(parse_options())


