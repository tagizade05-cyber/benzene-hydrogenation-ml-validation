"""Resolve the results layout and fill missing LOO curves from saved parameters.

No Bayesian optimization is imported or run. Existing learning CSVs are reused.
"""
from pathlib import Path
import argparse
import hashlib
import json
import sys
import time

import numpy as np
import pandas as pd

# The four plotting entry points live in workflow/results/, while the original
# shared validators live one level above. Also support running extracted scripts
# with an explicitly supplied results root when workflow_common is on PYTHONPATH.
_HERE = Path(__file__).resolve().parent
for _candidate in (_HERE.parent, _HERE):
    if (_candidate / 'workflow_common.py').is_file():
        sys.path.insert(0, str(_candidate))
        break
import workflow_common as _shared

CV_CASES = _shared.CV_CASES
PLOT_MODELS = _shared.PLOT_MODELS
load_four_metric_csvs = _shared.load_four_metric_csvs
_OOF_OPTIONS = None


def _root_for_scripts(script_dir):
    script_dir = Path(script_dir).resolve()
    if (script_dir / 'metrics_heatmaps').is_dir() or script_dir.name.lower() == 'results':
        return script_dir
    if (script_dir / 'results').is_dir():
        return script_dir / 'results'
    return script_dir


def _options(script_dir, target, kind):
    p = argparse.ArgumentParser(description=f'Plot saved {target} {kind} results.')
    p.add_argument('--results-root', type=Path, default=_root_for_scripts(script_dir))
    p.add_argument('--descriptor-filter', action=argparse.BooleanOptionalAction, default=True)
    p.add_argument('--output-dir', type=Path)
    return p


def load_metric_plot_options(script_dir, target):
    p = _options(script_dir, target, 'metric heatmaps')
    p.add_argument('--files', type=Path, nargs=4)
    p.add_argument('--dpi', type=int, default=300)
    a = p.parse_args()
    directory = a.results_root / 'metrics_heatmaps' / ('filter_on' if a.descriptor_filter else 'filter_off') / target
    a.files = a.files or [directory / f'{cv}.csv' for cv in CV_CASES]
    a.output_dir = a.output_dir or directory / 'figures'
    missing = [str(path) for path in a.files if not path.is_file()]
    if missing:
        raise FileNotFoundError(f'{target}: missing completed metric CSVs:\n' + '\n'.join(missing))
    if a.dpi < 72:
        p.error('DPI must be at least 72.')
    return a


def load_oof_plot_options(script_dir, target):
    global _OOF_OPTIONS
    p = _options(script_dir, target, 'OOF vs Actual and learning curves')
    p.add_argument('--data-dir', type=Path)
    p.add_argument('--generate-missing-loo-learning-curves', action=argparse.BooleanOptionalAction, default=True,
                   help='Fill missing LOO curves from saved fold parameters; no Bayesian optimization.')
    p.add_argument('--learning-fractions', type=float, nargs='+',
                   help='Fractions for a newly computed LOO curve; defaults to the other saved curves.')
    a = p.parse_args()
    a.data_dir = a.data_dir or a.results_root / 'oof_learning_curves' / ('filter_on' if a.descriptor_filter else 'filter_off') / target
    a.output_dir = a.output_dir or a.data_dir / 'figures'
    _OOF_OPTIONS = a
    return a


def learning_curve_note(frame):
    if 'learning_curve_method' in frame and frame['learning_curve_method'].eq('fixed_outer_fold_parameters').any():
        return 'LOO: saved fold-specific parameters reused; reduced training subsets refitted without Bayesian optimization. Other CV curves read from saved files.'
    return ''


def _scores(actual, predicted):
    from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
    return {'R2': float(r2_score(actual, predicted)),
            'MAE': float(mean_absolute_error(actual, predicted)),
            'RMSE': float(np.sqrt(mean_squared_error(actual, predicted)))}


def _fold_parameters(frame, base, fold, names, enabled):
    result = dict(base)
    if not enabled:
        return result
    required = {'outer_fold', 'parameter', 'value'}
    if required.difference(frame):
        raise ValueError('Saved optimized parameter table is incomplete.')
    subset = frame.loc[pd.to_numeric(frame['outer_fold'], errors='raise').eq(fold)]
    found = subset.loc[subset['parameter'].isin(names), ['parameter', 'value']]
    if found['parameter'].duplicated().any() or set(found['parameter']) != set(names):
        raise ValueError(f'Missing or duplicated optimized parameters for outer fold {fold}.')
    for key, value in found.itertuples(index=False, name=None):
        value = float(value)
        if not np.isfinite(value):
            raise ValueError(f'Invalid parameter {key} in fold {fold}.')
        if isinstance(base.get(key), int) and not isinstance(base.get(key), bool):
            if not value.is_integer():
                raise ValueError(f'Noninteger {key} in fold {fold}.')
            value = int(value)
        result[key] = value
    return result


def _read_params(path, enabled):
    if not enabled:
        return pd.DataFrame()
    return pd.read_csv(path)


def _bundle_fingerprint(bundle, fractions, settings):
    names = ['manifest.json', 'model_settings_seed42.json', 'processed_features_seed42.csv',
             'OOF_predictions_seed42.csv', 'outer_cv_splits_seed42.json',
             'learning_curve_full_size_metrics_seed42.csv']
    if settings['xgboost_bo_enabled']:
        names.append('xgboost_nested_BO_best_params_by_outer_fold.csv')
    if settings['gpr_bo_enabled']:
        names.append('gpr_nested_BO_best_params_by_outer_fold.csv')
    digest = hashlib.sha256()
    for name in names:
        digest.update(name.encode())
        digest.update((bundle / name).read_bytes())
    digest.update(json.dumps({'method':'fixed_outer_fold_parameters_v1','fractions':list(fractions)}).encode())
    return digest.hexdigest()


def generate_saved_parameter_loo_curve(case_dir, target, fractions):
    """Fit reduced subsets only, using the exact saved LOO parameters and splits."""
    bundle = case_dir / 'learning_curve_inputs_seed42'
    required_names = ('manifest.json', 'model_settings_seed42.json', 'processed_features_seed42.csv',
                      'OOF_predictions_seed42.csv', 'outer_cv_splits_seed42.json',
                      'learning_curve_full_size_metrics_seed42.csv')
    missing = [str(bundle / name) for name in required_names if not (bundle / name).is_file()]
    if missing:
        raise FileNotFoundError('Cannot calculate missing LOO learning points. Missing saved inputs:\n' + '\n'.join(missing))
    manifest = json.loads((bundle / 'manifest.json').read_text(encoding='utf-8'))
    settings = json.loads((bundle / 'model_settings_seed42.json').read_text(encoding='utf-8'))
    if manifest.get('target') != target or manifest.get('cv_strategy') != 'leave_one_out' or manifest.get('seed') != 42:
        raise ValueError('Saved learning-curve bundle has the wrong target, CV strategy or seed.')
    feature_frame = pd.read_csv(bundle / 'processed_features_seed42.csv')
    observations = pd.read_csv(bundle / 'OOF_predictions_seed42.csv')
    outer_predictions = pd.read_csv(case_dir / 'OOF_predictions_seed42.csv')
    full = pd.read_csv(bundle / 'learning_curve_full_size_metrics_seed42.csv')
    splits = json.loads((bundle / 'outer_cv_splits_seed42.json').read_text(encoding='utf-8'))
    actual_col = f'actual_{target.capitalize()}_yield_%'
    n = len(feature_frame)
    if not np.array_equal(feature_frame['row_index'], np.arange(n)) or not np.array_equal(observations['row_index'], np.arange(n)):
        raise ValueError('Saved features and observations have inconsistent row ordering.')
    X = feature_frame.drop(columns='row_index')
    y = observations[actual_col].to_numpy(dtype=float)
    if list(X) != settings['feature_columns'] or not np.isfinite(X.to_numpy(dtype=float)).all() or not np.isfinite(y).all():
        raise ValueError('Saved feature columns/values do not match the model settings.')
    if len(outer_predictions) != n or not np.array_equal(outer_predictions['row_index'], observations['row_index']) or not np.allclose(outer_predictions[actual_col], y):
        raise ValueError('Saved bundle does not match the current LOO prediction table.')
    for col in ('xgboost_nested_bo_oof_pred_%', 'gpr_nested_bo_oof_pred_%', 'ordinary_linear_regression_oof_pred_%'):
        if not np.allclose(outer_predictions[col], observations[col]):
            raise ValueError('Saved bundle predictions differ from the current LOO results.')
    _shared._validate_provenance([outer_predictions], target)
    if not outer_predictions['cv_strategy'].eq('leave_one_out').all() or not outer_predictions['seed'].eq(42).all():
        raise ValueError('Current LOO predictions have the wrong CV strategy or seed.')
    if not outer_predictions['workbook_sha256'].eq(manifest['workbook_sha256']).all():
        raise ValueError('Saved LOO inputs use a different dataset.')
    coverage = np.zeros(n, dtype=int)
    for i, split in enumerate(splits, 1):
        tr, te = np.asarray(split['train_indices'], dtype=int), np.asarray(split['test_indices'], dtype=int)
        if split['outer_fold'] != i or len(tr) != n-1 or len(te) != 1 or set(tr) & set(te) or set(tr) | set(te) != set(range(n)):
            raise ValueError(f'Invalid LOO split {i}.')
        coverage[te] += 1
    if len(splits) != n or not np.all(coverage == 1):
        raise ValueError('Saved LOO splits do not hold out each row exactly once.')
    fractions = sorted(set(float(f) for f in fractions))
    if len(fractions) < 2 or fractions[-1] != 1. or not all(0 < f <= 1 for f in fractions):
        raise ValueError('Learning fractions must be in (0,1], with at least two points including 1.0.')
    xgb_names = ('n_estimators','max_depth','learning_rate','subsample','colsample_bytree','reg_lambda','reg_alpha','min_child_weight','gamma')
    gpr_names = ('length_scale','constant_value','noise_level')
    xgb_best = _read_params(bundle / 'xgboost_nested_BO_best_params_by_outer_fold.csv', settings['xgboost_bo_enabled'])
    gpr_best = _read_params(bundle / 'gpr_nested_BO_best_params_by_outer_fold.csv', settings['gpr_bo_enabled'])
    fold_params = {}
    for i in range(1, n+1):
        xp = _fold_parameters(xgb_best, settings['xgboost_base_parameters'], i, xgb_names, settings['xgboost_bo_enabled'])
        xp.update(random_state=42, n_jobs=1)
        gp = _fold_parameters(gpr_best, settings['gpr_base_parameters'], i, gpr_names, settings['gpr_bo_enabled'])
        gp.update(random_state=42, kernel_name=settings['gpr_kernel'], alpha=settings['gpr_alpha_fixed'])
        fold_params[i] = (xp, gp)
    source_hash = _bundle_fingerprint(bundle, fractions, settings)
    from saved_curve_estimators import TunableGPR, OrdinaryLinearRegressor
    from xgboost import XGBRegressor
    from threadpoolctl import threadpool_limits
    rows, audit = [], []
    started = time.perf_counter()
    for fraction in fractions:
        for model_index, label in enumerate(PLOT_MODELS):
            if fraction == 1.:
                match = full.loc[full['model'].eq(label) & full['train_fraction'].eq(1.)]
                if len(match) != 1:
                    raise ValueError(f'Missing saved full-size scores for {label}.')
                row = match.iloc[0].to_dict()
                prediction_col = ('xgboost_nested_bo_oof_pred_%', 'gpr_nested_bo_oof_pred_%', 'ordinary_linear_regression_oof_pred_%')[model_index]
                expected = _scores(y, outer_predictions[prediction_col])
                if any(not np.isclose(row['validation_'+key], value, rtol=1e-7, atol=1e-8) for key, value in expected.items()):
                    raise ValueError(f'Saved full-size point does not match OOF predictions for {label}.')
                row['full_size_scores_reused'] = True
            else:
                print(f'{target}: LOO fraction {fraction:g}, {label}; fixed saved parameters, no optimization', flush=True)
                oof = np.full(n, np.nan)
                train_true, train_pred, sizes = [], [], []
                with threadpool_limits(limits=1):
                    for split in splits:
                        fold = split['outer_fold']
                        tr, te = np.asarray(split['train_indices'], dtype=int), np.asarray(split['test_indices'], dtype=int)
                        count = min(len(tr), max(3, int(np.ceil(fraction * len(tr)))))
                        subset_seed = 42 + 10000*model_index + 100*fold + int(round(fraction*1000))
                        chosen = np.sort(np.random.default_rng(subset_seed).choice(tr, size=count, replace=False))
                        xp, gp = fold_params[fold]
                        estimator = XGBRegressor(**xp) if model_index == 0 else TunableGPR(**gp) if model_index == 1 else OrdinaryLinearRegressor()
                        estimator.fit(X.iloc[chosen], y[chosen])
                        oof[te] = estimator.predict(X.iloc[te])
                        train_true.extend(y[chosen])
                        train_pred.extend(estimator.predict(X.iloc[chosen]))
                        sizes.append(count)
                        audit.append({'model':label, 'train_fraction':fraction, 'outer_fold':fold,
                                      'training_row_indices':json.dumps(chosen.tolist()),
                                      'test_row_indices':json.dumps(te.tolist()), 'subset_seed':subset_seed,
                                      'parameters':json.dumps(xp if model_index==0 else gp if model_index==1 else {}, sort_keys=True)})
                if not np.isfinite(oof).all():
                    raise ValueError('Incomplete reduced-size LOO predictions.')
                tm, vm = _scores(train_true, train_pred), _scores(y, oof)
                row = {'model':label, 'train_fraction':fraction, 'mean_outer_train_rows_used':float(np.mean(sizes)),
                       'min_outer_train_rows_used':min(sizes), 'max_outer_train_rows_used':max(sizes),
                       **{f'train_{k}':v for k,v in tm.items()}, **{f'validation_{k}':v for k,v in vm.items()},
                       'full_size_scores_reused':False}
            row.update(cv_strategy='leave_one_out', seed=42, learning_curve_method='fixed_outer_fold_parameters',
                       retuned_on_subset=False, learning_curve_input_sha256=source_hash,
                       validation_aggregation='pooled outer-test predictions',
                       training_aggregation='pooled used training rows across outer folds')
            for column in ('target','run_signature','workbook_sha256','descriptor_filter','xgb_bo_enabled','gpr_bo_enabled'):
                if column in outer_predictions:
                    row[column] = outer_predictions[column].iloc[0]
            rows.append(row)
    frame = pd.DataFrame(rows)
    destination = case_dir / 'learning_curves_all_metrics_seed42.csv'
    frame.to_csv(destination, index=False)
    pd.DataFrame(audit).to_csv(case_dir / 'learning_curve_fixed_parameters_audit_seed42.csv', index=False)
    (case_dir / 'learning_curve_fixed_parameters_metadata_seed42.json').write_text(json.dumps({
        'target':target, 'cv_strategy':'leave_one_out', 'seed':42, 'fractions':fractions,
        'method':'fixed_outer_fold_parameters', 'bayesian_optimization_run':False,
        'full_size_scores_reused':True, 'input_sha256':source_hash,
        'reduced_subset_fit_count':len(audit), 'elapsed_seconds':time.perf_counter()-started,
        'note':'Diagnostic curves conditional on parameters selected using each original outer-training fold.'}, indent=2), encoding='utf-8')
    print(f'Saved LOO learning curves: {destination}; {len(audit)} fixed-parameter fits, no optimization.', flush=True)
    return destination


def load_oof_inputs(directory, target):
    directory = Path(directory)
    missing = [str(directory / cv / 'OOF_predictions_seed42.csv') for cv in CV_CASES
               if not (directory / cv / 'OOF_predictions_seed42.csv').is_file()]
    if missing:
        raise FileNotFoundError(f'{target}: missing completed OOF prediction CSVs:\n' + '\n'.join(missing))
    loo_file = directory / 'leave_one_out' / 'learning_curves_all_metrics_seed42.csv'
    generate = not loo_file.is_file()
    if not generate:
        existing = pd.read_csv(loo_file)
        bundle = directory / 'leave_one_out' / 'learning_curve_inputs_seed42'
        if 'learning_curve_method' in existing and existing['learning_curve_method'].eq('fixed_outer_fold_parameters').all() and bundle.is_dir():
            settings = json.loads((bundle / 'model_settings_seed42.json').read_text(encoding='utf-8'))
            desired = (_OOF_OPTIONS.learning_fractions if _OOF_OPTIONS is not None else None) or sorted(existing['train_fraction'].unique())
            desired = sorted(set(float(f) for f in desired))
            fingerprint = _bundle_fingerprint(bundle, desired, settings)
            generate = 'learning_curve_input_sha256' not in existing or not existing['learning_curve_input_sha256'].eq(fingerprint).all()
    if generate:
        if _OOF_OPTIONS is None or not _OOF_OPTIONS.generate_missing_loo_learning_curves:
            raise FileNotFoundError(f'Missing {loo_file}. Enable --generate-missing-loo-learning-curves to use the saved LOO inputs.')
        fractions = _OOF_OPTIONS.learning_fractions
        if fractions is None:
            fractions = [0.2,0.4,0.6,0.8,1.0]
            for cv in ('kfold_5','groupkfold_catalyst','leave_one_paper_out'):
                path = directory / cv / 'learning_curves_all_metrics_seed42.csv'
                if path.is_file():
                    fractions = sorted(pd.read_csv(path)['train_fraction'].unique())
                    break
        generate_saved_parameter_loo_curve(directory / 'leave_one_out', target, fractions)
    else:
        print(f'Reusing saved LOO learning curves: {loo_file}', flush=True)
    return _shared.load_oof_inputs(directory, target)
