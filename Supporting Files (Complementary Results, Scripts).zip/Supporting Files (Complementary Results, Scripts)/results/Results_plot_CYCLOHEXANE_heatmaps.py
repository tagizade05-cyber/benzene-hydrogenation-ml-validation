# ================================================================
# HEATMAPS FOR MODEL / CV-STRATEGY COMPARISON — MEAN ± SD
# ================================================================

import os
from pathlib import Path
from results_plot_support import load_metric_plot_options, load_four_metric_csvs
import time
from datetime import datetime

import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# ----------------------------------------------------------------
# Input / output
# ----------------------------------------------------------------
OPTIONS = load_metric_plot_options(Path(__file__).resolve().parent, "cyclohexane")
INPUT_FILES = OPTIONS.files
INPUT_FILE = "Four per-CV CSV files"
OUT_DIR = OPTIONS.output_dir
DPI = OPTIONS.dpi
os.makedirs(OUT_DIR, exist_ok=True)

# ------------------------------------------------
# Runtime / progress logging
# ------------------------------------------------
RUN_START = time.perf_counter()

def log(message):
    elapsed = time.perf_counter() - RUN_START
    print(
        f"[{datetime.now():%Y-%m-%d %H:%M:%S}] "
        f"+{elapsed:7.2f}s | {message}",
        flush=True,
    )

def save_figure(fig, filename):
    start = time.perf_counter()
    path = os.path.join(OUT_DIR, filename)
    log(f"Saving {filename} at configured DPI...")
    fig.savefig(path, dpi=DPI, bbox_inches="tight")
    plt.close(fig)
    log(f"Saved {filename} in {time.perf_counter() - start:.2f}s")

log("Starting heatmap generation: 5 individual heatmaps + 1 merged CV/BO summary figure")
log(f"Input file: {INPUT_FILE}")
log(f"Output directory: {OUT_DIR}")

# ------------------------------------------------
# Read and clean table
# ------------------------------------------------
log("Reading the four CV metric CSVs...")
df = load_four_metric_csvs(INPUT_FILES, "cyclohexane")
log(f"Loaded {len(df)} rows x {len(df.columns)} columns")

df = df.rename(columns={
    "CV R2R^2": "CV_R2",
    "CV R2": "CV_R2",
    "CV R2 SD": "CV_R2_SD",
    "CV MAE": "CV_MAE",
    "CV MAE SD": "CV_MAE_SD",
    "CV RMSE": "CV_RMSE",
    "CV RMSE SD": "CV_RMSE_SD",
    "Cross-validation strategy": "CV_strategy",
    "Hyperparameter case": "case",
    "n seeds": "n_seeds",
})

required_columns = [
    "CV_strategy", "Model", "case",
    "CV_R2", "CV_R2_SD",
    "CV_MAE", "CV_MAE_SD",
    "CV_RMSE", "CV_RMSE_SD",
]
missing = [c for c in required_columns if c not in df.columns]
if missing:
    raise ValueError(
        "The input CSVs is missing required columns: "
        + ", ".join(missing)
    )

# ------------------------------------------------
# Short readable names
# ------------------------------------------------
cv_name_map = {
    "kfold_5": "5-Fold",
    "groupkfold_catalyst": "Catalyst Group\n5-Fold",
    "leave_one_out": "LOO",
    "leave_one_paper_out": "LOPO",
    "5-fold CV": "5-Fold",
    "5-fold GroupKFold by catalyst": "Catalyst Group\n5-Fold",
    "Leave-One-Out (LOOCV)": "LOO",
    "Leave-one-paper-out (LOPO)": "LOPO",
}
df["CV_short"] = df["CV_strategy"].replace(cv_name_map)
def round2_clean(x):
    return f"{x:.2f}".rstrip("0").rstrip(".")
def make_model_label(row):
    model = row["Model"]
    case = row["case"]

    if model == "Mean baseline":
        return "Mean baseline"

    if model == "Ordinary linear regression":
        return "Linear regression"

    if model == "XGBoost":
        if str(case).lower() == "base case":
            return "XGBoost — Base"
        if case == "BO optimized":
            return "XGBoost — BO"
        if case == "Nested BO optimized":
            return "XGBoost — Nested BO"

    if model == "GPR":
        if str(case).lower() == "base case":
            return "GPR — Base"
        if case == "BO optimized":
            return "GPR — BO"
        if case == "Nested BO optimized":
            return "GPR — Nested BO"

    return f"{model} — {case}"

df["Model_case"] = df.apply(make_model_label, axis=1)

model_order = [
    "Mean baseline",
    "Linear regression",
    "XGBoost — Base",
    "XGBoost — BO",
    "XGBoost — Nested BO",
    "GPR — Base",
    "GPR — BO",
    "GPR — Nested BO",
]

cv_order = [
    "5-Fold",
    "Catalyst Group\n5-Fold",
    "LOO",
    "LOPO",
]

# ------------------------------------------------
# Matrix / annotation helpers
# ------------------------------------------------
def metric_matrix(value_column):
    return (
        df.pivot(
            index="Model_case",
            columns="CV_short",
            values=value_column,
        )
        .reindex(index=model_order, columns=cv_order)
    )

def mean_sd_annotation(mean_matrix, sd_matrix, mean_decimals=None,
                       sd_decimals=None, show_plus=False):

    out = mean_matrix.copy().astype(object)

    for r in mean_matrix.index:
        for c in mean_matrix.columns:

            mean_val = mean_matrix.loc[r, c]
            sd_val = sd_matrix.loc[r, c]

            if pd.isna(mean_val):
                out.loc[r, c] = ""
                continue

            # Round to 2 decimal places and remove unnecessary trailing zeros
            mean_text = round2_clean(float(mean_val))

            # Add "+" sign for positive delta values when requested
            if show_plus and mean_val > 0:
                mean_text = "+" + mean_text

            # LOO: show mean only, without ± SD
            if c == "LOO" or pd.isna(sd_val):
                out.loc[r, c] = mean_text

            # All other validation strategies: mean ± SD
            else:
                sd_text = round2_clean(float(sd_val))
                out.loc[r, c] = f"{mean_text} ± {sd_text}"

    return out

# Publication-style font
plt.rcParams.update({
    "font.family": "sans-serif",
    "font.size": 17,
    "axes.titlesize": 20,
    "axes.labelsize": 18,
    "xtick.labelsize": 16,
    "ytick.labelsize": 16,
})

# ================================================================
# METRIC MATRICES
# ================================================================
r2_matrix = metric_matrix("CV_R2")
r2_sd_matrix = metric_matrix("CV_R2_SD")
mae_matrix = metric_matrix("CV_MAE")
mae_sd_matrix = metric_matrix("CV_MAE_SD")
rmse_matrix = metric_matrix("CV_RMSE")
rmse_sd_matrix = metric_matrix("CV_RMSE_SD")

# Use enough decimals that small SD values do not disappear after rounding.
r2_annot = mean_sd_annotation(r2_matrix, r2_sd_matrix, mean_decimals=3)
mae_annot = mean_sd_annotation(mae_matrix, mae_sd_matrix, mean_decimals=2)
rmse_annot = mean_sd_annotation(rmse_matrix, rmse_sd_matrix, mean_decimals=2)

# LOPO contains very negative R² values, especially OLS.
# Clip ONLY the colour scale; annotations retain the true mean ± SD.
r2_color = r2_matrix.clip(lower=-1.0, upper=1.0)

# ================================================================
# HEATMAP 1 — CV R²
# ================================================================
log("Generating Heatmap 1/5: CV R² across validation strategies")

fig, ax = plt.subplots(figsize=(15.2, 8.5))
sns.heatmap(
    r2_color,
    annot=r2_annot,
    fmt="",
    cmap="RdBu",
    center=0,
    vmin=-1,
    vmax=1,
    linewidths=1.0,
    linecolor="white",
    cbar_kws={"label": "Mean cross-validated R²\n(color scale clipped at −1)"},
    annot_kws={"fontsize": 12.5},
    ax=ax,
)

ax.set_xlabel("Cross-validation strategy")
ax.set_ylabel("")
ax.set_title("Model performance across cross-validation strategies (mean ± SD)")
ax.tick_params(axis="x", rotation=0)
ax.tick_params(axis="y", rotation=0)
fig.tight_layout()
save_figure(fig, "heatmap_CV_R2_mean_SD.png")

# ================================================================
# HEATMAP 2 — CV MAE
# ================================================================
log("Generating Heatmap 2/5: CV MAE")

fig, ax = plt.subplots(figsize=(15.2, 8.5))
sns.heatmap(
    mae_matrix,
    annot=mae_annot,
    fmt="",
    cmap="YlOrRd",
    linewidths=1.0,
    linecolor="white",
    cbar_kws={"label": "Mean cross-validated MAE (%)"},
    annot_kws={"fontsize": 12.5},
    ax=ax,
)

ax.set_title("Mean absolute error (%) across cross-validation strategies (mean ± SD)")
ax.set_xlabel("Cross-validation strategy")
ax.set_ylabel("")
ax.tick_params(axis="x", rotation=0)
ax.tick_params(axis="y", rotation=0)
fig.tight_layout()
save_figure(fig, "heatmap_CV_MAE_mean_SD.png")

# ================================================================
# HEATMAP 3 — CV RMSE
# ================================================================
log("Generating Heatmap 3/5: CV RMSE")

fig, ax = plt.subplots(figsize=(15.2, 8.5))
sns.heatmap(
    rmse_matrix,
    annot=rmse_annot,
    fmt="",
    cmap="YlOrRd",
    linewidths=1.0,
    linecolor="white",
    cbar_kws={"label": "Mean cross-validated RMSE (%)"},
    annot_kws={"fontsize": 12.5},
    ax=ax,
)

ax.set_title("Root mean squared error (%) across cross-validation strategies (mean ± SD)")
ax.set_xlabel("Cross-validation strategy")
ax.set_ylabel("")
ax.tick_params(axis="x", rotation=0)
ax.tick_params(axis="y", rotation=0)
fig.tight_layout()
save_figure(fig, "heatmap_CV_RMSE_mean_SD.png")

# ================================================================
# HEATMAP 4 — CHANGE IN MEAN CV R² CAUSED BY BO
# ================================================================
log("Generating Heatmap 4/5: BO effect on mean CV R²")

bo_rows = []

for cv in cv_order:
    temp = df[df["CV_short"] == cv]

    def fetch(model_case, value_col):
        return float(
            temp.loc[temp["Model_case"] == model_case, value_col].iloc[0]
        )

    # XGBoost
    xgb_base = fetch("XGBoost — Base", "CV_R2")
    xgb_base_sd = fetch("XGBoost — Base", "CV_R2_SD")
    xgb_bo = fetch("XGBoost — BO", "CV_R2")
    xgb_bo_sd = fetch("XGBoost — BO", "CV_R2_SD")
    xgb_nested = fetch("XGBoost — Nested BO", "CV_R2")
    xgb_nested_sd = fetch("XGBoost — Nested BO", "CV_R2_SD")

    # GPR
    gpr_base = fetch("GPR — Base", "CV_R2")
    gpr_base_sd = fetch("GPR — Base", "CV_R2_SD")
    gpr_bo = fetch("GPR — BO", "CV_R2")
    gpr_bo_sd = fetch("GPR — BO", "CV_R2_SD")
    gpr_nested = fetch("GPR — Nested BO", "CV_R2")
    gpr_nested_sd = fetch("GPR — Nested BO", "CV_R2_SD")

    # The workbook contains summary SDs only, not per-seed paired differences.
    # Therefore the SD of ΔR² is approximated by standard uncertainty propagation:
    #     SD_delta ≈ sqrt(SD_optimized² + SD_base²)
    # This is NOT the same as the exact SD of paired seed-by-seed differences.
    bo_rows.extend([
        {
            "Optimization": "XGBoost — BO",
            "CV": cv,
            "Delta_R2": xgb_bo - xgb_base,
            "Delta_R2_SD": np.sqrt(xgb_bo_sd**2 + xgb_base_sd**2),
        },
        {
            "Optimization": "XGBoost — Nested BO",
            "CV": cv,
            "Delta_R2": xgb_nested - xgb_base,
            "Delta_R2_SD": np.sqrt(xgb_nested_sd**2 + xgb_base_sd**2),
        },
        {
            "Optimization": "GPR — BO",
            "CV": cv,
            "Delta_R2": gpr_bo - gpr_base,
            "Delta_R2_SD": np.sqrt(gpr_bo_sd**2 + gpr_base_sd**2),
        },
        {
            "Optimization": "GPR — Nested BO",
            "CV": cv,
            "Delta_R2": gpr_nested - gpr_base,
            "Delta_R2_SD": np.sqrt(gpr_nested_sd**2 + gpr_base_sd**2),
        },
    ])

bo_effect_df = pd.DataFrame(bo_rows)

bo_order = [
    "XGBoost — BO",
    "XGBoost — Nested BO",
    "GPR — BO",
    "GPR — Nested BO",
]

bo_matrix = (
    bo_effect_df.pivot(index="Optimization", columns="CV", values="Delta_R2")
    .reindex(index=bo_order, columns=cv_order)
)

bo_sd_matrix = (
    bo_effect_df.pivot(index="Optimization", columns="CV", values="Delta_R2_SD")
    .reindex(index=bo_order, columns=cv_order)
)

bo_annot = mean_sd_annotation(
    bo_matrix, bo_sd_matrix,
    mean_decimals=3, sd_decimals=3,
    show_plus=True
)

fig, ax = plt.subplots(figsize=(15.2, 6.2))
sns.heatmap(
    bo_matrix,
    annot=bo_annot,
    fmt="",
    cmap="RdBu",
    center=0,
    vmin=-1,
    vmax=1,
    linewidths=1.0,
    linecolor="white",
    cbar_kws={"label": "Δ mean CV R² relative to base XGBoost/GPR"},
    annot_kws={"fontsize": 12.5},
    ax=ax,
)

ax.set_xlabel("Cross-validation strategy")
ax.set_ylabel("")
ax.set_title("Effect of Bayesian optimization on predictive performance (Δ mean ± propagated SD)")
ax.tick_params(axis="x", rotation=0)
ax.tick_params(axis="y", rotation=0)
fig.tight_layout()
save_figure(fig, "heatmap_BO_effect_on_R2_mean_SD.png")

# ================================================================
# HEATMAP 5 — NON-NESTED BO vs NESTED BO MEAN CV R² DIFFERENCE
# ================================================================
log("Generating Heatmap 5/5: Non-nested BO vs nested BO mean CV R² difference")

# Per user request, this panel reflects ONLY the difference in mean CV R².
# No SD is added to this comparison.
bo_nested_rows = []

for cv in cv_order:
    temp = df[df["CV_short"] == cv]

    xgb_bo = float(temp.loc[temp["Model_case"] == "XGBoost — BO", "CV_R2"].iloc[0])
    xgb_nested = float(temp.loc[temp["Model_case"] == "XGBoost — Nested BO", "CV_R2"].iloc[0])

    gpr_bo = float(temp.loc[temp["Model_case"] == "GPR — BO", "CV_R2"].iloc[0])
    gpr_nested = float(temp.loc[temp["Model_case"] == "GPR — Nested BO", "CV_R2"].iloc[0])

    bo_nested_rows.extend([
        {"Model": "XGBoost", "CV": cv, "Delta_R2": xgb_bo - xgb_nested},
        {"Model": "GPR", "CV": cv, "Delta_R2": gpr_bo - gpr_nested},
    ])

bo_nested_df = pd.DataFrame(bo_nested_rows)

bo_nested_matrix = (
    bo_nested_df.pivot(index="Model", columns="CV", values="Delta_R2")
    .reindex(index=["XGBoost", "GPR"], columns=cv_order)
)

bo_nested_color = bo_nested_matrix.clip(lower=-1.0, upper=1.0)

fig, ax = plt.subplots(figsize=(13.5, 4.8))
sns.heatmap(
    bo_nested_color,
    annot=bo_nested_matrix,
    fmt="+.3f",
    cmap="RdBu",
    center=0,
    vmin=-1,
    vmax=1,
    linewidths=1.0,
    linecolor="white",
    cbar_kws={
        "label": "Δ mean CV R² = non-nested BO − nested BO\n(color scale clipped at ±1)"
    },
    annot_kws={"fontsize": 15},
    ax=ax,
)

ax.set_xlabel("Cross-validation strategy")
ax.set_ylabel("")
ax.set_title("Difference between non-nested and nested Bayesian optimization")
ax.tick_params(axis="x", rotation=0)
ax.tick_params(axis="y", rotation=0)
fig.tight_layout()
save_figure(fig, "heatmap_non_nested_minus_nested_BO_R2_mean.png")

# ================================================================
# MERGED MANUSCRIPT FIGURE
# Top row: mean ± SD for CV R² | CV MAE | CV RMSE
# Bottom row: BO effect vs base (mean ± propagated SD)
#             | non-nested BO − nested BO (difference in means only)
# ================================================================
log("Generating merged performance summary figure")

fig = plt.figure(figsize=(35, 16.5))
gs = fig.add_gridspec(
    nrows=2,
    ncols=6,
    height_ratios=[1.05, 0.78],
    wspace=1.05,
    hspace=0.25,
)

ax_a = fig.add_subplot(gs[0, 0:2])
ax_b = fig.add_subplot(gs[0, 2:4])
ax_c = fig.add_subplot(gs[0, 4:6])
ax_d = fig.add_subplot(gs[1, 0:3])
ax_e = fig.add_subplot(gs[1, 3:6])

# (a) CV R²
sns.heatmap(
    r2_color,
    annot=r2_annot,
    fmt="",
    cmap="RdBu",
    center=0,
    vmin=-1.2,
    vmax=1.2,
    linewidths=1.0,
    linecolor="white",
    cbar_kws={"label": "Mean CV R²", "shrink": 0.82, "pad": 0.05},
    annot_kws={"fontsize": 16.5},
    ax=ax_a,
)
ax_a.collections[0].colorbar.ax.tick_params(labelsize=14)
ax_a.collections[0].colorbar.set_label("Mean CV R²", fontsize=16)
ax_a.set_title("(a) Cross-validated R² (mean ± SD)", fontsize=18, fontweight="bold", pad=12)
ax_a.set_xlabel("\nCross-validation strategy", fontsize=15)
ax_a.set_ylabel("")
ax_a.tick_params(axis="x", rotation=0, labelsize=16)
ax_a.tick_params(axis="y", rotation=0, labelsize=16)

# (b) CV MAE
sns.heatmap(
    mae_matrix,
    annot=mae_annot,
    fmt="",
    cmap="YlOrRd",
    linewidths=1.0,
    vmin=0,
    vmax=20,
    linecolor="white",
    cbar_kws={"label": "Mean CV MAE (%)", "shrink": 0.82, "pad": 0.05},
    annot_kws={"fontsize": 16.5},
    ax=ax_b,
)
ax_b.collections[0].colorbar.ax.tick_params(labelsize=14)
ax_b.collections[0].colorbar.set_label("Mean CV MAE (%)", fontsize=16)
ax_b.set_title("(b) Cross-validated MAE (%) (mean ± SD)", fontsize=18, fontweight="bold", pad=12)
ax_b.set_xlabel("\nCross-validation strategy", fontsize=15)
ax_b.set_ylabel("")
ax_b.tick_params(axis="x", rotation=0, labelsize=16)
ax_b.tick_params(axis="y", rotation=0, labelsize=16)

# (c) CV RMSE
sns.heatmap(
    rmse_matrix,
    annot=rmse_annot,
    fmt="",
    cmap="YlOrRd",
    linewidths=1.0,
    linecolor="white",
    vmin=0,
    vmax=20,
    cbar_kws={"label": "Mean CV RMSE (%)", "shrink": 0.82, "pad": 0.05},
    annot_kws={"fontsize": 16.5},
    ax=ax_c,
)
ax_c.collections[0].colorbar.ax.tick_params(labelsize=14)
ax_c.collections[0].colorbar.set_label("Mean CV RMSE (%)", fontsize=16)
ax_c.set_title("(c) Cross-validated RMSE (%) (mean ± SD)", fontsize=18, fontweight="bold", pad=12)
ax_c.set_xlabel("\nCross-validation strategy", fontsize=15)
ax_c.set_ylabel("")
ax_c.tick_params(axis="x", rotation=0, labelsize=16)
ax_c.tick_params(axis="y", rotation=0, labelsize=16)

# (d) BO effect relative to base
sns.heatmap(
    bo_matrix,
    annot=True,
    fmt="+.3f",
    cmap="RdBu",
    center=0,
    vmin=-0.6,
    vmax=0.6,
    linewidths=1.0,
    linecolor="white",
    cbar_kws={"label": "Optimized − Base model mean CV R²", "shrink": 0.82, "pad": 0.04},
    annot_kws={"fontsize": 17},
    ax=ax_d,
)
ax_d.collections[0].colorbar.ax.tick_params(labelsize=14)
ax_d.collections[0].colorbar.set_label("Optimized − Base model mean CV R²", fontsize=16)
ax_d.set_title("(d) Effect of Bayesian optimization", fontsize=18, fontweight="bold", pad=12)
ax_d.set_xlabel("\nCross-validation strategy", fontsize=15)
ax_d.set_ylabel("")
ax_d.tick_params(axis="x", rotation=0, labelsize=16)
ax_d.tick_params(axis="y", rotation=0, labelsize=16)

# (e) Non-nested BO minus nested BO — MEAN DIFFERENCE ONLY
sns.heatmap(
    bo_nested_matrix,
    annot=True,
    fmt="+.3f",
    cmap="RdBu",
    center=0,
    vmin=-0.6,
    vmax=0.6,
    linewidths=1.0,
    linecolor="white",
    cbar_kws={"label": "Non-nested − Nested mean CV R²", "shrink": 0.82, "pad": 0.04},
    annot_kws={"fontsize": 17},
    ax=ax_e,
)
ax_e.collections[0].colorbar.ax.tick_params(labelsize=14)
ax_e.collections[0].colorbar.set_label("Non-nested − Nested CV R²", fontsize=16)
ax_e.set_title("(e) Non-nested vs nested BO", fontsize=18, fontweight="bold", pad=12)
ax_e.set_xlabel("\nCross-validation strategy", fontsize=15)
ax_e.set_ylabel("")
ax_e.tick_params(axis="x", rotation=0, labelsize=16)
ax_e.tick_params(axis="y", rotation=0, labelsize=16)

fig.suptitle(
    "Cyclohexane yield\n"
    "Cross-validated model performance and Bayesian optimization effects",
    fontsize=27,
    fontweight="bold",
    y=0.985,
)

fig.subplots_adjust(
    left=0.07,
    right=0.965,
    top=0.90,
    bottom=0.08,
)

save_figure(fig, "heatmap_MERGED_performance_summary_mean_SD.png")

print("\nNon-nested BO − Nested BO mean CV R²:")
print(bo_nested_matrix)

print(
    "\nNOTE: Panels (a)–(c) show mean ± sample SD across five complete pipeline runs for 5-Fold, Catalyst Group and LOPO. LOO uses seed 42 without SD. "
    "Panel (d) shows Δ mean CV R² ± an approximate propagated SD calculated as "
    "sqrt(SD_optimized^2 + SD_base^2), because the four summary CSVs does not contain "
    "the paired seed-by-seed differences. Panel (e) uses the difference in mean values only."
)

log("All figures completed.")


# ================================================================
# ADDITIONAL FIGURE MATCHING THE SUPPLIED REFERENCE
# R² | MAE | RMSE; original five-panel numerical fonts and styling.
# All original code above remains unchanged.
# ================================================================
def save_reference_horizontal_cv_metrics():
    log("Generating reference-style horizontal R² / MAE / RMSE figure")

    # Wide canvas matches the supplied reference. The previous 8.5 cm
    # width restriction has been replaced by the requested reference layout.
    fig = plt.figure(figsize=(35, 10))
    gs = fig.add_gridspec(nrows=1, ncols=6, wspace=1.05)
    ax_a = fig.add_subplot(gs[0, 0:2])
    ax_b = fig.add_subplot(gs[0, 2:4])
    ax_c = fig.add_subplot(gs[0, 4:6])

    # (a) CV R²
    sns.heatmap(
        r2_color,
        annot=r2_annot,
        fmt="",
        cmap="RdBu",
        center=0,
        vmin=-1.2,
        vmax=1.2,
        linewidths=1.0,
        linecolor="white",
        cbar_kws={"label": "Mean CV R²", "shrink": 0.82, "pad": 0.05},
        annot_kws={"fontsize": 17.5},
        ax=ax_a,
    )
    ax_a.collections[0].colorbar.ax.tick_params(labelsize=14)
    ax_a.collections[0].colorbar.set_label("Mean R²", fontsize=17)
    ax_a.set_title("(a) Cross-validated R² (mean ± SD)", fontsize=18, fontweight="bold", pad=12)
    ax_a.set_xlabel("\nCross-validation strategy", fontsize=17)
    ax_a.set_ylabel("")
    ax_a.tick_params(axis="x", rotation=0, labelsize=17)
    ax_a.tick_params(axis="y", rotation=0, labelsize=17)

    # (b) CV MAE
    sns.heatmap(
        mae_matrix,
        annot=mae_annot,
        fmt="",
        cmap="YlOrRd",
        linewidths=1.0,
        vmin=0,
        vmax=20,
        linecolor="white",
        cbar_kws={"label": "Mean CV MAE (%)", "shrink": 0.82, "pad": 0.05},
        annot_kws={"fontsize": 17.5},
        ax=ax_b,
    )
    ax_b.collections[0].colorbar.ax.tick_params(labelsize=14)
    ax_b.collections[0].colorbar.set_label("Mean MAE (%)", fontsize=17)
    ax_b.set_title("(b) Cross-validated MAE (%) (mean ± SD)", fontsize=18, fontweight="bold", pad=12)
    ax_b.set_xlabel("\nCross-validation strategy", fontsize=17)
    ax_b.set_ylabel("")
    ax_b.tick_params(axis="x", rotation=0, labelsize=17)
    ax_b.tick_params(axis="y", rotation=0, labelsize=17)

    # (c) CV RMSE
    sns.heatmap(
        rmse_matrix,
        annot=rmse_annot,
        fmt="",
        cmap="YlOrRd",
        linewidths=1.0,
        linecolor="white",
        vmin=0,
        vmax=20,
        cbar_kws={"label": "Mean CV RMSE (%)", "shrink": 0.82, "pad": 0.05},
        annot_kws={"fontsize": 17.5},
        ax=ax_c,
    )
    ax_c.collections[0].colorbar.ax.tick_params(labelsize=14)
    ax_c.collections[0].colorbar.set_label("Mean RMSE (%)", fontsize=17)
    ax_c.set_title("(c) Cross-validated RMSE (%) (mean ± SD)", fontsize=18, fontweight="bold", pad=12)
    ax_c.set_xlabel("\nCross-validation strategy", fontsize=17)
    ax_c.set_ylabel("")
    ax_c.tick_params(axis="x", rotation=0, labelsize=17)
    ax_c.tick_params(axis="y", rotation=0, labelsize=17)

    

    fig.subplots_adjust(
        left=0.07,
        right=0.965,
        top=0.90,
        bottom=0.11,
    )

    # New filenames preserve all existing individual and five-panel figures.
    basename = "heatmap_HORIZONTAL_R2_MAE_RMSE_reference_mean_SD"
    for extension in ("png", "pdf"):
        path = os.path.join(OUT_DIR, basename + "." + extension)
        log(f"Saving {os.path.basename(path)}...")
        fig.savefig(path, dpi=DPI, bbox_inches="tight", facecolor="white")
        log(f"Saved {path}")
    plt.close(fig)


save_reference_horizontal_cv_metrics()
log("Reference-style horizontal figure completed.")
