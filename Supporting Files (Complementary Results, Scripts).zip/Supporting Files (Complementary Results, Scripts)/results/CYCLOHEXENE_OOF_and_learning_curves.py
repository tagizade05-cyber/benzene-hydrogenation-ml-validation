from pathlib import Path
from results_plot_support import load_oof_plot_options, load_oof_inputs

import numpy as np
import pandas as pd

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


# ============================================================
# CYCLOHEXENE — PLOT-ONLY SCRIPT
#
# Reads previously generated seed-42 CSV outputs.
# Existing curves are reused. Missing LOO curves use saved fold parameters.
# No Bayesian optimization or full model-evaluation reruns are performed.
#
# Outputs:
#   1) 8-panel figure:
#      top row    = saved OOF vs Actual plots
#      bottom row = RMSE learning curves, displayed with y-axis capped at 40
#
#   2) uncapped RMSE learning curves
#   3) R² learning curves capped at -2 to +2
#   4) uncapped R² learning curves
#   5) uncapped MAE learning curves
# ============================================================


# -----------------------
# File locations
# -----------------------
# By default, place this script in the same folder as the CSV files.
# If your CSVs are elsewhere, change DATA_DIR only.
OPTIONS = load_oof_plot_options(Path(__file__).resolve().parent, "cyclohexene")
DATA_DIR = OPTIONS.data_dir
OUT_DIR = OPTIONS.output_dir
OUT_DIR.mkdir(parents=True, exist_ok=True)

VALIDATION_ORDER = [
    ("leave_one_out", "Leave One Out", "Leave One Out"),
    ("kfold_5", "5-Fold", "5-Fold"),
    ("leave_one_paper_out", "Leave One Paper Out ", "Leave One Paper Out"),
    ("groupkfold_catalyst", "5-Fold Group by Catalyst", "5-Fold Group by Catalyst"),
]

ACTUAL_COL = "actual_Cyclohexene_yield_%"
PREDICTION_COLS = {
    "XGBoost nested BO": "xgboost_nested_bo_oof_pred_%",
    "GPR nested BO": "gpr_nested_bo_oof_pred_%",
    "Ordinary linear regression": "ordinary_linear_regression_oof_pred_%",
}

MODEL_ORDER = [
    "XGBoost nested BO",
    "GPR nested BO",
    "Ordinary linear regression",
]

# Use Matplotlib's default color cycle rather than hard-coded colors.
_default_colors = plt.rcParams["axes.prop_cycle"].by_key()["color"]
MODEL_COLORS = {
    model: _default_colors[i % len(_default_colors)]
    for i, model in enumerate(MODEL_ORDER)
}


# -----------------------
# Load saved results
# -----------------------
def require_file(path):
    if not path.exists():
        raise FileNotFoundError(
            f"Required file not found:\n{path}\n\n"
            "Place this script in the same folder as the saved CSV files, "
            "or change DATA_DIR at the top of the script."
        )


prediction_dfs, learning_df = load_oof_inputs(DATA_DIR, "cyclohexene")



# -----------------------
# Validate required columns
# -----------------------
required_learning_cols = {
    "cv_strategy",
    "model",
    "train_fraction",
    "mean_outer_train_rows_used",
    "train_R2",
    "train_MAE",
    "train_RMSE",
    "validation_R2",
    "validation_MAE",
    "validation_RMSE",
}
missing_learning = required_learning_cols.difference(learning_df.columns)
if missing_learning:
    raise ValueError(
        "Learning-curve CSV is missing required columns: "
        + ", ".join(sorted(missing_learning))
    )

for strategy, df in prediction_dfs.items():
    required = {ACTUAL_COL, *PREDICTION_COLS.values()}
    missing = required.difference(df.columns)
    if missing:
        raise ValueError(
            f"{strategy} prediction CSV is missing required columns: "
            + ", ".join(sorted(missing))
        )


# -----------------------
# Plot helpers
# -----------------------
def plot_oof_overlay(ax, df, title, show_ylabel=True):
    actual = df[ACTUAL_COL].to_numpy(dtype=float)
    preds = {
        model: df[col].to_numpy(dtype=float)
        for model, col in PREDICTION_COLS.items()
    }

    all_vals = np.concatenate(
        [actual] + [preds[m] for m in MODEL_ORDER]
    )
    finite = all_vals[np.isfinite(all_vals)]

    if finite.size:
        lo = float(np.min(finite))
        hi = float(np.max(finite))
    else:
        lo, hi = 0.0, 1.0

    pad = 0.05 * (hi - lo) if hi > lo else 1.0
    lo -= pad
    hi += pad

    for model in MODEL_ORDER:
        ax.scatter(
            actual,
            preds[model],
            s=24,
            alpha=0.78,
            edgecolor="black",
            linewidth=0.35,
            color=MODEL_COLORS[model],
            label=model,
        )

    ax.plot(
        [lo, hi],
        [lo, hi],
        linestyle="--",
        linewidth=1.0,
        color="black",
    )

    ax.set_xlim(lo, hi)
    ax.set_ylim(lo, hi)
    ax.set_title(title, fontsize=16)
    ax.set_xlabel("Actual cyclohexene yield (%)", fontsize=16)
    if show_ylabel:
        ax.set_ylabel("OOF predicted cyclohexene yield (%)", fontsize=16)
    ax.tick_params(axis="both", labelsize=13)
    ax.grid(True, alpha=0.18)


def plot_learning_metric(
    ax,
    lc_subset,
    metric,
    title,
    show_ylabel=True,
    ylim=None,
):
    for model in MODEL_ORDER:
        d = (
            lc_subset.loc[lc_subset["model"] == model]
            .sort_values("train_fraction")
        )

        if d.empty:
            continue

        x = d["mean_outer_train_rows_used"].to_numpy(dtype=float)
        y_valid = d[f"validation_{metric}"].to_numpy(dtype=float)
        y_train = d[f"train_{metric}"].to_numpy(dtype=float)

        ax.plot(
            x,
            y_valid,
            marker="o",
            linewidth=1.7,
            markersize=4.5,
            color=MODEL_COLORS[model],
            label=f"{model} — validation",
        )
        ax.plot(
            x,
            y_train,
            marker="o",
            linewidth=1.2,
            markersize=3.8,
            linestyle="--",
            alpha=0.72,
            color=MODEL_COLORS[model],
            label=f"{model} — training",
        )

    ax.set_title(title, fontsize=14)
    ax.set_xlabel("Mean outer-training samples used", fontsize=11)

    if show_ylabel:
        pretty = {
            "R2": "R²",
            "MAE": "MAE (%)",
            "RMSE": "RMSE (%)",
        }[metric]
        ax.set_ylabel(pretty, fontsize=13)

    if ylim is not None:
        ax.set_ylim(*ylim)

    ax.tick_params(axis="both", labelsize=13)
    ax.grid(True, alpha=0.20)


def make_four_panel_learning_figure(
    metric,
    filename,
    suptitle,
    ylim=None,
):
    fig, axes = plt.subplots(
        1,
        4,
        figsize=(23, 5.8),
        sharey=False,
    )

    for col_idx, (strategy, display_title, short_title) in enumerate(
        VALIDATION_ORDER
    ):
        subset = learning_df.loc[
            learning_df["cv_strategy"] == strategy
        ]

        plot_learning_metric(
            axes[col_idx],
            subset,
            metric,
            f"({chr(97 + col_idx)}) {display_title}",
            show_ylabel=(col_idx == 0),
            ylim=ylim,
        )

    handles, labels = axes[0].get_legend_handles_labels()

    fig.legend(
        handles,
        labels,
        loc="lower center",
        bbox_to_anchor=(0.5, -0.02),
        ncol=3,
        frameon=True,
        fontsize=14,
    )

    fig.suptitle(
        suptitle,
        fontsize=16,
        fontweight="bold",
    )

    fig.tight_layout(
        rect=[0.01, 0.10, 0.995, 0.92],
        w_pad=2.0,
    )

    
    fig.savefig(
        OUT_DIR / filename,
        dpi=300,
        bbox_inches="tight",
    )
    plt.close(fig)




def make_sixteen_panel_supporting_figure():
    """Create a combined 16-panel supporting-information figure with:
    row 1 = uncapped R²,
    row 2 = capped R²,
    row 3 = MAE (%),
    row 4 = uncapped RMSE (%).
    """
    fig, axes = plt.subplots(4, 4, figsize=(24, 20), constrained_layout=False)

    row_specs = [
        ("R2", None, "R² learning curve"),
        ("R2", (-2, 2), "R² learning curve (capped)"),
        ("MAE", None, "MAE learning curve"),
        ("RMSE", None, "RMSE learning curve"),
    ]

    panel_idx = 0
    for row_idx, (metric, ylim, row_title) in enumerate(row_specs):
        for col_idx, (strategy, display_title, short_title) in enumerate(VALIDATION_ORDER):
            subset = learning_df.loc[learning_df["cv_strategy"] == strategy]
            letter = chr(97 + panel_idx)
            plot_learning_metric(
                axes[row_idx, col_idx],
                subset,
                metric,
                f"({letter}) {short_title} — {row_title}",
                show_ylabel=(col_idx == 0),
                ylim=ylim,
            )
            panel_idx += 1

    handles, labels = axes[0, 0].get_legend_handles_labels()
    fig.legend(
        handles,
        labels,
        loc="lower center",
        bbox_to_anchor=(0.5, 0.02),
        ncol=3,
        frameon=True,
        fontsize=13,
    )

    fig.suptitle(
        "Cyclohexene yield (%) — Combined supporting-information learning curves (seed 42)",
        fontsize=16,
        y=0.995,
        fontweight="bold",
    )

    fig.tight_layout(
        rect=[0.02, 0.07, 0.995, 0.965],
        h_pad=2.2,
        w_pad=1.8,
    )

   
    fig.savefig(
        OUT_DIR / "06_supporting_combined_16panel_learning_curves.png",
        dpi=300,
        bbox_inches="tight",
    )
    plt.close(fig)


# ============================================================
# 1) MAIN 8-PANEL FIGURE
#    Top: saved OOF predictions
#    Bottom: RMSE learning curves capped at 40
# ============================================================
fig, axes = plt.subplots(
    2,
    4,
    figsize=(23, 11),
    constrained_layout=False,
)

for col_idx, (strategy, display_title, short_title) in enumerate(
    VALIDATION_ORDER
):
    # Top row: saved OOF predictions
    plot_oof_overlay(
    axes[0, col_idx],
    prediction_dfs[strategy],
    f"({chr(97 + col_idx)}) {display_title}",
    show_ylabel=(col_idx == 0),
)
    # Bottom row: saved RMSE learning curves
    lc_subset = learning_df.loc[
        learning_df["cv_strategy"] == strategy
    ]

    plot_learning_metric(
        axes[1, col_idx],
        lc_subset,
        "RMSE",
        f"({chr(101 + col_idx)}) {short_title} — learning curve",
        show_ylabel=(col_idx == 0),
        ylim=(0, 10),   # requested zoom/cap for the 8-panel figure
    )

# OOF-row legend
oof_handles, oof_labels = axes[0, 0].get_legend_handles_labels()
fig.legend(
    oof_handles,
    oof_labels,
    loc="upper center",
    bbox_to_anchor=(0.5, 0.965),
    ncol=3,
    frameon=True,
    fontsize=14,
)

# Learning-curve-row legend
lc_handles, lc_labels = axes[1, 0].get_legend_handles_labels()
fig.legend(
    lc_handles,
    lc_labels,
    loc="lower center",
    bbox_to_anchor=(0.5, 0.005),
    ncol=3,
    frameon=True,
    fontsize=15,
)

fig.suptitle(
    "Cyclohexene yield (%) — OOF vs Actual and RMSE learning curves (Random seed = 42)",
    fontsize=16,
    y=0.995,
    fontweight="bold",
)

fig.tight_layout(
    rect=[0.02, 0.07, 0.995, 0.94],
    h_pad=3.0,
    w_pad=2.0,
)


fig.savefig(
    OUT_DIR / "01_8panel_OOF_and_RMSE_learning_curves_RMSE_cap10.png",
    dpi=300,
    bbox_inches="tight",
)
plt.close(fig)


# ============================================================
# 2) UNCAPPED RMSE LEARNING CURVES
# ============================================================
make_four_panel_learning_figure(
    metric="RMSE",
    filename="02_learning_curves_RMSE_uncapped.png",
    suptitle="Cyclohexene yield — RMSE learning curves, uncapped (seed 42)",
    ylim=None,
)


# ============================================================
# 3) R² LEARNING CURVES CAPPED AT -2 TO +2
# ============================================================
make_four_panel_learning_figure(
    metric="R2",
    filename="03_learning_curves_R2_capped_minus2_plus2.png",
    suptitle="Cyclohexene yield — R² learning curves, displayed from −2 to +2 (seed 42)",
    ylim=(-2, 2),
)


# ============================================================
# 4) UNCAPPED R² LEARNING CURVES
# ============================================================
make_four_panel_learning_figure(
    metric="R2",
    filename="04_learning_curves_R2_uncapped.png",
    suptitle="Cyclohexene yield — R² learning curves, uncapped (seed 42)",
    ylim=None,
)


# ============================================================
# 5) UNCAPPED MAE LEARNING CURVES
# ============================================================
make_four_panel_learning_figure(
    metric="MAE",
    filename="05_learning_curves_MAE_uncapped.png",
    suptitle="Cyclohexene yield — MAE learning curves, uncapped (seed 42)",
    ylim=None,
)




# ============================================================
# 6) COMBINED 16-PANEL SUPPORTING FIGURE
#    uncapped R², capped R², MAE, and uncapped RMSE
# ============================================================
make_sixteen_panel_supporting_figure()


print("\nPlotting complete. No Bayesian optimization was run.")
print(f"Figures saved to:\n{OUT_DIR}")
print("\nGenerated files:")
for p in sorted(OUT_DIR.glob("*.png")):
    print(" -", p.name)
