"""Estimator definitions copied from the training workflow; no model evaluation on import."""
import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator, RegressorMixin
from sklearn.preprocessing import StandardScaler
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import ConstantKernel, RBF, Matern, WhiteKernel
from sklearn.linear_model import LinearRegression

class TunableGPR(BaseEstimator, RegressorMixin):
    """Standardized Gaussian Process Regression with BO-tunable kernel parameters."""

    def __init__(
        self,
        kernel_name="RBF",
        length_scale=2.0,
        constant_value=1.0,
        noise_level=0.20,
        alpha=1e-3,
        normalize_y=True,
        random_state=42,
    ):
        self.kernel_name = kernel_name
        self.length_scale = length_scale
        self.constant_value = constant_value
        self.noise_level = noise_level
        self.alpha = alpha
        self.normalize_y = normalize_y
        self.random_state = random_state

    def fit(self, X, y):
        X_df = pd.DataFrame(X).copy()
        self.feature_names_in_ = list(X_df.columns)
        y_arr = np.asarray(y, dtype=float)

        self.scaler_ = StandardScaler()
        X_scaled = self.scaler_.fit_transform(X_df)

        kernel_key = str(self.kernel_name).upper().strip()
        if kernel_key == "RBF":
            base_kernel = RBF(length_scale=float(self.length_scale), length_scale_bounds="fixed")
        elif kernel_key in {"MATERN_1.5", "MATERN15", "MATERN_15"}:
            base_kernel = Matern(length_scale=float(self.length_scale), length_scale_bounds="fixed", nu=1.5)
        elif kernel_key in {"MATERN_2.5", "MATERN25", "MATERN_25"}:
            base_kernel = Matern(length_scale=float(self.length_scale), length_scale_bounds="fixed", nu=2.5)
        else:
            raise ValueError("GPR kernel_name must be one of: RBF, MATERN_1.5, MATERN_2.5")

        kernel = ConstantKernel(float(self.constant_value), constant_value_bounds="fixed") * base_kernel + WhiteKernel(
            noise_level=float(self.noise_level), noise_level_bounds="fixed"
        )

        self.model_ = GaussianProcessRegressor(
            kernel=kernel,
            alpha=float(self.alpha),
            optimizer=None,
            normalize_y=self.normalize_y,
            random_state=self.random_state,
        )
        self.model_.fit(X_scaled, y_arr)
        self.kernel_ = self.model_.kernel_
        return self

    def predict(self, X):
        X_df = pd.DataFrame(X).copy()
        X_scaled = self.scaler_.transform(X_df)
        return self.model_.predict(X_scaled)

class OrdinaryLinearRegressor(BaseEstimator, RegressorMixin):
    """Conventional multiple linear regression (ordinary least squares) for ML comparison.

    The model is fit on standardized original descriptors. No L1/L2 penalty, no
    coefficient thresholding, and no Bayesian optimisation are applied. This gives
    a traditional linear baseline against XGBoost and GPR.
    """

    def __init__(self):
        pass

    def fit(self, X, y):
        X_df = pd.DataFrame(X).copy()
        self.feature_names_in_ = list(X_df.columns)
        y_arr = np.asarray(y, dtype=float)

        self.scaler_ = StandardScaler()
        X_scaled = self.scaler_.fit_transform(X_df)

        self.model_ = LinearRegression()
        self.model_.fit(X_scaled, y_arr)
        self.coef_scaled_ = np.asarray(self.model_.coef_, dtype=float)
        self.intercept_ = float(self.model_.intercept_)
        return self

    def predict(self, X):
        X_df = pd.DataFrame(X).copy()
        X_scaled = self.scaler_.transform(X_df)
        return self.model_.predict(X_scaled)
