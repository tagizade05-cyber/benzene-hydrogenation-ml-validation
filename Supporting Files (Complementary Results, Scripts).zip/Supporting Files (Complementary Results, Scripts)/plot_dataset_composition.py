
from pathlib import Path
import argparse

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch

SUPPORTS = {
    'Is_NY6': 'Nylon-6 (NY6)', 'Is_P4NR': 'P4NR', 'Is_Carbon': 'Carbon',
    'Is_PVP_clinopti': 'PVP-Clinoptilolite',
    'Is_unsupported_metal': 'Unsupported (Powder/Nano-clusters)',
    'Is_CS-N-n-Propyl-Membrane': 'N-n-propyl chitosan membrane',
    'Is_PAN': 'Polyacrylonitrile (PAN)', 'Is_PAAO': 'Polyacrylamideoxime (PAAO)',
    'Is_PFT': 'Poly-p-phenyleneterephthalamide (PFT)', 'Is_PAA': 'Polyacrylamide (PAA)',
    'Is_NY3': 'Nylon-3 (NY3)', 'Is_M4KR': 'M4KR', 'Is_S4NR': 'S4NR', 'Is_S8NR': 'S8NR',
}
TARGETS = ('Cyclohexane_yield_%', 'Cyclohexene_yield_%')


def plot_dataset_composition(df, output_dir):
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    missing = set(TARGETS).difference(df.columns)
    if missing:
        raise ValueError(f'Dataset composition: missing target columns {missing}.')
    if 'Is_unsupported_metal' not in df:
        raise ValueError('Dataset composition requires the updated Is_unsupported_metal descriptor.')
    active = [c for c in SUPPORTS if c in df and pd.to_numeric(df[c], errors='coerce').ge(.5).any()]
    if not active:
        raise ValueError('No active support descriptors found.')
    masks = {c: pd.to_numeric(df[c], errors='coerce').ge(.5) for c in active}
    counts = {c: int(masks[c].sum()) for c in active}
    colors = {c: plt.get_cmap('tab20')(i) for i, c in enumerate(active)}
    fig = plt.figure(figsize=(17, 11))
    grid = fig.add_gridspec(2, 2, height_ratios=(1, 1.05), hspace=.34, wspace=.30)
    ax_a, ax_b = fig.add_subplot(grid[0, 0]), fig.add_subplot(grid[0, 1])
    small = grid[1, 0].subgridspec(2, 1, hspace=.10)
    ax_c1, ax_c2 = fig.add_subplot(small[0]), fig.add_subplot(small[1])
    ax_d = fig.add_subplot(grid[1, 1])
    histogram_rows, summary_rows = [], []
    for ax, target, step, panel in ((ax_a, TARGETS[0], 5, '(a)'), (ax_b, TARGETS[1], 2, '(b)')):
        values = pd.to_numeric(df[target], errors='coerce')
        if (values.dropna() < 0).any():
            raise ValueError(f'{target} contains negative yields; review before plotting.')
        upper = max(step, np.ceil(values.max() / step) * step)
        edges = np.arange(0., upper + step * .5, step)
        labels = [f'{a:g}–{b:g}' for a, b in zip(edges[:-1], edges[1:])]
        bottom = np.zeros(len(labels))
        for c in active:
            # Right-closed bins match the original reference, including zero in the first bin.
            bins = pd.cut(values[masks[c]], edges, include_lowest=True, right=True)
            n = bins.value_counts(sort=False).to_numpy()
            ax.bar(np.arange(len(labels)), n, bottom=bottom, width=.78, color=colors[c],
                   edgecolor='#555555', linewidth=.35)
            bottom += n
            histogram_rows.extend({'target': target, 'yield_range': label, 'support': SUPPORTS[c], 'count': int(count)}
                                  for label, count in zip(labels, n))
        name = target.split('_')[0]
        ax.set(xticks=np.arange(len(labels)), xticklabels=labels,
               xlabel=f'{name} yield (%)', ylabel='Number of support occurrences',
               title=f'{name} yield distribution')
        ax.tick_params(axis='x', rotation=35)
        ax.text(-.10, 1.04, panel, transform=ax.transAxes, weight='bold', fontsize=13)
    for ax, target in ((ax_c1, TARGETS[0]), (ax_c2, TARGETS[1])):
        mean, sd = [], []
        for c in active:
            values = pd.to_numeric(df.loc[masks[c], target], errors='coerce').dropna()
            mean.append(values.mean())
            sd.append(values.std(ddof=1) if len(values) > 1 else 0.)
            summary_rows.append({'target': target, 'support': SUPPORTS[c], 'n': len(values),
                                 'mean_yield': values.mean(), 'sample_SD': values.std(ddof=1)})
        ax.bar(np.arange(len(active)), mean, yerr=sd, capsize=3, color=[colors[c] for c in active],
               edgecolor='#555555', linewidth=.6, error_kw={'elinewidth': .8})
        ax.set(xticks=[], ylabel=f'Mean {target.split("_")[0].lower()}\nyield (%)')
    ax_c1.set_title('Mean yield by catalyst support')
    ax_c1.text(-.10, 1.04, '(c)', transform=ax_c1.transAxes, weight='bold', fontsize=13)
    paper_col = next((c for c in ('Author', 'Reference', 'Source_study', 'Paper') if c in df), None)
    if paper_col is None:
        raise ValueError('No study label column found for the study distribution panel.')
    paper = df[paper_col].fillna('Unspecified study').astype(str)
    studies = paper.value_counts().index.tolist()
    left = np.zeros(len(studies))
    study_rows = []
    for c in active:
        n = np.array([int((masks[c] & paper.eq(study)).sum()) for study in studies])
        ax_d.barh(np.arange(len(studies)), n, left=left, color=colors[c], edgecolor='#555555', linewidth=.35)
        left += n
        study_rows.extend({'study': study, 'support': SUPPORTS[c], 'n_occurrences': int(count)} for study, count in zip(studies, n))
    for i, study in enumerate(studies):
        ax_d.text(left[i] + 1, i, f'{int(paper.eq(study).sum())} exp.', va='center', fontsize=11)
    ax_d.set(yticks=np.arange(len(studies)), yticklabels=studies,
             xlabel='Number of support occurrences', title='Catalyst-support distribution by study')
    ax_d.invert_yaxis()
    ax_d.set_xlim(0, max(left) * 1.18)
    ax_d.text(-.10, 1.04, '(d)', transform=ax_d.transAxes, weight='bold', fontsize=13)
    for ax in (ax_a, ax_b, ax_c1, ax_c2, ax_d):
        ax.grid(axis='x' if ax is ax_d else 'y', alpha=.15)
        ax.set_axisbelow(True)
        ax.tick_params(labelsize=11)
        ax.xaxis.label.set_size(12)
        ax.yaxis.label.set_size(12)
        ax.title.set_size(13)
    ax_d.tick_params(axis='y', labelsize=10.5)    
    legend = [Patch(facecolor=colors[c], edgecolor='#555555', linewidth=.4,
                    label=f'{SUPPORTS[c]} (n={counts[c]})') for c in active]
    fig.legend(handles=legend, title='Catalyst support', loc='lower center',
               bbox_to_anchor=(.5, .018), ncol=3, frameon=False, fontsize=12, title_fontsize=14)
    fig.suptitle('Dataset composition and product yield by catalyst support', weight='bold', fontsize=16, y=.98)
    fig.subplots_adjust(left=.08, right=.98, top=.92, bottom=.22)
    basename = output_dir / '00_dataset_composition_and_product_yield_by_support'
    for extension in ('png', 'pdf'):
        fig.savefig(basename.with_suffix('.' + extension), dpi=300, bbox_inches='tight')
    plt.close(fig)
    pd.DataFrame(histogram_rows).to_csv(output_dir / 'dataset_support_histogram_counts.csv', index=False)
    pd.DataFrame(summary_rows).to_csv(output_dir / 'dataset_support_yield_mean_SD.csv', index=False)
    pd.DataFrame(study_rows).to_csv(output_dir / 'dataset_support_by_study.csv', index=False)
    return basename.with_suffix('.png')


if __name__ == '__main__':
    script_dir = Path(__file__).resolve().parent
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input', type=Path, default=script_dir / 'DATA_ML_Benzene_Hydrogenation.xlsx')
    p.add_argument('--output-dir', type=Path, default=script_dir / 'results' / 'dataset_composition')
    a = p.parse_args()
    print(plot_dataset_composition(pd.read_excel(a.input, sheet_name='FullDataset'), a.output_dir))
